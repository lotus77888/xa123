'use strict';

angular.module('xplorationApp.filters', [])
        .filter('formatId', function () {
            return function (input, size) {
                if (input == null)
                    return '';
                return ('00000000' + input).substr(-size);
            };
        })
        .filter('formatDateTime', ['FORMATS', function (FORMATS) {
                return function (input, size) {
                    return moment(input).format(FORMATS.DATETIME.SHORT_DATE_TIME);
                };
            }])
        .filter('orderObjectBy', function () {
            return function (items, field, reverse) {
                var filtered = [];
                angular.forEach(items, function (item) {
                    filtered.push(item);
                });
                filtered.sort(function (a, b) {
                    return (a[field] > b[field] ? 1 : -1);
                });
                if (reverse)
                    filtered.reverse();
                return filtered;
            };
        })
        .filter('slugfilter', function () {
            return function (slug) {
                return slug.replace(/ /g , "-");
            };
        });

