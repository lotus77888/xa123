'use strict'

app.factory('Assets', ['$filter', 'Restangular', function($filter, Restangular) {

    var Assets = Restangular.all('assets');

    Restangular.extendModel('assets', function(model) {
        return model;
    });

    return Assets;

}]);
