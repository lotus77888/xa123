'use strict';
function showsService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var showsService = {};
    showsService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewPost", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getShowsData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetSelectedShowData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSelectedShowData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editShowsData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updatePostData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteShowsData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toDeleteShowLinksData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteShowsWatchLinksData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetSeasonsByShowId = function (episodeId, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getShowSeasonsByEpisodeId?episodeId=" + episodeId).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetShowPublishData = function (lmt, ofSet, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetShowPublishData?lmt=" + lmt + "&ofSet=" + ofSet).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }


    showsService.toGetShowPublishCount = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetShowPublishCount").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    // showsService.getPostDetails = function (id, successCallback, errorCallback) {
    //     $http.get(URLS.BASE_API + "/getPostDetails?id="+id ).then(function (response) {
    //         successCallback(response.data);
    //     }, function (error) {
    //         errorCallback(error);
    //     });
    // }


    /* to get all techexplorer data */
    showsService.toGetDataById = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetOnlyShowsData?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    showsService.toGetShowWatchLinksDataByShowId = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetShowLinksData?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }



    /* to get all Season data */
    showsService.toGetSeasonDataById = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/togetSeasonsBasedOnShowId?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to get all Season data */
    showsService.toGetEpisodeDataById = function (limit, offset, id, slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetEpisodeData?slug=" + slug + "&limit=" + limit + "&offset=" + offset + "&seasonId=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Publish Count */
    showsService.toGetEpisodeDataCount = function (id, slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getEpisodeDataCount?slug=" + slug + "&seasonId=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* check slug aleady exist or not */
    showsService.toCheckSlug = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkShowSlug", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* check Show Name whether aleady exist or not */
    showsService.toCheckShowName = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkShowName", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    return showsService;
}

app.factory('showsService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    showsService
]);