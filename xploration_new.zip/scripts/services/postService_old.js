'use strict';
function postService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var postService = {};
    postService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewPost", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    postService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPostData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    postService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editPostData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    postService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updatePostData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    postService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deletePostData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    return postService;
}

app.factory('postService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    postService
]);