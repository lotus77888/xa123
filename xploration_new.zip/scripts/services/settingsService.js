'use strict';
function settingsService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var settingsService = {};

    settingsService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateSettings", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
//
//    settingsService.toGetS = function (data, successCallback, errorCallback) {
//        $http.post(URLS.BASE_API + "/updateSettings", {
//            data: data
//        }).then(function (response) {
//            successCallback(response);
//        }, function (error) {
//            errorCallback(error);
//        });
//    }

    settingsService.toGetData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editSettingsData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    return settingsService;
}

app.factory('settingsService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    settingsService
]);