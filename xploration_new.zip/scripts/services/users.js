'use strict'

app.factory('Users', ['$filter', 'Restangular', function($filter, Restangular) {

    var Users = Restangular.service('users');

    Restangular.extendModel('users', function(model) {
        model.selected = false;

        model.getFullName = function() {
        	if (model.full_name) return full_name;
        	return model.first_name + ' ' + model.last_name;
        }

        return model;
    });

    return Users;

}]);
