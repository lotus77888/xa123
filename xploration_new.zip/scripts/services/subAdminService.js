'use strict';
function SubAdminService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var subAdminService = {};
    subAdminService.chkUserExistingPassword = function (data, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/checkUserExistingPassword?id=" + data.id + "&password=" + data.password)
                .then(function (response) {
                    if (response.data !== 'fail') {
                        $rootScope.errorMsg = '';
                        successCallback(response);
                    } else {
                        $rootScope.errorMsg = 'Password was incorrect';
                        successCallback(response);
                    }
                }, function (error) {
                    errorCallback(error);
                });
    }

    subAdminService.checkingUser = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/forgotPassword", {
            data: email
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.resetPassword = function (resetKey, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/userData?resetKey=" + resetKey)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }

    subAdminService.toUpdatePassword = function (updateddata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updatePassword", {
            data: updateddata
        }).then(function (response) {
            console.log(response);
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toGetAdminData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editSubAdmindata?id=" + id)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }

    subAdminService.toUpdateUserData = function (updateddata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateSubAdmindata", {
            data: updateddata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toAddNewUserData = function (userdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewUser", {
            data: userdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toGetAdminsData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSubAdminsdata").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    subAdminService.toGetAllUsersData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllUserData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toAddSubAdminData = function (userdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addAdmindata", {
            data: userdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toCheckEmail = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkEmail", {
            data: email
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    subAdminService.toDeleteAdmin = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteSubAdmindata/"+id).then(function (response) {
            if (response.data == 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }


    subAdminService.auth = function (event) {

        if ($rootScope.toState.data.access !== undefined) {
            var access = $rootScope.toState.data.access;
            if ($localStorage.session !== undefined) {
                if ($localStorage.session.username === undefined && access) {
                    $state.go("access.login");
                    event.preventDefault();
                } else if ($localStorage.session.username !== undefined && !access) {
                    $state.go("home.app.dashboard");
                    event.preventDefault();
                }
            } else {
                if ($rootScope.toState.name === "access.login") {
                    return;
                }
                $state.go("access.login");
                event.preventDefault();
            }

        }
    }


    return subAdminService;
}

app.factory('SubAdminService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    SubAdminService
]);