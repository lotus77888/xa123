'use strict';

app.provider('notification', [function() {

  this.$get = ['toaster', function(toaster) {

    return {
      notifySuccess: function(title, message) {
      	toaster.success({
          title: title,
          body: message,
          showCloseButton: true,
        });
      },
      notifyInfo: function(title, message) {
        toaster.info({
          title: title,
          body: message,
          showCloseButton: true,
        });
      },
      notifyError: function(title, error) {
        toaster.error({
          title: title,
          body: error,
          showCloseButton: true,
        });
      },
      notifyErrors: function(title, errors) {
        var body = '<ul>';
        for (var i = 0; i < errors.length; i++) {
          body += '<li>' + errors[i] + '</li>';
        }
        body += '</ul>';

        toaster.error({
          title: title,
          body: body,
          showCloseButton: true,
          bodyOutputType: 'trustedHtml',
        });
      }
    };

  }];

}]);