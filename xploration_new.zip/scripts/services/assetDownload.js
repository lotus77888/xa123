'use strict'

app.factory('AssetDownload', ['$filter', 'Restangular', function($filter, Restangular) {

    var AssetDownload = Restangular.service('orders');

    Restangular.extendModel('tempreports', function(model) {
        return model;
    });

    return AssetDownload;

}]);