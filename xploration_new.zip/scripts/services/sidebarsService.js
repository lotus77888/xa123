'use strict';
function sidebarsService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var sidebarsService = {};

    var sidebarsService = {};
    sidebarsService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/sidebarsData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    sidebarsService.toGetAllActiveSidebarsData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/sidebarsActiveData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    sidebarsService.toAddSidebarData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addSidebar", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    sidebarsService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteSidebarData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    sidebarsService.toGetSidebarData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editSidebardata?id=" + id)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }


    sidebarsService.toCheckSidebarTitle = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkSidebarTitle", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    return sidebarsService;
}

app.factory('sidebarsService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    sidebarsService
]);