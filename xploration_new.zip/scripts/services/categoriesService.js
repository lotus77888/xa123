'use strict';
function categoryService($http, jwtHelper, Session, URLS, $localStorage, $stateParams, $state, $rootScope, MESSAGES) {

    var categoryService = {};
    categoryService.toAddNewCategoryData = function (categorydata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addCategoryData", {
            data: categorydata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toGetAllCategoriesData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getCategroyData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toGetHomeCategoriesData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getHomeCategroyData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toGetCategoryData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editCategroyData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toGetCategoryDataBySlug = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editCategroyDataBySlug?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    categoryService.toGetCategoryDataById = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editCategoryDataById?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    categoryService.toGetSelectCategoryData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSelectCategoryData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Check Home Category Count */
    categoryService.toCheckHomeCategoryCount = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getHomeCategoryCount", {
            data: data
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* check Category Name whether aleady exist or not */
    categoryService.toCheckCategory = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkCategory", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toUpdateCategoryData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updateCategoryData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    categoryService.toDeleteCategoryData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteCategoryData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    categoryService.toGetCategoryDataByPostId = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/categoryDataByPostId?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }



    return categoryService;
}

app.factory('CategoryService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$stateParams',
    '$state',
    '$rootScope',
    'MESSAGES',
    categoryService
]);