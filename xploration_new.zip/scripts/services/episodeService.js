'use strict';
function episodesService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var episodesService = {};


    episodesService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getEpisodeData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }


    episodesService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editEpisodeData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    episodesService.toUpdateEpisodeData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updateEpisodeData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    episodesService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteEpisodeData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    episodesService.toGetSeasonsByShow = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSeasonsByShow?id=" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    episodesService.toGetWatchlinksByShow = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getWatchLinksByShow?id=" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    /* check slug aleady exist or not */
    episodesService.toCheckSlug = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkEpisodeSlug", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Get episode Detail */
    episodesService.getEpisodeDetails = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getEpisodeDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    
    /* to Get episode realted Data */
    episodesService.getRelatedEpisodeData = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getRelatedEpisodeDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Get Next episode Detail */
    episodesService.getNextEpisodeData = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getNextEpisodeDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    episodesService.getTrendingEpisodeData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getTrendingEpisodes").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Post_views By using Post Id*/
    episodesService.updateEpisodeViewCount = function (id, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateEpisodeViewCount", {
            id: id
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Episode_view By using S Id*/
    episodesService.updateEpisodeViewCount = function (slug, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateEpisodeViewCount", {
            slug: slug
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    return episodesService;
}

app.factory('episodesService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    episodesService
]);