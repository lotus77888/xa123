'use strict';
function keywordService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var keywordService = {};
    keywordService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewKeyword", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    keywordService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getKeywordData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    keywordService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editKeywordData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    keywordService.toGetSelectedKeywordData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSelectedKeywordData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    keywordService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updateKeywordData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    keywordService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteKeywordData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    return keywordService;
}

app.factory('keywordService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    keywordService
]);