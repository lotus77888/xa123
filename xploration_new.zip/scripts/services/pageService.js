'use strict';
function pagesService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var pagesService = {};

    pagesService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPageData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toGetHomePagesData = function (val, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getHomePagesData?val=" + val).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toSelectOption = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getSelectOptionData", {
            data: data
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toGetCustomPageData = function (slug, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getPagesDataBySlug",{slug: slug}).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewPage", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updatePage", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }


    /* check Category Name whether aleady exist or not */
    pagesService.toCheckPageTitle = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPageTitle", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* check Page title for Mobile */
    pagesService.toCheckPageTitleForMobile = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPageTitleForMobile", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* check slug aleady exist or not */
    pagesService.toCheckSlug = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPageSlug", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    pagesService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editPageData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    pagesService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deletePageData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to get  Sidebar Details */
    
    pagesService.getsideBarDetails = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPageSidebarDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    return pagesService;
}

app.factory('pagesService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    pagesService
]);