'use strict';
function userService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var userService = {};

    /* to add user */
    userService.toAddNewUserData = function (userdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewUser", {
            data: userdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* to add user end here */

    /* to get all users data */
    userService.toGetAllUsersData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllUserData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* to get all users data end here */

    /* to get user data by id */
    userService.toGetUserData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editUserData?id=" + id)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }
    /* to get user data by id end here */


    /* check email for user whether aleady exist or not */
    userService.toCheckUserEmail = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkUserEmail", {
            data: email
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* check email for user whether aleady exist or not end*/

    /* to delete user */
    userService.toDeleteUser = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteUserData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* to delete user end*/

    userService.toUpdateUserData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateUserData/", {data: data}).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    return userService;
}

app.factory('UserService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    userService
]);