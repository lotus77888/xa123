'use strict';

function AuthenticationService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var authenticationService = {};

    authenticationService.isAuthenticated = function () {
        return Session.get() != null;
    };

    authenticationService.login = function (credentials, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/login", {
            data: credentials
        }).then(function (response) {
            if (response.data != 'fail') {
                $rootScope.authError = false;
                console.log(response.data);
                // $state.go('home.app.dashboard');
                $localStorage.session = response.data;
            } else {
                $rootScope.authError = true;
                $rootScope.errorMessage = MESSAGES.LOGIN.INVALID_CREDENTIALS;
            }
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.logout = function (successCallback) {
        Session.destroy();
        successCallback();
    };

    authenticationService.forgetPwd = function (details, successCallback, errorCallback) {
        console.log('dad');
    }

    authenticationService.chkUserExistingPassword = function (data, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/checkUserExistingPassword?id=" + data.id + "&password=" + data.password)
                .then(function (response) {
                    if (response.data !== 'fail') {
                        $rootScope.errorMsg = '';
                        successCallback(response);
                    } else {
                        $rootScope.errorMsg = 'Password was incorrect';
                        successCallback(response);
                    }
                }, function (error) {
                    errorCallback(error);
                });
    }

    authenticationService.checkingUser = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkEmail", {
            data: {email:email}
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    authenticationService.forgetPassword = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/forgotPassword", {
            data: email
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.resetPassword = function (resetKey, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/userData?resetKey=" + resetKey)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }

    authenticationService.toUpdatePassword = function (updateddata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updatePassword", {
            data: updateddata
        }).then(function (response) {
            console.log(response);
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.toGetUserData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editSubAdmindata?id=" + id)
                .then(function (response) {
                    successCallback(response.data);
                }, function (error) {
                    errorCallback(error);
                });
    }

    authenticationService.toUpdateUserData = function (updateddata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updateSubAdmindata", {
            data: updateddata
        }).then(function (response) {
            console.log(response);
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.toAddNewUserData = function (userdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewUser", {
            data: userdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.toGetAllAppData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetAllAppData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    authenticationService.toAddAdmin = function (userdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addAdmindata", {
            data: userdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }


    authenticationService.auth = function (event) {

        if ($rootScope.toState.data.access !== undefined) {
            var access = $rootScope.toState.data.access;
            if ($localStorage.session !== undefined) {
                  
                if ($rootScope.toState.data.adminPermission !== undefined) {
                    var accessPermission = $localStorage.session.permissions[$rootScope.toState.data.adminPermission];
                    if (!accessPermission && $rootScope.fromState.data !== undefined) {
                        console.error("401 UnAuthorized");
                        $rootScope.UnAuth = true;
                        $rootScope.loading = false;
                        event.preventDefault();
                    }else if(!accessPermission && $rootScope.fromState.data === undefined){
                        console.error("401 UnAuthorized");
                        $state.go("home.app.dashboard");
                        $rootScope.UnAuth = true;
                        $rootScope.loading = false;
                        event.preventDefault();
                    }
                }

                if ($localStorage.session.username === undefined && access) {
                    $state.go("access.login");
                    $rootScope.loading = false;
                    event.preventDefault();
                } else if ($localStorage.session.username !== undefined && !access) {
                    $state.go("home.app.dashboard");
                    $rootScope.loading = false;
                    event.preventDefault();
                }
            } else {
                if ($rootScope.toState.name === "access.login") {
                    $rootScope.loading = false;
                    return;
                }
                $state.go("access.login");
                $rootScope.loading = false;
                event.preventDefault();
            }

        }
    }


    return authenticationService;
}

app.factory('AuthenticationService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    AuthenticationService
]);