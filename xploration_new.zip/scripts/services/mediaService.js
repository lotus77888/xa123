'use strict';
function mediaService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var mediaService = {};
    mediaService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewMedia", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    mediaService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getMediaData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    mediaService.toGetImagesData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getImagesData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    mediaService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editMediaData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    mediaService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updateMediaData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    mediaService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteMediaData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    return mediaService;
}

app.factory('mediaService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    mediaService
]);