'use strict'

app.provider('datetime', [function DateTimeProvider () {

  this.$get = ['FORMATS', function (FORMATS) {

  	return {
  		getCurrentDateTime: function() {

  			return moment().format(FORMATS.DATETIME.SHORT_DATE_TIME);
  		}
  	}
  }]

}]);
