'use strict';

app.factory('UserInfo', [
  '$http',
  '$localStorage',
  'URLS',
  '$q',
  '$timeout',
  '$rootScope',
  '$state',
  '$location',
  function(
    $http,
    $localStorage,
    URLS,
    $q,
    $timeout,
    $rootScope,
    $state,
    $location
  ) {

    var user = {};

    user.getUserInfo = function() {
      return $localStorage.user;
    };

    user.get = function(successCallback, errorCallback) {
      console.log("get uinfo:",URLS.BASE_API);
      $http({
        url: URLS.BASE_API + '/login',
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(function(response) {
      	
        $localStorage.user = response.data.data;
        successCallback(response);
      }, function(error) {
        errorCallback(error);
      });
    };

    user.destroy = function() {
      delete $localStorage.session;
    };


    // user.get = function() {
    //   var deferred = $q.defer();
    //   $http.get(URLS.BASE_API + '/me').then(function(res) {
    //     $timeout(function(){
    //       deferred.resolve(res);
    //     }, 10000);
        
    //   }, function(error) {
    //     console.log("sdfsf");
    //     deferred.reject(error);
    //   });

    //   return deferred.promise;

    // }

    user.authentication = function(){
      delete $localStorage.user;
      if($rootScope.toState.data.access !== undefined){
        var access = $rootScope.toState.data.access;
        //$localStorage.user = "sdfsdf";
        console.log("access", access);
        if($localStorage.user === undefined && access){
          console.log("loginnnnnnnnnnnnnn");
          $timeout(function(){
            $location.url('/access/login');
          });
          
          // $state.go("access.acp"); 
        }else if($localStorage.user !== undefined && !access){
          console.log("dashboardddddddddddddddddd");
          // $state.go("home.app.dashboard");
           $timeout(function(){
              $location.url('/acp/dashboard');
           });
        }
        console.log("$localStorage.user", $localStorage.user);
      }
      
      
    }

    return user;

  }
]);