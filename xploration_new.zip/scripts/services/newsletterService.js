'use strict';
function newsletterService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var newsletterService = {};
    newsletterService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/newsletterData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.toInsert = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addnewsletter", {email: email}).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.contestContactInfo = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/contestContactInfo", {email: email}).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.toCheckEmail = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkNewletterEmail", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.toAddNewsletterData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addnewsletterdata", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.toGetNewletterData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editNewsletterdata?id=" + id)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }

    newsletterService.toDeleteNewsletter = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteNewsletterdata/" + id).then(function (response) {
            if (response.data == 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    newsletterService.toDeleteMultipleData = function (ids, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/deleteMultipleNLData/", {ids: ids}).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* for search */
    newsletterService.forsearchCount = function (value, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getSearchCount/", {data: value}).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */

    return newsletterService;
}
app.factory('newsletterService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    newsletterService
]);