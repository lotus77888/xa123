'use strict'

app.factory('Roles', ['$filter', 'Restangular', function($filter, Restangular) {

    var Users = Restangular.service('roles');

    Restangular.extendModel('roles', function(model) {
        return model;
    });

    return Users;

}]);
