'use strict';
function techexplorerService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var techexplorerService = {};

    /* to get all techexplorer data */
    techexplorerService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllTechexplorersData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* end here */

    /* to get all techexplorer data by limit*/
    techexplorerService.toGetAllDataByLimit = function (lmt, slug, successCallback, errorCallback) {
//        console.log('hi');console.log(slug);return false;
        $http.get(URLS.BASE_API + "/getAllTechexplorersDataByLimit?lmt=" + lmt + "&slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* end here */

    /* to get all techexplorer data by limit */
    techexplorerService.toGetAllXplorerDataByLimit = function (lmt, id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllXplorersDataByLimit?lmt=" + lmt + "&id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */

    /* to get all techexplorer data based on status*/
    techexplorerService.toGetAllDataStatus = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllTechexplorersDataStatus").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */
    /* to get all techexplorer data based on status*/
    techexplorerService.toGetAllDataStatusByAsc = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getAllTechexplorersDataStatusByAsc").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */


    /* to add techexplorer */
    techexplorerService.toAddNewTechexplorer = function (techexplorerdata, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewTechexplorerData", {
            data: techexplorerdata
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */

    /* to get techexplorer data */
    techexplorerService.toGetTechexplorerData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editTechexplorerData?id=" + id)
                .then(function (response) {
                    successCallback(response);
                }, function (error) {
                    errorCallback(error);
                });
    }
    /* end here */

    /* to delete techexplorer 8*/
    techexplorerService.toDeleteTechexplorer = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deleteTechexplorerData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */

    /* to check email */
    techexplorerService.toCheckTechexplorerEmail = function (email, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkTechexplorerEmail", {
            data: email
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */



    /* to get all techexplorer data */
    techexplorerService.toGetDataById = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetXplorerDataById?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to get Techxplorer data by Seasons Id */
    techexplorerService.toGetTexhxplorerDataBySeasonId = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetXplorerDataBySeasonId?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }


    return techexplorerService;
}
app.factory('techexplorerService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    techexplorerService
]);