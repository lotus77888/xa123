'use strict';

app.factory('TokenInterceptor', [
  '$timeout',
  '$q',
  '$location',
  'Session',
  function(
    $timeout,
    $q,
    $location,
    Session
  ) {

    var tokenInterceptor = {};

    tokenInterceptor.request = function(config) {

      config.headers = config.headers || {};

      var session = Session.get();
      if (session) {
        config.headers.Authorization = 'Bearer ' + session.token;
      }

      return config;
    }

    tokenInterceptor.responseError = function(response) {

      if (response.status === 401) {
        $timeout(function() {
          $location.path('/access/login');
        }, 1);

      }

      if (response.status === 403) {
        $timeout(function() {
          $location.path('/app/dashboard');
        }, 1);

      }

      return $q.reject(response);
    }

    return tokenInterceptor;
  }
])
