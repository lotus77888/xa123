'use strict';

function Session($localStorage) {
    this.get = function() {
        return $localStorage.session;
    }

    this.set = function(session) {
        $localStorage.session = session;
    }

    this.destroy = function() {
        delete $localStorage.session;
    }
}

app.service('Session', ['$localStorage',
    Session
]);
