'use strict';
function postService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var postService = {};

    /* to Get All Post Data */
    postService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPostData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Get All Post Data */
    postService.toGetSelectedData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSelectedPostData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to get posts by category */

    postService.toGetAllDataByCategoryId = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPostDataByCategory?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Add Post Data */
    postService.toAddData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/addNewPost", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }



    /* to Get Post Data */
    postService.toGetData = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/editPostData?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Update Post Data */
    postService.toUpdateData = function (data, successCallback, errorCallback) {
        $http.put(URLS.BASE_API + "/updatePostData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Delete Post Data */
    postService.toDeleteData = function (id, successCallback, errorCallback) {
        $http.delete(URLS.BASE_API + "/deletePostData/" + id).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    postService.toDeleteMultipleData = function (ids, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/deleteMultiplePostData/", {ids: ids}).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Publish Data */
    postService.toGetPostPublishData = function (lmt, ofSet, banner_type, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetPostPublishData?lmt=" + lmt + "&ofSet=" + ofSet + "&banner_type=" + banner_type).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Publish Data By Category */
    postService.toGetPostPublishDataByCategory = function (slug, post_id, lmt, ofSet, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetPostPublishDataByCategory?slug=" + slug + "&post_id=" + post_id + "&lmt=" + lmt + "&ofSet=" + ofSet).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Get Post Publish Data By using  Category Id*/
    postService.toGetPostPublishDataByCategoryById = function (id, post_id, lmt, ofSet, successCallback, errorCallback) {
        console.log(id);return false;
        $http.get(URLS.BASE_API + "/toGetPostPublishDataByCategoryById?id=" + id + "&post_id=" + post_id + "&lmt=" + lmt + "&ofSet=" + ofSet).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Publish Count Data By Category Count */
    postService.toGetPostPublishDataByCategoryCount = function (slug, post_id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetPostPublishDataByCategoryCount?slug=" + slug + "&post_id=" + post_id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }


    /* to Get Post Publish Count Data by id */
    postService.toGetPostPublishDataByCategoryCountById = function (id, post_id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetPostPublishDataByCategoryCountById?id=" + id + "&post_id=" + post_id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to Get Post Publish Count */
    postService.toGetPostPublishCount = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/toGetPostPublishCount").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Detail */
    postService.getPostDetails = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPostDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* to get  Sidebar Details */
    
    postService.getsideBarDetails = function (slug, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getSidebarDetails?slug=" + slug).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Preview Post Detail */
    postService.getPreviewPostDetails = function (id, successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getPreviewPostDetails?id=" + id).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Post Trending Data */
    postService.getTrendingPostData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/getTrendingPosts").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* to Get Trending Post Data By Slug in Category */
    postService.getTrendingPostDataByCategory = function (slug, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getTrendingPostsByCategory", {
            slug: slug
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

        postService.getTrendingPostDataByCategoryById = function (id, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getTrendingPostsByCategoryById", {
            id: id
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    /* Post Tilte whether aleady exist or not */
    postService.toCheckPostTitle = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPostTitle", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }

    /* Post Tilte For Mobile whether aleady exist or not */
    postService.toCheckPostTitleForMobile = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPostTitleForMobile", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    
    /* check slug aleady exist or not */
    postService.toCheckPostSlug = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/checkPostSlug", {
            data: data
        }).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }


    /* to Post_views By using Post Id*/
    postService.updatePostViewCount = function (id, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/updatePostViewCount", {
            id: id
        }).then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }

    /* for search */
    postService.forsearchCount = function (value, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/getPostSearchCount/", {data: value}).then(function (response) {
            if (response.data === 'fail') {
                successCallback(response);
            } else {
                successCallback(response);
            }
        }, function (error) {
            errorCallback(error);
        });
    }
    /* end here */
    return postService;
}

app.factory('postService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    postService
]);