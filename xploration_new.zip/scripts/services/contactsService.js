'use strict';
function contactsService($http, jwtHelper, Session, URLS, $localStorage, $state, $rootScope, MESSAGES) {

    var contactsService = {};
    contactsService.toGetAllData = function (successCallback, errorCallback) {
        $http.get(URLS.BASE_API + "/contactsData").then(function (response) {
            successCallback(response.data);
        }, function (error) {
            errorCallback(error);
        });
    }
    
    
    contactsService.toSendEmailData = function (data, successCallback, errorCallback) {
        $http.post(URLS.BASE_API + "/SendContactUsData", {
            data: data
        }).then(function (response) {
            successCallback(response);
        }, function (error) {
            errorCallback(error);
        });
    }
    return contactsService;
}
app.factory('contactsService', [
    '$http',
    'jwtHelper',
    'Session',
    'URLS',
    '$localStorage',
    '$state',
    '$rootScope',
    'MESSAGES',
    contactsService
]);