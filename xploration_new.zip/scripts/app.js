'use strict';

/**
 * @ngdoc overview
 * @name xplorationApp
 * @description
 * # xplorationApp
 *
 * Main module of the application.
 */
var app = angular.module('xplorationApp', [
    'angular-ladda',
    'angular-jwt',
    'ngAnimate',
    'ngAria',
    'ngCookies',
    'ngMessages',
    'ngSanitize',
    'ngStorage',
    'ui.router',
    'permission',
    'ui.bootstrap',
    'ui.utils',
    'ui.validate',
    'ui.date',
    'toaster',
    'ui.select',
    'oc.lazyLoad',
    'restangular',
    'angularUtils.directives.dirPagination',
    'xplorationApp.filters',
    'angularMoment',
    'angularFileUpload',
    'ngFileUpload',
    'daterangepicker',
    'ngProgress',
    'textAngular',
    'ngTagsInput',
    'djds4rce.angular-socialshare'
]);

app.run([
    '$rootScope',
    '$state',
    'Session',
    '$localStorage',
    'AuthenticationService',
    '$FB',
    function (
            $rootScope,
            $state,
            Session,
            $localStorage,
            AuthenticationService,
            $FB
            ) {

        $FB.init('1197711023678715');

        $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
            $rootScope.toState = toState;
            $rootScope.fromState = fromState;
            $rootScope.loading = true;
            window.scrollTo(0, 0);
            $rootScope.UnAuth = false;
            AuthenticationService.auth(event);
            $rootScope.site_tit_cont = 'Xploration Station: Science for everyone | STEM Education Videos';
            $rootScope.site_desc_cont = 'Xploration Station explores space with Emily Calandrelli, DIY science experiments with Steve Spangler, our planet, future tech, and STEM with engaging videos.';
            $rootScope.site_tags = 'STEM Education, Education Videos, Science Videos, Earth Videos, Space Videos, Tech Videos';

        });

        $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState) {
            $rootScope.loading = false;
            if (toState == null) {
                return;
            }
        });
    }
]);
