app.directive('scroll', function($window) {
    return function(scope, element, attr) {
        angular.element($window).bind('scroll', function() {
            if (this.pageYOffset >= 1) {
                scope.ChangeClass = true;
            } else
            {
                scope.ChangeClass = false;
            }
            scope.$apply();
        });
    };
});