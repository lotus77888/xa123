'use strict';

angular.module('xplorationApp')
    .directive('uiSortable', [function() {

        return {
            restrict: 'A',
            scope: {
                uiSortableOptions: '=',

            },
            link: function(scope, el, attr) {
                el.addClass('dataTable');
                var options = scope.uiSortableOptions;
                var columns = options.columns;

                var headers = el.find('thead > tr > th');

                var sortableHeaders = headers.filter(function(index, header) {
                    return columns[index].sortable == 1;
                })

                var sortableColumns = columns.filter(function(column) {
                    return column.sortable;
                })

                sortableHeaders.each(function(index, header) {
                    var $header = angular.element(header);
                    $header.attr('ui-sortable-name', sortableColumns[index].name);
                    $header.addClass('sorting');
                    $header.on('click', headerClicked);
                })

                function headerClicked() {
                    var clickedHeader = this;

                    sortableHeaders.each(function(index, header) {
                        if (this == clickedHeader) {
                            return;
                        }
                        $(header).attr('class', 'sorting');
                    })

                    var sortingClass = $(clickedHeader).hasClass('sorting_asc') ? 'sorting_desc' : 'sorting_asc';
                    var sortDirection = $(clickedHeader).hasClass('sorting_asc') ? 'desc' : 'asc';

                    $(clickedHeader).attr('class', sortingClass);

                    if (scope.uiSortableOptions.onSort) {
                        scope.uiSortableOptions.onSort($(this).attr('ui-sortable-name'), sortDirection);
                    }
                }
            }
        };
    }]);
