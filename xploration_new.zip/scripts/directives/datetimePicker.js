app.directive('datetimePicker', function() {
  return {
    restrict: 'AE',
    transclude: true,
    require: '^ngModel',
    replace: true,
    template: '<div class="input-group date">' +
      '<span class="input-group-addon">' +
      '<span class="glyphicon glyphicon-calendar"></span>' +
      '</span>' +
      '</div>',

    controller: [
      '$scope',
      '$element',
      '$attrs',
      '$transclude',
      '$parse',
      'FORMATS',
      function(
        $scope,
        $element,
        $attrs,
        $transclude,
        $parse,
        FORMATS
      ) {
        var ngModel = $element.controller('ngModel');

        var dateFormat = $attrs.format || FORMATS.SHORT_DATE_TIME;
        var value = $scope.$eval($attrs.ngModel);

        $transclude(function(clone) {
          $element.prepend(clone);
        });

        var picker = $element.datetimepicker({
          format: dateFormat,
          defaultDate: moment(value, FORMATS.DATETIME.ISO_SHORT_DATE_TIME),
          ignoreReadonly: true
        });

        picker.on('dp.change', function(a, b) {
          var value = a.date.format(FORMATS.DATETIME.ISO_SHORT_DATE_TIME);
          ngModel.$setViewValue(value);
        })

      }
    ]
  }
});
