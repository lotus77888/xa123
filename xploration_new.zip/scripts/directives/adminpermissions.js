app.directive('adminPermissions', function (LISTS, $localStorage) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var accessPermission = $localStorage.session.permissions[attrs.accessPermission];
            if(!accessPermission){
                element.addClass('ng-hide');
            }
        }
    };
});