'use strict';

app.config([
  '$controllerProvider',
  '$compileProvider',
  '$httpProvider',
  '$filterProvider',
  '$provide',
  'RestangularProvider',
  'paginationTemplateProvider',
  'URLS',
  function(
    $controllerProvider,
    $compileProvider,
    $httpProvider,
    $filterProvider,
    $provide,
    RestangularProvider,
    paginationTemplateProvider,
    URLS
  ) {

    // Lazy controller, directive and service
    app.controller = $controllerProvider.register;
    app.directive = $compileProvider.directive;
    app.filter = $filterProvider.register;
    app.factory = $provide.factory;
    app.service = $provide.service;
    app.constant = $provide.constant;
    app.value = $provide.value;
    // Config restanguar
     
    RestangularProvider.setBaseUrl(URLS.BASE_API); 
    
    //RestangularProvider.setDefaultHeaders({ 'Content-Type': 'application/json' });
    RestangularProvider.addResponseInterceptor(function(data, operation, what, url, response, deferred) {

      var extractedData;
      // .. to look for getList operations
      if (operation === "getList") {
        // .. and handle the data and meta data
        extractedData = data.data;
        if(data.meta != undefined)
          extractedData.meta = data.meta;
      } else {
        extractedData = data.data;
      }
      return extractedData;
    });

    console.log("configjs : config");
    // Config angular utils pagination to use custom template
    paginationTemplateProvider.setPath('views/blocks/pagination.html');

    
    //$httpProvider.interceptors.push('TokenInterceptor');
  }
]);