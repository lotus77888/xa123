'use strict';

app.constant('MESSAGES', {
    LOGIN: {
        'INVALID_CREDENTIALS': 'Your username or password is incorrect'
    }
});
 console.log(location.host);
if (location.host == "192.168.1.38:9800") {
    app.constant('URLS', { 
        BASE_API: 'http://192.168.1.38/xploration/api'
    });
} else if (location.host == "192.168.1.38") {
    app.constant('URLS', {
        BASE_API: '/xploration/api'
    });
} else if (location.host == "199.38.182.140") {
   
    app.constant('URLS', {
        BASE_API: 'http://199.38.182.140/~xplorationstatio/api'
    });
}else {
    app.constant('URLS', {
        BASE_API: 'http://www.xplorationstation.com/api'
    });
}
app.constant('API', {
    PARAMS: {
        LIMIT: 'limit',
        PAGE: 'page',
        SEARCH: 'search',
        SORT_BY: 'sort_by',
        TYPE: 'type',
        CLINIC: 'clinic',
        CONSUMER: 'consumer',
        SORT_DIRECTION: 'sort_direction',
        CATEGORY: 'category',
        START_DATE: 'start_date',
        END_DATE: 'end_date'
    }
})
        .constant('FORMATS', {
            DATETIME: {
                SHORT_DATE: 'DD/MM/YYYY',
                SHORT_DATE_TIME: 'DD/MM/YYYY h:mm a',
                ISO_SHORT_DATE: 'YYYY-MM-DD',
                ISO_SHORT_DATE_TIME: 'YYYY-MM-DD[T]HH:mm:ss',
            }
        })
        .constant('LISTS', {
            USER_TYPES: [
                {id: 10, code: 'AM', name: 'Account Manager'},
                {id: 20, code: 'A', name: 'Admin'},
                {id: 30, code: 'CC', name: 'Call Centrel Staff'},
                {id: 40, code: 'PS', name: 'Product Staff'},
                {id: 50, code: 'SA', name: 'Super Admin'},
            ],
            STATES: [
                {name: 'ACT', code: 'ACT'},
                {name: 'NSW', code: 'NSW'},
                {name: 'NT', code: 'NT'},
                {name: 'QLD', code: 'QLD'},
                {name: 'SA', code: 'SA'},
                {name: 'TAS', code: 'TAS'},
                {name: 'VIC', code: 'VIC'},
                {name: 'WA', code: 'WA'},
            ],
            DELIVERY_METHODS: [
                {id: 10, code: 'COURIER', name: 'Courier'},
                {id: 20, code: 'RECEIPTED_DELIVERY', name: 'Receipted delivery'},
            ],
            DELIVERY_TYPES: [
                {id: 10, name: 'To Doctors at Clinics'}, {id: 20, name: 'To Warehouse (bulk)'}
            ],
            ORDER_TYPES: [
                {id: 10, code: 'CONSUMER', name: 'Consumer'},
                {id: 20, code: 'ENTERPRISE', name: 'Enterprise'},
            ],
            ORDER_STATUSES: [
                {id: 10, code: 'AWAITING_PAYMENT', name: 'Awaiting payment'},
                {id: 17, code: 'AWAITING_PAYMENT_CONFIRMATION', name: 'Awaiting payment Confirmation'},
                {id: 20, code: 'CANCELLED', name: 'Cancelled'},
                {id: 30, code: 'COMPLETE', name: 'Complete'},
                {id: 40, code: 'DISPATCHED', name: 'Dispatched'},
                {id: 50, code: 'DRAFT', name: 'Draft'},
                {id: 60, code: 'IN_PROGRESS', name: 'In progress'},
                {id: 70, code: 'ON_HOLD', name: 'On hold'},
                {id: 80, code: 'PENDING', name: 'Pending'},
                {id: 90, code: 'RETURNED', name: 'Returned'},
                {id: 27, code: 'CANCELLED_STOCK', name: 'Cancelled Stock'}
            ],
            PRICE_OVERRIDE_REASONS: [
                {id: 10, code: 'OPTION1', name: 'Option One'},
                {id: 20, code: 'OPTION2', name: 'Option Two'},
                {id: 30, code: 'OPTION3', name: 'Option Three'}
            ],
            ORDER_SOURCE: [
                {code: 'email', name: 'Email'},
                {code: 'phone', name: 'Phone'},
                {code: 'fax', name: 'Fax'},
                {code: 'web', name: 'Web'}
            ],
            SUBADMIN_PERMISSIONS: ["admins","users","categories","keywords","media","xplorers","shows","episodes","posts", "pages","sidebars","settings","contacts","newsletters"]
        })
        .constant('REGEX', {
            POSTCODE: /^\d{4}$/,
            //PHONE: /^\({0,1}((0|\+61)(2|4|3|7|8)){0,1}\){0,1}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{1}(\ |-){0,1}[0-9]{3}$/,
            PHONE : /^(\(?\+?[0-9]*\)?)?[0-9_\- \(\)]*$/,        
            PH: /^[+0-9 -()&0-9-()&0-9]*$/,
            DATE: /[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])$/,
            DATETIME: /[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) (2[0-3]|[01][0-9]):[0-5][0-9]/,
            EMAIL: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/,
            MONTH: /^(0?[1-9]|1[012])$/,
            CREDIT_CARD: /\b(?:3[47]\d|(?:4\d|5[1-5]|65)\d{2}|6011)\d{12}\b/


        })
        .constant('MODULE_CONFIG', [{

            }])

