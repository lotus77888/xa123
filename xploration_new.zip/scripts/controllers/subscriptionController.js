'use strict';

app.controller('subscriptionControl', [
    '$scope',
    '$rootScope',
    '$timeout',
    'newsletterService',
    function (
            $scope,
            $rootScope,
            $timeout,
            newsletterService
            ) {
        $scope.subsceibe_form = false;

        $scope.subscribe_submit = function (valid, email) {
            $scope.subscribe_success = '';
//            var email = $scope.subscribe_email;
            if (!valid) {
                $rootScope.loading = true;
                newsletterService.toInsert(email, function (res) {
                    $rootScope.loading = false;
                    if (res === "success") {
                        //$window.alert("You are scubscribed to newsletter successfully!!!");
                        $scope.subscribe_email = "";
                        $scope.subsceibe_form = false;
                        $scope.subscribe_success = "You have subscribed successfully!!!";
                        $scope.txtClass = 'sub_sucess';
                    } else if (res === "exist") {
                        $scope.subscribe_email = "";
                        $scope.subsceibe_form = false;
                        $scope.subscribe_success = "You have already scubscribed";
                        $scope.txtClass = 'sub_error';
                    } else {
                        $scope.subsceibe_form = false;
                        $scope.subscribe_success = "Something went wrong please try again";
                        $scope.txtClass = 'sub_error';
                    }
                    $timeout(function () {
                        $scope.subscribe_success = '';
                    }, 5000);
                }, function (err) {
                    $rootScope.loading = false;
                    $scope.subscribe_success = "";
                    $scope.subscribe_success = "Something went wrong please try again";
                    $scope.txtClass = 'sub_error';
                });
            }
        }


    }
]);