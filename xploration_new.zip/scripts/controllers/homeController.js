'use strict';

app.controller('homeControl', [
    '$scope',
    'userdata',
    function (
            $scope,
            userdata
            ) {
        $scope.head_username = userdata.username; // to shwo username in header 
        $scope.head_profile_pic = userdata.profile_pic; //to show image in header

    }
]);