'use strict';

app.controller('editpageCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$filter',
    '$timeout',
    '$stateParams',
    'pagesService',
    'sidebarsService',
    'pagesData',
    'Upload',
    'mediaImages',
    'AllSidebars',
    'URLS',
    function ( 
            $scope,
            $rootScope,
            $state,
            $filter,
            $timeout,
            $stateParams,
            pagesService,
            sidebarsService,
            pagesData,
            Upload,
            mediaImages,
            AllSidebars,
            URLS
            ) {
        $scope.page = pagesData;
        $scope.mediaImages = mediaImages;
        $scope.sidebars = AllSidebars;
        $scope.posturl = URLS.BASE_API;
        $scope.page.banner = parseInt($scope.page.banner) == 1 ? true : false;
//        $scope.page.video_option = $scope.page.video_option == 1 ? true : false;
        $scope.title = 'Edit Page';
        $scope.errorPageMsg = '';
        $scope.selectOptionMessage = '';
        $scope.errorSluMsg = '';
        var id = '';
        if ($stateParams.pageId !== 'undefined') {
            id = $stateParams.pageId;
        }
        
        /* to empty the field of sidebar title while selecting No option */
        $scope.toCheckSidebar = function(val) {
            if(val == 0){
                $scope.page.sidebar_id = '';
            }
        }
        /*end */
        
         /* banner Image */
        $scope.bannerImage = function () {
            $scope.page.banner_image = '';
            $scope.sizeValiadtion = '';
        }
        /* end */
        
        /* to Check Page Title of Page*/
        $scope.toCheckPageTitle = function (pageTitle) {
            if (pageTitle === undefined) {
                return false;
            }
            var data = {
                id: id,
                pageTitle: pageTitle
            }
//            console.log(data);return false;
            pagesService.toCheckPageTitle(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorPageMsg = '';
                } else {
                    $scope.errorPageMsg = 'Title already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorPageMsg = 'Something Went Wrong!.. Please try again';
            });

        }
        /* end */
        /* To Check Page Title For Mobile*/
        $scope.toCheckPageTitleForMobile = function (pagetTitleForMobile) {
            if (pagetTitleForMobile === undefined) {
                return false;
            }
            var data = {
                id: pagesData.id,
                pageTitleMobile: pagetTitleForMobile
            }
            pagesService.toCheckPageTitleForMobile(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorPageMsgMobile = '';
                } else {
                    $scope.errorPageMsgMobile = 'Mobile Page Title already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorPageMsgMobile = 'Something Went Wrong!.. Please try again';
            });
        }
        /* end here */

        /* update page */
        $scope.addPageData = function (chk_validations, description, imageValidation, selectOptionMsg, errPageMsg,  errSluMsg, errPageMsgMob) {
            if (chk_validations === true || (imageValidation !== '' && imageValidation !== undefined) || (selectOptionMsg !== '' && selectOptionMsg !== undefined) || (errPageMsg !== '' && errPageMsg !== undefined) || (errSluMsg !== '' && errSluMsg !== undefined)  || (errPageMsgMob !== '' && errPageMsgMob !== undefined)) {
                return false;
            }
            $scope.upload($scope.page);
//            if (description < 14) {
//                return false;
//            }
        }
        /* end here */

        $scope.upload = function (page) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addNewPage',
                data: {file: page.banner_image, data: page}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authPage = true;
                if (response.data === 'success') {
                    $rootScope.pageMessage = 'Page Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.pages');
                } else {
                    $rootScope.pageMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.pageMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.pageMessage = '';
                $rootScope.authPage = false;
            }, 7000);
        };

        $scope.imageSelection = function (img) {
            console.log(img);
            console.log($rootScope.textAngularTools.insertImage.action);
            $rootScope.textAngularTools.insertImage.imgAction(img);
        }


        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authPage = false;
        }
        /* end here */

        /* for image validation */
        $scope.chkValidations = function (media) {
            if (media === undefined || media === null) {
                return;
            }
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.sizeValiadtion = 'Please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
                return;
            }
        }
        /* End here */

        /* To Get Select Option */
        $scope.toCheckOption = function (is_footer) {
            var data = {
                id: id,
                is_footer: is_footer
            }
            pagesService.toSelectOption(data, function (response) {
                if (response === 'successHeader') {
                    $scope.selectOptionMessage = 'Header Allows 1 page Only, please choose another option';
                } else if (response === 'successFooter') {
                    $scope.selectOptionMessage = 'Footer Allows 3 pages only, please choose another option';
                } else {
                    $scope.selectOptionMessage = '';
                }
            });
        }


        /* for slug */
        $scope.$watch('page.page_title', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.page.slug = '';
                return;
            }
            $scope.page.slug = $filter('slugfilter')(new_value);
        });
        /* end here */

        /* To Check Slug */
        $scope.$watch('page.slug', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            var data = {
                id: id,
                pageSlug: new_value
            }
            pagesService.toCheckSlug(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorSluMsg = '';
                } else {
                    $scope.errorSluMsg = 'Slug already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorSluMsg = 'Something Went Wrong!.. Please try again';
            });
        });
        /* end here */
    }
]);