'use strict';

app.controller('pagesCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'pagesService',
    'pagesdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            pagesService,
            pagesdata
            ) {

        $scope.pages = pagesdata;
        $scope.dropdown_val = 10;

        /* Edit Post */
        $scope.toEditPage = function (id) {
            $location.path('/acp/editpage').search({pageId: id});
        }

        /* End here */

        /* Sort the Table Headings */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* End here */


        /* Delete page Data*/
        $scope.toDeletePage = function (val, id) {
            $rootScope.loading = true;
            pagesService.toDeleteData(id, function (response) {
                $rootScope.loading = false;
                $rootScope.authPage = true;
                if (response.data === 'success') {
                    $rootScope.pageMessage = 'Page Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.pageMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.pageMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.pageMessage = '';
                $rootScope.authPage = false;
            }, 7000);
        }
        /* End here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authPage = false;
        }
        /* end here */
    }
]);