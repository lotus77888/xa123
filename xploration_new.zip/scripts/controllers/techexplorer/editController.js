'use strict';
app.controller('editTechexplorerCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$stateParams',
    '$timeout',
    'Upload',
    'URLS',
    'techexplorerdata',
    'mediaImages',
    'AllCategories',

    function (
            $scope,
            $rootScope,
            $state,
            $stateParams,
            $timeout,
            Upload,
            URLS,
            techexplorerdata,
            mediaImages,
            AllCategories
            ) {
        $scope.tExplorer = {};
        $scope.tExplorer = techexplorerdata;
        console.log($scope.tExplorer);
        $scope.posturl = URLS.BASE_API;
        $scope.oldimg = $scope.posturl + '/uploads/mediauploads/images/thumbnails_300_250/' + techexplorerdata.profile_pic;
        $scope.posturl = URLS.BASE_API;
        $scope.subTitle = 'Edit Xplorer'; // title
        $scope.mediaImages = mediaImages;
        $scope.categories = AllCategories;
//        console.log($scope.categories);
        var id = '';
        if ($stateParams.techexplorerId !== 'undefined') {
            id = $stateParams.techexplorerId;
        }

        /* Image Selection */
        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');

                $scope.oldimg = imgLink;
                $scope.tExplorer.profile_pic = img;
            }

        }

        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }
        /* end here */

        /* to update techexplorer */
        $scope.toAddNewTechexplorer = function (chk_validations, imageValidation) {
            if (chk_validations === true || (imageValidation === '' && imageValidation === undefined)) {
                return false;
            }
            $scope.upload($scope.tExplorer);
        }
        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updateTechexplorerData',
                data: {file: post.profile_pic, data: post, id: id}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authTechexplorer = true;
                if (response.data === 'success') {
                    $rootScope.techexplorerMessage = 'Xplorer Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.techexplorers');
                } else {
                    $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
            });
            $timeout(function () {
                $rootScope.techexplorerMessage = '';
                $rootScope.authTechexplorer = false;
            }, 7000);
        };
        /* end */

        /* for checking image validations */
        $scope.chkValidations = function (media) {
            if (media === undefined || media === null) {
                return;
            }
            $scope.imgValidataion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.imgValidataion = 'Please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.imgValidataion = 'File size must be lessthan 2 mb';
                return;
            }

        }
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authTechexplorer = false;
        }
        /* end here */
    }
]);