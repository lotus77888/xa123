'use strict';

app.controller('addTechexplorerCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    'Upload',
    'URLS',
    'mediaImages',
    'AllCategories',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            Upload,
            URLS,
            mediaImages,
            AllCategories
            ) {

        $scope.subTitle = 'Add Xplorer'; // title
        $scope.mediaImages = mediaImages;
        $scope.categories = AllCategories;
        $scope.posturl = URLS.BASE_API;
        $scope.tExplorer = {};


        /* image Selection */
        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');
                $scope.oldimg = imgLink;
                $scope.tExplorer.profile_pic = img;
            }

        }

        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }
        
        /* to add new techexplorer data */
        $scope.toAddNewTechexplorer = function (chk_validations, imageValidation) {
            if (chk_validations === true || (imageValidation === '' && imageValidation === undefined)) {
                return false;
            }
            $scope.upload($scope.tExplorer);
        }
        /* end here */
        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addNewTechexplorerData',
                data: {file: post.profile_pic, data: post}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authTechexplorer = true;
                if (response.data === 'success') {
                    $rootScope.techexplorerMessage = 'Xplorer Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.techexplorers');
                } else {
                    $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
            });
            $timeout(function () {
                $rootScope.techexplorerMessage = '';
                $rootScope.authTechexplorer = false;
            }, 7000);
        };

        /* for checking image validations */
        $scope.chkValidations = function (media) {
            if (media === undefined || media === null) {
                return;
            }
            $scope.imgValidataion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.imgValidataion = 'please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.imgValidataion = 'file size must be lessthan 2 mb';
                return;
            }
        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authTechexplorer = false;
        }
        /* end here */


    }
]);