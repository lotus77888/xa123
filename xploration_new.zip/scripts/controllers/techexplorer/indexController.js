'use strict';

app.controller('techexplorerCtrl', [
    '$scope',
    '$location',
    '$timeout',
    '$rootScope',
    '$state',
    'techexplorerService',
    'techexplorerdata',
    function (
            $scope,
            $location,
            $timeout,
            $rootScope,
            $state,
            techexplorerService,
            techexplorerdata
            ) {
        $scope.techexplorer = techexplorerdata; // techexplorer data
        $scope.dropdown_val = 10; // default records to show in manage page

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */
        
        /* to view data of techexplorer by uisng Id */
        $scope.toEditTechexplorer = function (id) {
            $location.path('/acp/edittechexplorer').search({techexplorerId: id});
        }
        /* end here */
        
        /* to delete techexplorer data by using Id*/
        $scope.toDeleteTechexpl = function (val, id) {
            $rootScope.loading = true;
            techexplorerService.toDeleteTechexplorer(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authTechexplorer = true;
                    $rootScope.techexplorerMessage = 'Xplorer Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authTechexplorer = true;
                    $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authTechexplorer = true;
                $rootScope.techexplorerMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.techexplorerMessage = '';
                $rootScope.authTechexplorer = false;
            }, 7000);
        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authTechexplorer = false;
        }
        /* end here */

    }
]);