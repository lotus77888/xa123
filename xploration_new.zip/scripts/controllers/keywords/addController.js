'use strict';

app.controller('addKeywordCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    '$filter',
    'keywordService',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            $filter,
            keywordService
            ) {
        $scope.title = 'Add Keyword' // title

        /* to add new keyword to database */
        $scope.addKeywordData = function (chk_validations) {
            if (chk_validations === true) {
                return false;
            }
            var data = $scope.keyword;
            $rootScope.loading = true;
            keywordService.toAddData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authKeyword = true;
                    $rootScope.keywordMessage = 'Keyword Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.keywords');
                } else {
                    $rootScope.authKeyword = true;
                    $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authKeyword = true;
                $rootScope.alertType = 'alert-danger';
                $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
            });
            $timeout(function () {
                $rootScope.keywordMessage = '';
                $rootScope.authKeyword = false;
            }, 7000);
        }
        /* end here */

        /* for slug */
        $scope.$watch('keyword.keyword_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.keyword.keyword_slug = '';
                return;
            }
            $scope.keyword.keyword_slug = $filter('slugfilter')(new_value);
        });
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authKeyword = false;
        }
        /* end here */




    }
]);