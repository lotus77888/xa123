'use strict';

app.controller('keywordsCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'keywordService',
    'keywordsdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            keywordService,
            keywordsdata
            ) {

        $scope.keywords = keywordsdata; // keywords data
        $scope.dropdown_val = 10; // default records to show in manage page

        /* to show particular data of keyword */
        $scope.toEditKeyword = function (id) {
            $location.path('/acp/editkeyword').search({keywordId: id});
        }
        /* end here */


        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */

        /* to delete keywords */
        $scope.toDeleteKeyword = function (val, id) {
            $rootScope.loading = true;
            keywordService.toDeleteData(id, function (response) {
                $rootScope.loading = false;
                $rootScope.authKeyword = true;
                if (response.data === 'success') {
                    $rootScope.keywordMessage = 'Keyword Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authKeyword = true;
                $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.keywordMessage = '';
                $rootScope.authKeyword = false;
            }, 7000);
        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authKeyword = false;
        }
        /* end here */




    }
]);