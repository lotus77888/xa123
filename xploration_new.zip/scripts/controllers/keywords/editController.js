'use strict';

app.controller('editKeywordCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    '$filter',
    'keywordService',
    'keywordData',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            $filter,
            keywordService,
            keywordData
            ) {
        $scope.keyword = keywordData; // keyword data
        $scope.title = 'Edit Keyword' // title

        /* update existing keyword to database */
        $scope.addKeywordData = function () {
            var data = $scope.keyword;
            $rootScope.loading = true;
            keywordService.toUpdateData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authKeyword = true;
                    $rootScope.keywordMessage = 'Keyword Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.keywords');
                } else {
                    $rootScope.authKeyword = true;
                    $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authKeyword = true;
                $rootScope.keywordMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.keywordMessage = '';
                $rootScope.authKeyword = false;
            }, 7000);
        }
        /* end here */

        /* for slug */
        $scope.$watch('keyword.keyword_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.keyword.keyword_slug = '';
                return;
            }
            $scope.keyword.keyword_slug = $filter('slugfilter')(new_value);
        });
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authKeyword = false;
        }
        /* end here */




    }
]);