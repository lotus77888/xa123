'use strict';

app.controller('customCategoriesCtrl', [
    '$scope',
    '$state',
    '$stateParams',
    '$rootScope',
    '$window',
    'CategoryService',
    'postsCount',
    'postService',
    'categotyDataBySlug',
    'trendingPostDataByCategory',
    'settingsData',
    'URLS',
    function (
            $scope,
            $state,
            $stateParams,
            $rootScope,
            $window,
            CategoryService,
            postsCount,
            postService,
            categotyDataBySlug,
            trendingPostDataByCategory,
            settingsData,
            URLS
            ) {
        if ($stateParams.id !== undefined) {
            CategoryService.toGetCategoryData($stateParams.id, function (response) {
                $rootScope.loading = false;
                if (response !== "fail") {
                    $stateParams.customCategory = response.slug;
                }
            }, function (data) {
                console.log(data);
            });
        }
        if (categotyDataBySlug === 0) {
            $scope.catData = 0;
        } else {
            $scope.catData = 1;
        }
        if (categotyDataBySlug.categorydata !== undefined) {
            var categoryName = categotyDataBySlug.categorydata.category_name;
            $scope.CatF = categoryName.substring(1, 0)
            $scope.CatL = categoryName.substr(1);
            $scope.posturl = URLS.BASE_API;
            $scope.site_url = settingsData.site_url;
            $scope.xplorerdata = categotyDataBySlug.techx_data;
            $scope.categoryData = categotyDataBySlug.categorydata;
            if ($scope.categoryData.category_image !== '') {
                $scope.category_image = $scope.posturl + '/uploads/categoryUploads/' + $scope.categoryData.category_image;
            }
            if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                $scope.postData = categotyDataBySlug.post_data.slice(0, 1);
            } else {
                $scope.postData = [{'id': categotyDataBySlug.categorydata.featured_post_id,
                        'feature_image': categotyDataBySlug.categorydata.feature_image,
                        'post_title': categotyDataBySlug.categorydata.post_title,
                        'thumbnail_image': categotyDataBySlug.categorydata.thumbnail_image,
                        'post_slug': categotyDataBySlug.categorydata.post_slug}]
            }

            $scope.trendingPostDataByCategory = trendingPostDataByCategory;
            var lmt = 9;
            var ofSet = 0;
            var _loadMore = 0;
            $scope.tPostData = $scope.nPostData = [];
            $scope.subscribe_success = "";

            if (postsCount !== "fail") {
                if (categotyDataBySlug.categorydata.form_subscription === 'Y') {
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        _loadMore = (parseInt(postsCount) - 12) / lmt;
                    } else {
                        _loadMore = (parseInt(postsCount) - 11) / lmt;
                    }

                } else {
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        _loadMore = (parseInt(postsCount) - 11) / lmt;
                    } else {
                        _loadMore = (parseInt(postsCount) - 10) / lmt;
                    }
                }
                console.log("_loadMore", _loadMore);
            }

            $scope.loadMore = false;
            if (categotyDataBySlug.post_data.length > 1) {
                $scope.loadMore = true;
                if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                    var fp = 1;
                    var x = 3;
                } else {
                    var fp = 0;
                    var x = 2;
                }
                if (categotyDataBySlug.categorydata.form_subscription === 'Y') {
                    var idx = 6;
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        var fp = 1;
                        var x = 3;
                    } else {
                        var fp = 0;
                        var x = 2;
                    }
                    $scope.tPostData = categotyDataBySlug.post_data.slice(fp, x);
//                $scope.ntPostData = categotyDataBySlug.post_data.slice(x, idx);
                    $scope.nPostData = categotyDataBySlug.post_data.slice(x);
                } else {
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        var fp = 1;
                        var x = 3;
                        var idx = 5;
                    } else {
                        var fp = 0;
                        var x = 2;
                        var idx = 4;
                    }

                    $scope.tPostData = categotyDataBySlug.post_data.slice(fp, x);
                    $scope.ntPostData = categotyDataBySlug.post_data.slice(x, idx);
                    $scope.nPostData = categotyDataBySlug.post_data.slice(idx);
                }

            }
            if (_loadMore == 0 || 0 > _loadMore) {
                $scope.loadMore = false;
            }

            var i = 0;
            $scope.toGetPostsData = function () {
                i++;
                if (i === 1 && categotyDataBySlug.categorydata.form_subscription === 'Y') {
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        ofSet += 12;
                    } else {
                        ofSet += 11;
                    }

                } else if (i === 1 && categotyDataBySlug.categorydata.form_subscription !== 'Y') {
                    if (categotyDataBySlug.categorydata.featured_post_id == 0) {
                        ofSet += 11;
                    } else {
                        ofSet += 10;
                    }
                } else {
                    ofSet += lmt;
                }
                console.log("_loadMore", _loadMore);
                $rootScope.loading = true;

                postService.toGetPostPublishDataByCategory($stateParams.customCategory, categotyDataBySlug.categorydata.featured_post_id, lmt, ofSet, function (response) {
                    $rootScope.loading = false;
                    if (response !== "fail") {
                        $scope.nPostData = $scope.nPostData.concat(response);
                    }
                    if (_loadMore == 1 || (_loadMore > 0 && _loadMore < 1)) {
                        $scope.loadMore = false;
                    }
                    _loadMore -= 1;
                }, function (data) {
                    console.log(data);
                });
            }
        }


        /* post full view */
        $scope.fullPostView = function (slug) {
            $state.go('home.post', {slug: slug});
        }
        /* shows inner page*/
        $scope.fullShowView = function (slug) {
            if (slug == null) {
                $state.go('home.shows');
                return;
            } else {
                $state.go('home.show', {slug: slug});
            }

        }

    }
]);