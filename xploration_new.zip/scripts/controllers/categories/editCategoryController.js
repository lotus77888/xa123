'use strict';

app.controller('editCategoriesCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$filter',
    'Upload',
    'URLS',
    '$timeout',
    '$stateParams',
    'CategoryService',
    'categoryData',
    'AllCategories',
    'categoryPostsData',
    function (
            $scope,
            $rootScope,
            $state,
            $filter,
            Upload,
            URLS,
            $timeout,
            $stateParams,
            CategoryService,
            categoryData,
            AllCategories,
            categoryPostsData
            ) {
        AllCategories.unshift({id: "0", category_name: "Please Select Parent Category"});
        $scope.category = categoryData; // to shwo all categories data
        $scope.parentCategories = AllCategories; // to shwo all categories data (parent category)
        $scope.categoryPosts = categoryPostsData;
        console.log(categoryPostsData);
        $scope.title = 'Edit Category'; // title
        $scope.homeCategoryMessage = '';
        $scope.errorCatMsg = '';
        $scope.posturl = URLS.BASE_API;
        if(categoryData.category_image !== ''){
        $scope.category.category_image = $scope.posturl + '/uploads/categoryUploads/' + categoryData.category_image;
        }
        var id = '';
        if ($stateParams.categoryId !== 'undefined') {
            id = $stateParams.categoryId;
        }

        /* Image Validations */
        $scope.sizeValiadtion = '';
        $scope.chkValidations = function (media) {
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
//                        if (this.width > 300 || this.height > 250) {
//                            $scope.sizeValiadtion = 'Image dimensions must be lessthan 300x250';
//                            $scope.$digest();
//                            return;
//                        } else {
//                            $scope.sizeValiadtion = '';
//                            $scope.$digest();
//                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            }
//           if (media !== undefined && media.size > 2000000) {
//                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
//            }
        }
        /* End here */
        
        
        /* to Check slug of Page*/
        $scope.toCheckCatName = function (categoryName) {
            if (categoryName === undefined) {
                return false;
            }
            var data = {
                id: id,
                categoryName: categoryName
            }
            CategoryService.toCheckCategory(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorCatMsg = '';
                } else {
                    $scope.errorCatMsg = 'Category already exist!.. please try with';
                }
            }, function (response) {
                $scope.errorCatMsg = 'Something Went Wrong!.. Please try again';
            });
        }

        /* to Get Home Category Data */
        $scope.toCheckHomeCategoryCount = function (is_home) {
            if (is_home === '1') {
                var data = {
                    id: id,
                    is_home: is_home
                }
                CategoryService.toCheckHomeCategoryCount(data, function (response) {
                    if (response === 'success') {
                        $scope.homeCategoryMessage = 'Home Menu Bar Allowes only 3 Categories';
                    } else {
                        $scope.homeCategoryMessage = '';
                    }
                });
            } else {
                $scope.homeCategoryMessage = '';
            }
        }

        /* update existing user to database */
//        $scope.addCategoryData = function (chk_validations, homeCatValidation, errCatMsg) {
//            if (chk_validations === true || (homeCatValidation !== '' && homeCatValidation !== undefined) || (errCatMsg !== '' && errCatMsg !== undefined)) {
//                return false;
//            }
//            var data = $scope.category;
//            $rootScope.loading = true;
//            CategoryService.toUpdateCategoryData(data, function (response) {
//                $rootScope.loading = false;
//                if (response.data === 'success') {
//                    $rootScope.authCategory = true;
//                    $rootScope.categoryMessage = 'Category Updated Successfully!..';
//                    $rootScope.alertType = 'alert-success';
//                    $state.go('home.app.categories');
//                } else {
//                    $rootScope.authCategory = true;
//                    $rootScope.alertType = 'alert-danger';
//                    $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
//                }
//            }, function (response) {
//                $rootScope.loading = false;
//                $rootScope.authCategory = true;
//                $rootScope.alertType = 'alert-danger';
//                $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
//            });
//            $timeout(function () {
//                $rootScope.categoryMessage = '';
//                $rootScope.authCategory = false;
//            }, 7000);
//        }
        /* end here */

        /* for slug */
        $scope.$watch('category.category_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.category.slug = '';
                return;
            }
            $scope.category.slug = $filter('slugfilter')(new_value);
        });
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authCategory = false;
        }
        /* end here */

        /* Update Category to database */
        $scope.addCategoryData = function (chk_validations, homeCatValidation, errCatMsg, imageVal) {
            if (chk_validations === true || (homeCatValidation !== '' && homeCatValidation !== undefined) || (errCatMsg !== '' && errCatMsg !== undefined) || (imageVal !== '' && imageVal !== undefined)) {
                return false;
            }
            $scope.upload($scope.category);
        }

        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addCategoryData',
                data: {file: post.category_image, data: post}
            }).then(function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authCategory = true;
                    $rootScope.categoryMessage = 'Category Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.categories');
                } else {
                    $rootScope.authCategory = true;
                    $rootScope.alertType = 'alert-danger';
                    $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authCategory = true;
                $rootScope.alertType = 'alert-danger';
                $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
            });
            $timeout(function () {
                $rootScope.categoryMessage = '';
                $rootScope.authCategory = false;
            }, 7000);
        };
        /* end here */


    }
]);