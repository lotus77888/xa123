'use strict';

app.controller('categoriesCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$stateParams',
    '$location',
    '$timeout',
    'CategoryService',
    'categoriesdata',
    function (
            $scope,
            $rootScope,
            $state,
            $stateParams,
            $location,
            $timeout,
            CategoryService,
            categoriesdata
            ) {

        $scope.categories = categoriesdata; // categories data
        $scope.dropdown_val = 10; // default value for showing records in manage page.

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */

        /* to display single category value in page */
        $scope.toEditCategory = function (id) {
            $location.path('/acp/editcategory').search({categoryId: id});
        }
        /* ende here */


        /* to delete category */
        $scope.toDeleteCategory = function (val, id) {
            $rootScope.loading = true;
            CategoryService.toDeleteCategoryData(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authCategory = true;
                    $rootScope.categoryMessage = 'Category Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authCategory = true;
                    $rootScope.alertType = 'alert-danger';
                    $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authCategory = true;
                $rootScope.alertType = 'alert-danger';
                $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
            });
            $timeout(function () {
                $rootScope.categoryMessage = '';
                $rootScope.authCategory = false;
            }, 7000);
        }
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authCategory = false;
        }
        /* end here */

        /* Category Preview */
        $scope.toPreviewCategory = function (id) {
//            home.customcategories({customCategory:'{{cat.slug}}'})
//            var url = $state.href('home.preview', {id: id});
            var url = $state.href('home.previewCustomcategories',{id:id});
            window.open(url, '_blank');
        }




    }
]);