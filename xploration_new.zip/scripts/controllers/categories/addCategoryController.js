'use strict';
app.controller('addCategoriesCtrl', [
    '$scope',
    '$rootScope',
    'Upload',
    'URLS',
    '$state',
    '$filter',
    '$timeout',
    'CategoryService',
    'AllCategories',
    function (
            $scope,
            $rootScope,
            Upload,
            URLS,
            $state,
            $filter,
            $timeout,
            CategoryService,
            AllCategories
            ) {
        //AllCategories.unshift({id: "0", category_name: "Please Select Parent Category"}); // to shwo all categories
        $scope.category = {};
        $scope.category.parent_category_id = '';
        $scope.category.status = '';
        $scope.parentCategories = AllCategories;
        $scope.title = 'Add Category'; // title
        $scope.homeCategoryMessage = '';
        $scope.errorCatMsg = '';
        $scope.category = {
            form_subscription: 'N'
        };
        /* To check Home Category Count */
        $scope.toCheckHomeCategoryCount = function (is_home) {
            if (is_home === '1') {
                var data = {
                    is_home: is_home
                }
                CategoryService.toCheckHomeCategoryCount(data, function (response) {
                    if (response === 'success') {
                        $scope.homeCategoryMessage = 'Home Menu Bar Allowes only 3 Categories';
                    } else {
                        $scope.homeCategoryMessage = '';
                    }
                });
            } else {
                $scope.homeCategoryMessage = '';
            }
        }

        /* Image Validations */
        $scope.sizeValiadtion = '';
        $scope.chkValidations = function (media) {
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
//                        if (this.width > 300 || this.height > 250) {
//                            $scope.sizeValiadtion = 'Image dimensions must be lessthan 300x250';
//                            $scope.$digest();
//                            return;
//                        } else {
//                            $scope.sizeValiadtion = '';
//                            $scope.$digest();
//                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            }
//            if (media !== undefined && media.size > 2000000) {
//                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
//            }
        }
        /* End here */
        
        
        /* Add New Category to database */
        $scope.addCategoryData = function (chk_validations, homeCatValidation, errCatMsg, imageVal) {
            if (chk_validations === true || (homeCatValidation !== '' && homeCatValidation !== undefined) || (errCatMsg !== '' && errCatMsg !== undefined) || (imageVal !== '' && imageVal !== undefined)) {
                return false;
            }
            $scope.upload($scope.category);
//            $rootScope.loading = true;
//            var data = $scope.category;
//            CategoryService.toAddNewCategoryData(data, function (response) {
//                $rootScope.loading = false;
//                if (response.data === 'success') {
//                    $rootScope.authCategory = true;
//                    $rootScope.categoryMessage = 'Category Added Successfully!..';
//                    $rootScope.alertType = 'alert-success';
//                    $state.go('home.app.categories');
//                } else {
//                    $rootScope.authCategory = true;
//                    $rootScope.alertType = 'alert-danger';
//                    $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
//                }
//            }, function (response) {
//                $rootScope.loading = false;
//                $rootScope.authCategory = true;
//                $rootScope.alertType = 'alert-danger';
//                $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
//            });
//            $timeout(function () {
//                $rootScope.categoryMessage = '';
//                $rootScope.authCategory = false;
//            }, 7000);
        }

        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addCategoryData',
                data: {file: post.category_image, data: post}
            }).then(function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authCategory = true;
                    $rootScope.categoryMessage = 'Category Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.categories');
                } else {
                    $rootScope.authCategory = true;
                    $rootScope.alertType = 'alert-danger';
                    $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authCategory = true;
                $rootScope.alertType = 'alert-danger';
                $rootScope.categoryMessage = 'Something Went Wrong!.. Please try again';
            });
            $timeout(function () {
                $rootScope.categoryMessage = '';
                $rootScope.authCategory = false;
            }, 7000);
        };
        /* end here */



        /* for slug */
        $scope.$watch('category.category_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.category.slug = '';
                return;
            }
            $scope.category.slug = $filter('slugfilter')(new_value);
        });
        /* end here */

        /* to Check category Name */
        $scope.toCheckCatName = function (categoryName) {
            if (categoryName === undefined) {
                return false;
            }
            var data = {
                categoryName: categoryName
            }
            CategoryService.toCheckCategory(data, function (response) {
                //console.log(category);return false;
                if (response.data === 'fail') {
                    $scope.errorCatMsg = '';
                } else {
                    $scope.errorCatMsg = 'Category already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorCatMsg = 'Something Went Wrong!.. Please try again';
            });
        }
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authCategory = false;
        }
        /* end here */




    }
]);