'use strict';

app.controller('addAdminCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    'SubAdminService',
    '$timeout',
    'REGEX',
    'LISTS',
    function (
            $scope,
            $rootScope,
            $state,
            SubAdminService,
            $timeout,
            REGEX,
            LISTS) {
        $scope.title = 'Add Admin';
        $scope.errorEmailMsg = '';
        $scope.adminPermissions = LISTS.SUBADMIN_PERMISSIONS;

        /* initialize permsissions variables as false */
        $scope.admin = {};
        $scope.admin.permissions = {};

        $scope.admin.permissions.admins = false;
        $scope.admin.permissions.users = false;
        $scope.admin.permissions.categories = false;
        $scope.admin.permissions.keywords = false;
        $scope.admin.permissions.media = false;
        $scope.admin.permissions.xplorers = false;
        $scope.admin.permissions.shows = false;
        $scope.admin.permissions.episodes = false;
        $scope.admin.permissions.posts = false;
        $scope.admin.permissions.pages = false;
        $scope.admin.permissions.sidebars = false;
        $scope.admin.permissions.settings = false;
        $scope.admin.permissions.contacts = false;
        $scope.admin.permissions.newsletters = false;
        /* end here */

        $scope.mobilePattern = REGEX.PHONE; // pattern for phone number 

        $scope.AddForm = true; // for password validation

        /* cheking validations for permissions */
        $scope.$watchCollection(
                "admin.permissions",
                function (newValue, oldValue) {
                    var keys = _.filter($scope.admin.permissions, function (num, key) {
                        return $scope.admin.permissions[key] === true;
                    });
                    $scope.permissions_validation = keys.length;
                }
        );
        /* end here */

        /* to add admins data into database */
        $scope.toAddAdminData = function (chk_validations, errEmailMsg, permissions_validation) {
            if (chk_validations === true || errEmailMsg !== '' || permissions_validation === 0) {
                return false;
            }
            $rootScope.loading = true;
            var data = $scope.admin;
            SubAdminService.toAddSubAdminData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authAdmin = true;
                    $rootScope.adminMessage = 'Admin Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.adminusers');
                } else {
                    $rootScope.authAdmin = true;
                    $rootScope.adminMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authAdmin = true;
                $rootScope.adminMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.adminMessage = '';
                $rootScope.authAdmin = false;
            }, 7000);
        }
        /* end here */

        /* to check email already exist or not */
        $scope.toCheckEmail = function () {
            if ($scope.admin.email !== undefined) {
                var data = {
                    email: $scope.admin.email
                };
                SubAdminService.toCheckEmail(data, function (response) {
                    if (response.data !== 'fail') {
                        $scope.errorEmailMsg = 'Email Already Exist';
                    } else {
                        $scope.errorEmailMsg = '';
                    }
                }, function (response) {
                    $scope.errorEmailMsg = 'Email Already Registered';
                });
            }
        }
        /* end here */

        /* for check all permissions */
        $scope.checkallpermissions = function () {
            if ($scope.checkAll) {
                angular.forEach($scope.admin.permissions, function (item, key) {
                    $scope.admin.permissions[key] = true;
                });
            } else {
                angular.forEach($scope.admin.permissions, function (item, key) {
                    $scope.admin.permissions[key] = false;
                });
            }


        }

        $scope.$watchCollection('admin.permissions', function (newvalue, oldvalue) {
            if (newvalue !== undefined) {
                var falsestatus = _.filter($scope.admin.permissions, function (item) {
                    return item == false;
                });
                if (falsestatus.length) {
                    $scope.checkAll = false;
                } else {
                    $scope.checkAll = true;
                }
            }
        });

        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authAdmin = false;
        }
        /* end here */




    }
]);