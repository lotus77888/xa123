'use strict';

app.controller('adminusersCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'SubAdminService',
    'adminsdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            SubAdminService,
            adminsdata
            ) {

        $scope.adminusers = adminsdata; // admins data
        $scope.dropdown_val = 10; // default records to show in manage page
        $scope.title = 'Manage Admins'; //page title

        /* to show particular data of admin user */
        $scope.toEditAdmin = function (id) {
            $location.path('/acp/editadmin').search({admin_id: id});
        }
        /* end here */

        /* to delete admin users */
        $scope.toDeleteAdmin = function (val, id) {
            $rootScope.loading = true;
            SubAdminService.toDeleteAdmin(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authAdmin = true;
                    $rootScope.adminMessage = 'Admin Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authAdmin = true;
                    $rootScope.adminMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authAdmin = true;
                $rootScope.adminMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.adminMessage = '';
                $rootScope.authAdmin = false;
            }, 7000);
        }

        /* end here */

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authAdmin = false;
        }
        /* end here */




    }
]);