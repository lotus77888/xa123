'use strict';

app.controller('appCtrl', []);