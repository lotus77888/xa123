'use strict';

angular.module('xplorationApp')
        .controller('previewController', [
            '$scope',
            'postData',
            '$sce',
            '$state',
            '$stateParams',
            'URLS',
            'postService',
            'categoriesdata',
            'headerpagesdata',
            'trendingPostData',
            function ( 
                    $scope,
                    postData,
                    $sce,
                    $state,
                    $stateParams,
                    URLS,
                    postService,
                    categoriesdata,
                    headerpagesdata,
                    trendingPostData
                    ) {
                $scope.postData = postData;
                console.log(categoriesdata);
                $scope.categories = categoriesdata;
                $scope.headerpages = headerpagesdata;

                /* to Update Post View Count*/
                postService.updatePostViewCount(postData.postsData.id, function (response) {
                    if (response.data === 'success') {
                        console.log('success');
                    } else {
                        console.log('fail');
                    }
                }, function (response) {
                    console.log(response);
                });
                /* end here */


                $scope.trendingPostInfo = trendingPostData;//trending Post Data
                $scope.posturl = URLS.BASE_API;
                console.log(URLS);
                console.log($scope.posturl);
                /* post view */
                var keys = [];
                angular.forEach(postData.postsData.tags, function (item, key) {
                    keys.push(item.text);
                });
                $scope.postData.postsData.tags = keys.join(',');
                $scope.postData.postsData.cats_name = $scope.postData.postsData.cats_name.join(',');
                $scope.postData.postsData.video_tag = $sce.trustAsHtml(postData.postsData.video_tag);
                $scope.postData.postsData.post_description = $sce.trustAsHtml(postData.postsData.post_description);
                /* end here */


                $scope.fullPostView = function (id) {
                    $state.go('home.post', {id: id});
                }

                /* next post video tag*/
                // if($scope.postData.nextPostData !== undefined){
                //     $scope.postData.nextPostData.video_tag = $sce.trustAsHtml(postData.nextPostData.video_tag);    
                // }

                /* end here */
            }
        ]);