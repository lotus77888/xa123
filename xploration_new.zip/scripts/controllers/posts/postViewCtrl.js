'use strict';

angular.module('xplorationApp')
        .controller('PostViewCtrl', [
            '$scope',
            '$rootScope',
            'postData',
            '$sce',
            '$state',
            '$stateParams',
            '$timeout',
            'URLS',
            'postService',
            'categoriesdata',
            'headerpagesdata',
            'trendingPostData',
            'settingsData',
            'sideBarsData',
            function (
                    $scope,
                    $rootScope,
                    postData,
                    $sce,
                    $state,
                    $stateParams,
                    $timeout,
                    URLS,
                    postService,
                    categoriesdata,
                    headerpagesdata,
                    trendingPostData,
                    settingsData,
                    sideBarsData
                    ) {
                $scope.site_url = settingsData.site_url;
                $scope.postData = postData;
                if ($scope.postData === 'fail') {
                    $rootScope.site_tit_cont = settingsData.site_title;
                    $rootScope.site_tags = settingsData.site_tags;
                    $rootScope.site_desc_cont = settingsData.site_description;
                } else {
                    if (postData.postsData !== undefined) {
                        if (postData.postsData.seo_title === '') {
                            $rootScope.site_tit_cont = settingsData.site_title;
                        }
                        if (postData.postsData.seo_tags === '') {
                            $rootScope.site_tags = settingsData.site_tags;
                        }
                        if (postData.postsData.seo_description === '') {
                            $rootScope.site_desc_cont = settingsData.site_description;
                        }
                        /* to Update Post View Count*/
                        postService.updatePostViewCount(postData.postsData.id, function (response) {
                            if (response.data === 'success') {
                                console.log('success');
                            } else {
                                console.log('fail');
                            }
                        }, function (response) {
                            console.log(response);
                        });
                        /* end here */


                        $scope.trendingPostInfo = trendingPostData;//trending Post Data
                        $scope.sideBarData = sideBarsData; // sideBars Data
//                    console.log($scope.sideBarData);
                        $scope.posturl = URLS.BASE_API;
                        /* post view */
                        var keys = [];
                        angular.forEach(postData.postsData.tags, function (item, key) {
                            keys.push(item.text);
                        });
                        $scope.postData.postsData.feature_image = $scope.posturl + '/uploads/mediauploads/images/thumbnails_300_250/' + postData.postsData.feature_image;
                        $scope.postData.postsData.tags = keys.join(',');
                        $scope.postData.postsData.cats_name = $scope.postData.postsData.cats_name.join(',');
                        $scope.postData.postsData.video_tag = $sce.trustAsHtml(postData.postsData.video_tag);
                        $scope.postData.postsData.post_description = $sce.trustAsHtml(postData.postsData.post_description);
                        /* end here */


                        $scope.fullPostView = function (slug) {
//                        console.log(slug);return false;
                            $state.go('home.post', {slug: slug});
                        }
                    }
                }

                $scope.categories = categoriesdata;
                $scope.headerpages = headerpagesdata;



                /* next post video tag*/
                // if($scope.postData.nextPostData !== undefined){
                //     $scope.postData.nextPostData.video_tag = $sce.trustAsHtml(postData.nextPostData.video_tag);    
                // }

                /* end here */

//                $scope.addSource = '<script src="//ap.lijit.com/www/delivery/fpi.js?z=451136&width=300&height=250"></script>';
//                var addS = angular.element("<script src='//ap.lijit.com/www/delivery/fpi.js?z=451136&width=300&height=250'></script>");
//                var body = angular.element(document).find('addSense');
//                body.append(addS);
//                $scope.name = '<script type="text/javascript" src="//ap.lijit.com/www/delivery/fpi.js?z=451136&width=300&height=250"></script>';

//                angular.element('#addSense').append('<script type="text/javascript" src="//ap.lijit.com/www/delivery/fpi.js?z=451136&width=300&height=250">alert(1)</script>');

            }
        ]);

app.directive("w3TestDirective", function () {
    return {
        restrict: 'E',
        replace: true,
        template: '<script src="//ap.lijit.com/www/delivery/fpi.js?z=451136&width=300&height=250"></script>'
    };
});
        