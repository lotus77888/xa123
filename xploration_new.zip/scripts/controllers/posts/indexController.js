'use strict';

app.controller('postsCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'postService',
    'postsdata',
    'postsearchdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            postService,
            postsdata,
            postsearchdata
            ) {
        $scope.posts = postsdata;
        $scope.postsTodos = [];
        $scope.totalItems = $scope.posts.length;
        $scope.searchPostData = function (val) {
            if (val == undefined && val == '') {
                $scope.totalItems = $scope.posts.length;
            } else {
                searchCount(val);
            }
        }

        /* for search count */
        function searchCount(val) {
            postService.forsearchCount(val, function (response) {
                if (response.data !== 'fail') {
                    postsdata = response.data;
                    $scope.postsTodos = postsdata.slice(begin, end);
                    $scope.totalItems = postsdata.length;
                    $scope.$watch('currentPage + itemsPerPage', function () {
                        var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                        var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                        $scope.postsTodos = postsdata.slice(begin, end);
                        $scope.isAll = false
                        angular.forEach(postsdata, function (row, index) {
                            $scope.tableSelection[row.id] = false;
                        });
                        $scope.array = [];
                    });
                } else {
                    var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                    var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                    $scope.totalItems = postsearchdata.length;
                    $scope.postsTodos = postsearchdata.slice(begin, end);
                    $scope.$watch('currentPage + itemsPerPage', function () {
                        var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                        var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                        $scope.postsTodos = postsearchdata.slice(begin, end);
                        $scope.isAll = false
                        angular.forEach(postsearchdata, function (row, index) {
                            $scope.tableSelection[row.id] = false;
                        });
                        $scope.array = [];
                    });


                }
            }, function (response) {
                $rootScope.loading = false;
            });
        }
        /* end here */


        $scope.itemsPerPage = 10;
        $scope.currentPage = 1;
        $scope.maxSize = 5;
        $scope.$watch('currentPage + itemsPerPage', function () {
            var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
            var end = parseInt(begin) + parseInt($scope.itemsPerPage);
            $scope.postsTodos = postsearchdata.slice(begin, end);
            $scope.isAll = false
            angular.forEach($scope.postsTodos, function (row, index) {
                $scope.tableSelection[row.id] = false;
            });
            $scope.array = [];
        });

        $scope.$watch('itemsPerPage', function () {
            var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
            var end = parseInt(begin) + parseInt($scope.itemsPerPage);
            $scope.postsTodos = postsearchdata.slice(begin, end);
            $scope.isAll = false
            angular.forEach($scope.postsTodos, function (row, index) {
                $scope.tableSelection[row.id] = false;
            });
            $scope.array = [];
        });




        /* Edit Post */
        $scope.toEditPost = function (id) {
            $location.path('/acp/editpost').search({postId: id});
        }
        /* End here */

        /* Preview Post */
        $scope.toPreviewPost = function (id) {
            var url = $state.href('home.preview', {id: id});
            window.open(url, '_blank');
        }
        /* end */

        /* Sort the Table Headings */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* End here */


        /* Delete Post Data*/
        $scope.toDeletePost = function (val, id) {
            $rootScope.loading = true;
            postService.toDeleteData(id, function (response) {
                $rootScope.loading = false;
                $rootScope.authPost = true;
                if (response.data === 'success') {
                    $rootScope.postMessage = 'Post Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.postMessage = '';
                $rootScope.authPost = false;
            }, 7000);
        }
        /* End here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authPost = false;
        }
        /* end here */
        /* select all  delete */
        $scope.array = [];
        $scope.isAll = false;
        $scope.tableSelection = {};

        $scope.selectAllRows = function () {
            if ($scope.isAll === false) {
                //set all row unselected
                angular.forEach($scope.postsTodos, function (row, index) {
                    $scope.tableSelection[row.id] = false;
                    if (index !== -1) {
                        $scope.array.splice(index, 1);
                    }
                });
                $scope.array = [];
            } else {
                $scope.array = [];
                //set all row selected
                angular.forEach($scope.postsTodos, function (row, index) {

                    $scope.tableSelection[row.id] = true;
                    var index = $scope.array.indexOf(row.id);
                    if (index === -1) {
                        $scope.array.push(row.id);
                    }
                });
            }

        };

        $scope.checkOnclick = function (index, id) {
            $scope.isAll = false;
            $scope.array = [];
            angular.forEach($scope.postsTodos, function (row, index) {
                if ($scope.tableSelection[row.id] == true) {
                    $scope.array.push(row.id);
                }
            });
        }
        /* delete selected rows */

        $scope.removeSelectedRows = function () {
            $rootScope.loading = true;
            postService.toDeleteMultipleData($scope.array, function (response) {
                $rootScope.loading = false;
                $rootScope.authPost = true;
                if (response.data === 'success') {
                    $rootScope.postMessage = 'Post Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.postMessage = '';
                $rootScope.authPost = false;
            }, 7000);
        }
    }
]);