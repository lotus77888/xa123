'use strict';

app.controller('editPostCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    '$filter',
    'postService',
    'AllCategories',
    'Upload',
    'URLS',
    'FORMATS',
    'postData',
    'AllKeywords',
    'mediaImages',
    'sideBars',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            $filter,
            postService,
            AllCategories,
            Upload,
            URLS,
            FORMATS,
            postData,
            AllKeywords,
            mediaImages,
            sideBars
            ) {
        $scope.post = postData;
        $scope.sidebars = sideBars;
        $scope.posturl = URLS.BASE_API;
        $scope.post.banner_featureImage = $scope.posturl + '/uploads/postuploads/' + postData.banner_featureImage;
        if($scope.post.thumbnail_image != '') {
            $scope.post.thumbnail_image = $scope.posturl + '/uploads/postuploads/' + postData.thumbnail_image;
        }
        if (postData.publish_end_date !== '0000-00-00') {
            $scope.publish_end_date = postData.publish_end_date;
        }
        $scope.posturl = URLS.BASE_API;
        $scope.oldimg = $scope.posturl + '/uploads/mediauploads/images/' + postData.feature_image;
        $scope.mediaImages = mediaImages;
        $scope.categories = AllCategories;

        $scope.category_id = '';
        $scope.title = 'Edit Post'

        var currentDate = moment().format(FORMATS.DATETIME.ISO_SHORT_DATE);
        var cYr = parseInt(moment().format('YYYY'));
        $scope.dateOptions = {
            changeYear: true,
            changeMonth: true,
//            minDate: new Date(postData.publish_start_date),
            yearRange: cYr + ':' + (cYr + 10),
//            minDate: 0,
        };
        $scope.post.publish_start_date = postData.publish_start_date;
        $scope.$watch('post.publish_start_date', function (new_value, old_value) {
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.endDateOptions = {
                changeYear: true,
                changeMonth: true,
                minDate: new_value,
                yearRange: '2013:' + (cYr + 10),
            };
        });

        $scope.$watch('publish_end_date', function (new_value, old_value) {
            if (new_value === undefined) {
                $scope.post.publish_end_date = '';
            }
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.post.publish_end_date = moment(new_value).format(FORMATS.DATETIME.ISO_SHORT_DATE);
        });


        /* Unset Feature Image Validation */
        $scope.toUnsetValidation = function () {
            $scope.sizeValiadtion = '';
        }
        /* end */
        
        
        /* Feature Image Validation */
        $scope.sizeValiadtion = '';
        $scope.chkFeatureImageValidations = function (media) {
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width == 1280 && this.height == 600) {
                            $scope.sizeValiadtion = '';
                            $scope.$digest();
                        } else {
                            $scope.sizeValiadtion = 'Image dimensions must be 1280X600';
                            $scope.$digest();
                            return;
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.sizeValiadtion = 'please select image only';
                return;
            }
//            if (media !== undefined && media.size > 2000000) {
//                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
//            }
        }


        /* Thumbnail Image */
        $scope.thumbnaiImageValidation = '';
        $scope.chkThumbnailImageValidations = function (media) {
            $scope.thumbnaiImageValidation = '';
            if (media === undefined || media === null) {
                return;
            }
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width == 300 && this.height == 250) {
                            $scope.thumbnaiImageValidation = '';
                            $scope.$digest();
                        } else {
                            $scope.thumbnaiImageValidation = 'Image dimensions must be 300X250';
                            $scope.$digest();
                            return;
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.thumbnaiImageValidation = 'please select image only';
                return;
            }
        }
        /* end */
        
        /* to Check Page Title of Page*/
        
        $scope.toCheckPostTitle = function (postTitle) {
            if (postTitle === undefined) {
                return false;
            }
            var data = {
                id: postData.id,
                postTitle: postTitle
            }
            postService.toCheckPostTitle(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorPostMsg = '';
                } else {
                    $scope.errorPostMsg = 'Title already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorPostMsg = 'Something Went Wrong!.. Please try again';
            });
        }
        /* end here */
        /* To Check Post Title For Mobile*/
        $scope.toCheckPostTitleForMobile = function (postTitleForMobile) {
            if (postTitleForMobile === undefined) {
                return false;
            }
            var data = {
                id: postData.id,
                postTitleMobile: postTitleForMobile
            }
            postService.toCheckPostTitleForMobile(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorPostMsgMobile = '';
                } else {
                    $scope.errorPostMsgMobile = 'Mobile Page Title already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorPostMsgMobile = 'Something Went Wrong!.. Please try again';
            });
        }
        /* end here */
        /* for slug */
        $scope.$watch('post.post_title', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.post.post_slug = '';
                return;
            }
            $scope.post.post_slug = $filter('slugfilter')(new_value);
        });
        /* end here */

        /* To Check Slug */
        $scope.$watch('post.post_slug', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            var data = {
                id: postData.id,
                postSlug: new_value
            }
            postService.toCheckPostSlug(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorPostSluMsg = '';
                } else {
                    $scope.errorPostSluMsg = 'Slug already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorPostSluMsg = 'Something Went Wrong!.. Please try again';
            });
        });
        /* end here */

        /* update Post Data in DB */
        $scope.addPostData = function (chk_validations, imageValidation, description, bannerImage, thumbImage, titleValidation, slugValidation, titleValidationMobile) {
            if (chk_validations === true || (imageValidation === '' || imageValidation === undefined)
                    || (bannerImage !== '' && bannerImage !== undefined)
                    || (thumbImage !== '' && thumbImage !== undefined)
                    || (titleValidation !== '' && titleValidation !== undefined)
                    || (titleValidationMobile !== '' && titleValidationMobile !== undefined)
                    || (slugValidation !== '' && slugValidation !== undefined)) {
                return false;
            }
//            if (description < 14){
//                return false;
//            }


            $scope.upload($scope.post);

        }

        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');

                $scope.oldimg = imgLink;
                $scope.post.feature_image = img;
            }

        }

        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }
        /* end here */

        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updatePostData',
                data: {file: post.banner_featureImage, data: post, thumbnail_image:post.thumbnail_image}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authPost = true;
                if (response.data === 'success') {
                    $rootScope.postMessage = 'Post Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.posts');
                } else {
                    $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.postMessage = '';
                $rootScope.authPost = false;
            }, 7000);
        };

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authPost = false;
        }
        /* end here */

        /* for image validation */
        $scope.chkValidations = function (media) {
            if (media === undefined || media === null) {
                return;
            }
            $scope.imgValidataion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.imgValidataion = 'please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.imgValidataion = 'file size must be lessthan 2 mb';
                return;
            }
        }
        /* End here */

        $scope.loadTags = function () {
            return AllKeywords;
        }


    }
]);