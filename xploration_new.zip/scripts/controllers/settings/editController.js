'use strict';

app.controller('editSettingsCtrl', [
    '$scope',
    '$rootScope',
    '$timeout',
    'settingsService',
    'settingsdata',
    function (
            $scope,
            $rootScope,
            $timeout,
            settingsService,
            settingsdata
            ) {
        $scope.settings = settingsdata;
        $rootScope.site_tit_cont = settingsdata.site_title;
        $rootScope.site_tags = settingsdata.site_tags;
        $rootScope.site_desc_cont = settingsdata.site_description;
        $scope.title = 'Settings';

        /* update settings */
        $scope.addSettingsData = function (chk_validations) {
            if (chk_validations === true) {
                return false;
            }
            var data = $scope.settings;
            $rootScope.loading = true;
            settingsService.toUpdateData(data, function (response) {
                $rootScope.loading = false;
                $rootScope.authSettings = true;
                if (response.data === 'success') {
                    $rootScope.settingsMessage = 'Settings Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                } else {
                    $rootScope.settingsMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.settingsMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.settingsMessage = '';
                $rootScope.authSettings = false;
            }, 7000);
        }
        /* end here */


        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authSettings = false;
        }
        /* end here */

        /* Custom Date */
        $scope.IsVisibleDate = false;
        $scope.customDate = function (value) {
            $scope.IsVisibleDate = value == '1';
        }
        /* end here */

        /* Custom Time */
        $scope.IsVisibleTime = false;
        $scope.customTime = function (value) {
            $scope.IsVisibleTime = value == '1';
        }
    }
]);