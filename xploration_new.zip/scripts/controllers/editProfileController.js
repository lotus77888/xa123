'use strict';

app.controller('editProfileCtrl', [
    '$scope',
    '$rootScope',
    '$timeout',
    '$state',
    'REGEX',
    'userdata',
    'URLS',
    'Upload',
    function (
            $scope,
            $rootScope,
            $timeout,
            $state,
            REGEX,
            userdata,
            URLS,
            Upload) {
        $scope.edit = userdata; // user data
        $scope.mobilePattern = REGEX.PHONE; // pattern for phone

        /* for checking image validations */
        $scope.chkValidations = function (media) {
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.sizeValiadtion = 'please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
                return;
            }

        }
        /* end here */

        /* to update logins user profile */
        $scope.toUpdateUser = function (chk_validations) {
            if (chk_validations === true) {
                return false;
            }
            $scope.upload($scope.edit);
        }

        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updateSubAdmindata',
                data: {file: post.profile_pic, data: post}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authProfile = true;
                if (response.data === 'success') {
                    $rootScope.profileMessage = 'Profile Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.profileMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.profileMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.profileMessage = '';
                $rootScope.authProfile = false;
            }, 7000);
        };
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authProfile = false;
        }
        /* end here */
    }
]);