'use strict';

app.controller('editShowCtrl', [
    '$scope',
    '$rootScope',
    '$filter',
    '$state',
    '$timeout',
    '$stateParams',
    'showData',
    'techexplorerdata',
    'Upload',
    'URLS',
    'mediaImages',
    'showsService',
    function (
            $scope,
            $rootScope,
            $filter,
            $state,
            $timeout,
            $stateParams,
            showData,
            techexplorerdata,
            Upload,
            URLS,
            mediaImages,
            showsService
            ) {
        $scope.shows = showData; // show data
        $scope.mediaImages = mediaImages;
        $scope.posturl = URLS.BASE_API;
        $scope.oldimg = $scope.posturl + '/uploads/mediauploads/images/' + showData.featured_image;
        if ($scope.shows.thumbnail_image != '') {
            $scope.shows.thumbnail_image = $scope.posturl + '/uploads/show_uploads/' + showData.thumbnail_image;
        }
        $scope.shows.file = $scope.posturl + '/uploads/show_uploads/' + showData.banner_image;
        $scope.xplorers = techexplorerdata; // xplorers data
        /* add more fields for seasons and watchlinks */
        $scope.seasons = [{season_name: ""}];
        $scope.addfield = function () {
            if ($scope.seasons[$scope.seasons.length - 1].show_xplorer_id !== undefined) {
                $scope.seasons.push({});
            } else {
                $scope.seasonValidationErrorMsg = "Please Enter Required Fileds"
            }
        }
        $scope.removefield = function (i) {
            $scope.seasons.splice(i, 1);
        }

        $scope.links = [{link_logo: "", watch_link: ""}];
        $scope.addlinksfield = function () {
            if (($scope.links.length - 1) != -1) {
                if ($scope.links[$scope.links.length - 1].watch_link !== undefined &&
                        $scope.links[$scope.links.length - 1].link_logo !== undefined) {
                    $scope.links.push({});
                } else {
                    $scope.validationErrorMsg = "Please Enter Required Fileds"
                }
            } else {
                $scope.links.push({});
            }


        }
        $scope.removelinksfield = function (i, id) {
            $scope.links.splice(i, 1);
            $rootScope.loading = true;
            showsService.toDeleteShowLinksData(id, function (res) {
                $rootScope.loading = false;
                if (res === "success") {

                } else if (res === "exist") {

                }
            }, function (err) {
                $rootScope.loading = false;
            });
        }
        /* end here */
        $scope.title = 'Edit Show' // title
        $scope.mode = false;
        $scope.seasons = showData.seasons;
        angular.forEach(showData.links, function (value, key) {
            value.link_logo = $scope.posturl + '/uploads/show_uploads/' + value.link_logo;
        });
        $scope.links = showData.links;

        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');
                $scope.oldimg = imgLink;
                $scope.shows.featured_image = img;
            }
        }
        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }


        /* for checking image validations */

        $scope.chkValidations = function (media) {
            $scope.imgValidataion = '';
            if (media !== null) {
                if (media !== undefined && media.type.search("image") === 0) {
                    var _URL = window.URL || window.webkitURL;
                    var file, img;
                    if ((file = media)) {
                        img = new Image();
                        img.onload = function () {
                            if (this.width == 1280 && this.height == 248) {
                                $scope.imgValidataion = '';
                                $scope.$digest();
                            } else {
                                $scope.imgValidataion = 'Image dimensions must be 1280X248';
                                $scope.$digest();
                                return;
                            }
                        };
                        img.src = _URL.createObjectURL(file);
                    }
                }
                if (media !== undefined && media.type.search("image") === -1) {
                    $scope.imgValidataion = 'please select image only';
                    return;
                }
                if (media !== undefined && media.size > 5000000) {
                    $scope.imgValidataion = 'file size must be lessthan 5 mb';
                    return;
                }
            }
        }

        /* Thumbnail Image */
        $scope.thumbnaiImageValidation = '';
        $scope.chkThumbnailImageValidations = function (media) {
            $scope.thumbnaiImageValidation = '';
            if (media === undefined || media === null) {
                return;
            }
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width == 300 && this.height == 250) {
                            $scope.thumbnaiImageValidation = '';
                            $scope.$digest();
                        } else {
                            $scope.thumbnaiImageValidation = 'Image dimensions must be 300X250';
                            $scope.$digest();
                            return;
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.thumbnaiImageValidation = 'please select image only';
                return;
            }
        }
        /* end */

        /* to upload watch links to database */
        $scope.sizeValiadtionImage = [];
        $scope.chkValidationsLinkImages = function (media, val, mdata) {
            if (media !== null) {
                if (media !== undefined && media.type.search("image") === -1) {
                    $('#chk_' + val).html('please select image only');
                    $scope.sizeValiadtionImage[val] = 1;
                    return;
                } else {
                    $scope.sizeValiadtionImage[val] = 0;
                    $('#chk_' + val).html('');
                    $scope.ImgMedia = media;
                    $scope.watchesF = $scope.links[val].watch_link;
                    addLinksToWatch($scope.ImgMedia, $scope.watchesF, mdata.show_watchlink_id);
                }
                if (media !== undefined && media.size > 2000000) {
                    $scope.sizeValiadtionImage[val] = 1;
                    $('#chk_' + val).html('file size must be lessthan 2 mb');
                    return;
                } else {
                    $scope.sizeValiadtionImage[val] = 0;
                    $('#chk_' + val).html('');
                    $scope.ImgMedia = media;
                    $scope.watchesF = $scope.links[val].watch_link;
                    addLinksToWatch($scope.ImgMedia, $scope.watchesF, mdata.show_watchlink_id);
                }

            }
        }

        $scope.chkWatchLinks = function (watchLink, index, wdata) {
            if ($scope.links[index].link_logo !== undefined) {
                $scope.ImgMedia = $scope.links[index].link_logo;
            }
            if ($scope.ImgMedia === undefined) {
                $scope.ImgMedia = $scope.links[index].link_logo;
            }
            $scope.watchesF = $scope.links[index].watch_link;
            addLinksToWatch($scope.ImgMedia, $scope.watchesF, wdata.show_watchlink_id);
        }

        function addLinksToWatch(media, watchLink, show_watch_id) {

            var f = _.filter($scope.sizeValiadtionImage, function (num) {
                if (num == 1) {
                    return num;
                }
            });

            if ((media !== undefined && (watchLink !== undefined && watchLink !== '')) && f.length === 0) {
                $scope.watchLinkUpload(media, watchLink, show_watch_id);
                $scope.watchesF = undefined;
                $scope.ImgMedia = undefined;
            }
        }
        $scope.watchLinkUpload = function (media, watchLink, show_watch_id) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updateOrAddWatchLinkUpload',
                data: {watchLink: watchLink, fimage: media, show_watch_id: show_watch_id, show_id: $stateParams.showId}
            }).then(function (response) {
                $rootScope.loading = false;
                if (response.data !== 'fail') {
                    angular.forEach(response.data, function (value, key) {
                        value.link_logo = $scope.posturl + '/uploads/show_uploads/' + value.link_logo;
                    });
                    $scope.links = response.data;
                } else {
                    console.log(response.data);
                }
            }, function (response) {
                $rootScope.loading = false;
            }, function (evt) {
                $rootScope.loading = false;
            });
        };

        /* end here */


        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authShow = false;
        }
        /* end here */

        /* to add new Show to database */
        $scope.addShowsData = function (chk_validations, featuredImage, imageValidation, description, thumbImage, errSlug, errShowName) {

            var f = _.filter($scope.sizeValiadtionImage, function (num) {
                if (num == 1) {
                    return num;
                }
            });
            if (chk_validations === true ||
                    (featuredImage === '' && featuredImage === undefined) ||
                    (imageValidation !== '' && imageValidation !== undefined) || f.length !== 0 || (thumbImage !== '' && thumbImage !== undefined)
                    || (errSlug !== '' && errSlug !== undefined) || (errShowName !== '' && errShowName !== undefined)) {
                return false;
            }
//            if (description < 14) {
//                return false;
//            }
            $scope.upload($scope.shows, $scope.links, $scope.seasons);
        }

        $scope.upload = function (show, links, seasons) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updateShowsData',
                data: {links: links, showdata: show, thumbnail_image: show.thumbnail_image, fimage: show.file, seasons: seasons}
            }).then(function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authShow = true;
                    $rootScope.showMessage = 'Show Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.shows');
                } else {
                    $rootScope.authShow = true;
                    $rootScope.showMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.authShow = true;
                $rootScope.showMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.showMessage = '';
                $rootScope.authShow = false;
            }, 7000);
        };
        /* end here */

        /* for slug */
        $scope.errorShowSluMsg = '';
        $scope.$watch('shows.show_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.shows.show_slug = '';
                return;
            }
            $scope.shows.show_slug = $filter('slugfilter')(new_value);
        });


        /* To Check Slug */
        $scope.$watch('shows.show_slug', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            var data = {
                showSlug: new_value,
                id: $scope.shows.show_id
            }
            showsService.toCheckSlug(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorShowSluMsg = '';
                } else {
                    $scope.errorShowSluMsg = 'Show Slug already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorShowSluMsg = 'Something Went Wrong!.. Please try again';
            });
        });
        /* end here */

        /* to Check Show Name*/
        $scope.errorShowName = '';
        $scope.toCheckShowName = function (showName) {
            if (showName === undefined) {
                return false;
            }
            var data = {
                id: $scope.shows.show_id,
                showName: showName
            }
            showsService.toCheckShowName(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorShowName = '';
                } else {
                    $scope.errorShowName = 'Show Name already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorShowName = 'Something Went Wrong!.. Please try again';
            });

        }


    }
]);