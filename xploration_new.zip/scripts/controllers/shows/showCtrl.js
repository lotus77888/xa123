'use strict';

angular.module('xplorationApp')
        .controller('showCtrl', [
            '$scope',
            '$rootScope',
            '$state',
            'showData',
            'showCount',
            'showsService',
            'newsletterService',
            'URLS',
            function (
                    $scope,
                    $rootScope,
                    $state,
                    showData,
                    showCount,
                    showsService,
                    newsletterService,
                    URLS
                    ) {
                var lmt = 9;
                var ofSet = 0;
                var _loadMore = 0;
                $scope.posturl = URLS.BASE_API;
                $scope.tShowData = $scope.nShowData = $scope.ntShowData = [];
                $scope.showData = [];

                if (showCount !== "fail") {
                    _loadMore = (parseInt(showCount) - 8) / lmt;
                    console.log(_loadMore);
                }

                $scope.loadMore = false;

                if (showData !== "fail") {
                    var idx = 3;
                    $scope.loadMore = true;
                    $scope.tShowData = showData.slice(0, idx);
                    $scope.ntShowData = showData.slice(idx, 5);
                    $scope.nShowData = showData.slice(idx+2);
                }

                if (_loadMore == 0 || 0 > _loadMore) {
                    $scope.loadMore = false;
                }
                var i = 0;
                $scope.toGetPostsData = function () {
                    i++;
                    if (i === 1) {
                        ofSet += 8;
                    } else {
                        ofSet += lmt;
                    }
                    $rootScope.loading = true;
                    showsService.toGetShowPublishData(lmt, ofSet, function (response) {
                        $rootScope.loading = false;
                        if (response !== "fail") {
                            $scope.nShowData = $scope.nShowData.concat(response);
                        }
                        if (_loadMore == 1 || (_loadMore > 0 && _loadMore < 1)) {
                            $scope.loadMore = false;
                        }
                        _loadMore -= 1;
                    }, function (data) {
                        console.log(data);
                    });
                }

                $scope.subscribe_submit = function (valid) {
                    var email = $scope.subscribe_email;
                    if (!valid) {
                        newsletterService.toInsert(email, function (res) {
                            if (res === "success") {
                                //$window.alert("You are scubscribed to newsletter successfully!!!");
                                $scope.subscribe_email = "";
                                $scope.subsceibe_form = false;
                                $scope.subscribe_success = "You are scubscribed to newsletter";
                            }
                        }, function (err) {
                            $scope.subscribe_success = "";
                            $scope.subscribe_success = "oops something went wrong please try again";
                        });
                    }
                }
                
                $scope.fullShowView = function(slug){
                    $state.go('home.show', {slug: slug});
                }

            }
        ]);