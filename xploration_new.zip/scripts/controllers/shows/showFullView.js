'use strict';

angular.module('xplorationApp')
        .controller('showViewCtrl', [
            '$scope',
            '$sce',
            '$state',
            '$stateParams',
            'URLS',
            'xplorererdata',
            'showdata',
            'seasondata',
            'showLinksdata',
            'showsService',
            'techexplorerService',
            function (
                    $scope,
                    $sce,
                    $state,
                    $stateParams,
                    URLS,
                    xplorererdata,
                    showdata,
                    seasondata,
                    showLinksdata,
                    showsService,
                    techexplorerService
                    ) {
                var offset = 0;
                var limit = 3;
                /* xplorer data start here */
                if (xplorererdata !== '') {
//                $scope.xplorererBySeasons = xplorerDataBySeasonId; // need to uncomment after dynamic
//                if ($scope.xplorererBySeasons === 'fail') { // need to uncomment after dynamic
                    $scope.xplorererBySeasons = xplorererdata;
                    $scope.xplorererBySeasons.description = $sce.trustAsHtml(xplorererdata.description);

//                } // need to uncomment after dynamic
                }
                /* xplorer data end here */

                /*  episodes seasons 1 data */
                if (seasondata.episodedata !== 'fail') {
                    angular.forEach(seasondata.episodedata, function (row, index) {
                        seasondata.episodedata[index].episode_description = $sce.trustAsHtml(row.episode_description);
                    });
                    $scope.episodes = seasondata.episodedata;
                    $scope.episodeCount = seasondata.episodeCount; // season 1 data count

                    $scope.loadMore = true;
                    var _loadMore = 0;
                    if (seasondata.episodeCount !== "fail") {
                        _loadMore = (parseInt(seasondata.episodeCount) - 3) / limit;
                    }
                    if (_loadMore == 0 || 0 > _loadMore) {
                        $scope.loadMore = false;
                    }
                }
                /* end here */
                /* to get episodes data by click on seasons */
                $scope.toGetEpisodeDataBySeasons = function (id) {
                    limit = 3;
                    offset = 0;
                    showsService.toGetEpisodeDataById(limit, offset, id, $stateParams.slug, function (data) {
                        if (data === 'fail') {
                            $scope.episodes = [];
                        } else {
                            $scope.episodes = data;
                        }
                    }, function (data) {
                        console.log(data);
                    });
                    showsService.toGetEpisodeDataCount(id, $stateParams.slug, function (response) {
                        if (response !== 'fail') {
                            $scope.episodeCount = response;
                            _loadMore = (parseInt(response) - 3) / limit;
                            if (_loadMore == 0 || 0 > _loadMore) {
                                $scope.loadMore = false;
                            } else {
                                $scope.loadMore = true;
                            }
                        } else {
                            $scope.loadMore = false;
                        }

                    }, function (data) {
                        console.log(data);
                    });

                    techexplorerService.toGetTexhxplorerDataBySeasonId(id, function (techxpldata) {
                        if (techxpldata !== 'fail') {
                            $scope.xplorererBySeasons = techxpldata;
                            $scope.xplorererBySeasons.description = $sce.trustAsHtml(techxpldata.description);
                        } else {
                            /* xplorer data start here */
                            $scope.xplorererBySeasons = xplorererdata;
                            $scope.xplorererBySeasons.description = $sce.trustAsHtml(xplorererdata.description);
                            /* xplorer data end here */
                        }

                    }, function (data) {
                        console.log(data);
                    });
                }
                /* end here */

                $scope.baseApi = URLS.BASE_API; // base url;

                /* to fetch show data */
                if (showdata !== '') {
                    $scope.showBase = 1;
                    $scope.show = showdata;
                    $scope.show.video = $sce.trustAsHtml(showdata.video);
                    $scope.show.show_description = $sce.trustAsHtml(showdata.show_description);
                } else {
                    $scope.showBase = 0;
                }
                /* end here */

                $scope.seasons = seasondata.seasondata; // seasons data;
                $scope.showlinks = showLinksdata; // links data

                /* loadmore records  code start here */
                $scope.toGetEpiosdesData = function (id) {
                    limit = 3;
                    offset += limit;
                    showsService.toGetEpisodeDataById(limit, offset, id, $stateParams.slug, function (data) {
                        if (data === 'fail') {
                            $scope.loadMore = false;

                        } else {
                            $scope.episodes = $scope.episodes.concat(data);
                            if (data.length < 3 || seasondata.episodeCount == $scope.episodes.length) {
                                $scope.loadMore = false;
                            }
                        }
                    }, function (data) {
                        $scope.episodes = [];
                    });

                }
                /* loadmore records end here */

                $scope.fullEpisodeView = function (slug) {
                    $state.go('home.episode', {slug: slug});
                }


            }
        ]);