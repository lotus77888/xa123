'use strict';

app.controller('addShowCtrl', [
    '$scope',
    '$rootScope',
    '$filter',
    '$state',
    '$timeout',
    'Upload',
    'URLS',
    'techexplorerdata',
    'mediaImages',
    'showsService',
    function (
            $scope,
            $rootScope,
            $filter,
            $state,
            $timeout,
            Upload,
            URLS,
            techexplorerdata,
            mediaImages,
            showsService
            ) {
        $scope.title = 'Add Show' // title
        $scope.mediaImages = mediaImages;
        $scope.posturl = URLS.BASE_API;
        $scope.mode = true;
        $scope.xplorers = techexplorerdata; // xplorers data
        $scope.shows = {};
        $scope.seasons = [{}];
        $scope.addfield = function () {
            $scope.seasons.push({});
        }
        $scope.removefield = function (i) {

            $scope.seasons.splice(i, 1);
        }

        $scope.links = [{link_logo: "", watch_link: ""}]; //
        $scope.addlinksfield = function () {
            $scope.links.push({});
        }
        $scope.removelinksfield = function (i) {
            $scope.links.splice(i, 1);
        }
        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');
                $scope.oldimg = imgLink;
                $scope.shows.featured_image = img;
            }
        }
        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }


        /* for checking image validations */
        $scope.chkValidations = function (media) {
            $scope.imgValidataion = '';
            if (media !== null) {
                if (media !== undefined && media.type.search("image") === 0) {
                    var _URL = window.URL || window.webkitURL;
                    var file, img;
                    if ((file = media)) {
                        img = new Image();
                        img.onload = function () {
                            if (this.width == 1280 && this.height == 248) {
                                $scope.imgValidataion = '';
                                $scope.$digest();
                            } else {
                                $scope.imgValidataion = 'Image dimensions must be 1280X248';
                                $scope.$digest();
                                return;
                            }
                        };
                        img.src = _URL.createObjectURL(file);
                    }
                }
                if (media !== undefined && media.type.search("image") === -1) {
                    $scope.imgValidataion = 'please select image only';
                    return;
                }
                if (media !== undefined && media.size > 5000000) {
                    $scope.imgValidataion = 'file size must be lessthan 5 mb';
                    return;
                }
            }
        }
        $scope.sizeValiadtionImage = [];
        $scope.chkValidationsLinkImages = function (media, val) {
            if (media !== null) {
                if (media !== undefined && media.type.search("image") === -1) {
                    $('#chk_' + val).html('please select image only');
                    $scope.sizeValiadtionImage[val] = 1;
                    return;
                } else {
                    $scope.sizeValiadtionImage[val] = 0;
                    $('#chk_' + val).html('');
                }
                if (media !== undefined && media.size > 2000000) {
                    $scope.sizeValiadtionImage[val] = 1;
                    $('#chk_' + val).html('file size must be lessthan 2 mb');
                    return;
                } else {
                    $scope.sizeValiadtionImage[val] = 0;
                    $('#chk_' + val).html('');
                }
            }
        }
        /* end here */

        /* Thumbnail Image */
        $scope.thumbnaiImageValidation = '';
        $scope.chkThumbnailImageValidations = function (media) {
            $scope.thumbnaiImageValidation = '';
            if (media === undefined || media === null) {
                return;
            }
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width == 300 && this.height == 250) {
                            $scope.thumbnaiImageValidation = '';
                            $scope.$digest();
                        } else {
                            $scope.thumbnaiImageValidation = 'Image dimensions must be 300X250';
                            $scope.$digest();
                            return;
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.thumbnaiImageValidation = 'please select image only';
                return;
            }
        }
        /* end */
        /* to add new Show to database */
        $scope.addShowsData = function (chk_validations, featuredImage, imageValidation, description, thumbImage, errSlug, errShowName) {
            var f = _.filter($scope.sizeValiadtionImage, function (num) {
                if (num == 1) {
                    return num;
                }
            });
            if (chk_validations === true ||
                    (featuredImage === '' && featuredImage === undefined) ||
                    (imageValidation !== '' && imageValidation !== undefined) || f.length !== 0 || (thumbImage !== '' && thumbImage !== undefined)
                    || (errSlug !== '' && errSlug !== undefined) || (errShowName !== '' && errShowName !== undefined)) {
                return false;
            }
//            if (description < 14) {
//                return false;
//            }
            $scope.upload($scope.shows, $scope.links, $scope.seasons);
        }

        $scope.upload = function (show, links, seasons) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addNewShow',
                data: {links: links, showdata: show, thumbnail_image: show.thumbnail_image, bimage: show.file, seasons: seasons}
            }).then(function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authShow = true;
                    $rootScope.showMessage = 'Show Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.shows');
                } else {
                    $rootScope.authShow = true;
                    $rootScope.showMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.authShow = true;
                $rootScope.showMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.showMessage = '';
                $rootScope.authShow = false;
            }, 7000);
        };
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authShow = false;
        }
        /* end here */


        /* for slug */
        $scope.errorShowSluMsg = '';
        $scope.$watch('shows.show_name', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.shows.show_slug = '';
                return;
            }
            $scope.shows.show_slug = $filter('slugfilter')(new_value);
        });


        /* To Check Slug */
        $scope.$watch('shows.show_slug', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            var data = {
                showSlug: new_value,
                id:''
            }
            showsService.toCheckSlug(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorShowSluMsg = '';
                } else {
                    $scope.errorShowSluMsg = 'Show Slug already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorShowSluMsg = 'Something Went Wrong!.. Please try again';
            });
        });
        /* end here */


        
        /* to Check Show Name*/
        $scope.errorShowName = '';
        $scope.toCheckShowName = function (showName) {
            if (showName === undefined) {
                return false;
            }
            var data = {
                showName: showName
            }
            showsService.toCheckShowName(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorShowName = '';
                } else {
                    $scope.errorShowName = 'Show Name already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorShowName = 'Something Went Wrong!.. Please try again';
            });

        }

    }
]);