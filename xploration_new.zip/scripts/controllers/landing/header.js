'use strict';

angular.module('xplorationApp')
        .controller('headerCtrl', [
            '$scope',
            '$location',
            'categoriesdata',
            'headerpagesdata',
            'URLS',
            function (
                    $scope,
                    $location,
                    categoriesdata,
                    headerpagesdata,
                    URLS
                    ) {
                $scope.categories = categoriesdata;
                $scope.headerpages = headerpagesdata;
                $scope.subscribeLetter = function () {
                    $location.hash('subscribe-letter');
                    // call $anchorScroll()
                    $anchorScroll();
                    angular.element('#sEmail').trigger('focus');
                }
                $scope.baseUrl = URLS.BASE_API;
            }
        ]);