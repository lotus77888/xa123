'use strict';

angular.module('xplorationApp')
        .controller('LandingCtrl', [
            '$scope',
            '$rootScope',
            '$state',
            '$window',
            'postData',
            'postCount',
            'postService',
            'newsletterService',
            'trendingPostData',
            'settingsData',
            'URLS',
            function (
                    $scope,
                    $rootScope,
                    $state,
                    $window,
                    postData,
                    postCount,
                    postService,
                    newsletterService,
                    trendingPostData,
                    settingsData,
                    URLS
                    ) {

                var lmt = 9;
                var ofSet = 0;
                var _loadMore = 0;
                $scope.site_url = settingsData.site_url;
                $scope.tPostData = $scope.nPostData = [];
                $scope.subscribe_success = "";
                $scope.base_path = URLS.BASE_API;
                $scope.trendingPostInfo = trendingPostData;//trending Post Data
                if (postCount !== "fail") {
                    _loadMore = (parseInt(postCount) - 10) / lmt;
                    console.log(_loadMore);
                }

                $scope.loadMore = false;

                if (postData !== "fail") {
                    var idx = 4;
                    $scope.loadMore = true;
                    $scope.tPostData = postData.slice(0, idx);
                    $scope.nPostData = postData.slice(idx);
                }

                if (_loadMore == 0 || 0 > _loadMore) {
                    $scope.loadMore = false;
                }

                var i = 0;
                $scope.toGetPostsData = function () {
                    i++;
                    if (i === 1) {
                        ofSet += 10;
                    } else {
                        ofSet += lmt;
                    }
                    $rootScope.loading = true;
                    postService.toGetPostPublishData(lmt, ofSet, 'N', function (response) {
                        $rootScope.loading = false;
                        if (response !== "fail") {
                            $scope.nPostData = $scope.nPostData.concat(response);
                        }
                        if (_loadMore == 1 || (_loadMore > 0 && _loadMore < 1)) {
                            $scope.loadMore = false;
                        }
                        _loadMore -= 1;
                    }, function (data) {
                        console.log(data);
                    });
                }

                $scope.fullPostView = function (slug) {
                    $state.go('home.post', {slug: slug});
                }

//                $scope.subscribe_submit = function (valid) {
//                    var email = $scope.subscribe_email;
//                    if (!valid) {
//                        newsletterService.toInsert(email, function (res) {
//                            if (res === "success") {
//                                //$window.alert("You are scubscribed to newsletter successfully!!!");
//                                $scope.subscribe_email = "";
//                                $scope.subsceibe_form = false;
//                                $scope.subscribe_success = "You are scubscribed to newsletter";
//                            }
//                        }, function (err) {
//                            $scope.subscribe_success = "";
//                            $scope.subscribe_success = "oops something went wrong please try again";
//                        });
//                    }
//                }

            }
        ]);