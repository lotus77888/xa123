'use strict';

angular.module('xplorationApp')
  .controller('footerCtrl', [
    '$scope',
    '$anchorScroll',
    '$location',
    'pagesdata',
    'URLS',
    function(
      $scope,
      $anchorScroll,
      $location,
      pagesdata,
      URLS
    ) {

      $scope.subscribeLetter = function(){
        $location.hash('subscribe-letter');
        // call $anchorScroll()
        $anchorScroll();
        angular.element('#sEmail').trigger('focus');
      }
      $scope.pages = pagesdata;
      $scope.baseUrl = URLS.BASE_API;
    }
  ]);