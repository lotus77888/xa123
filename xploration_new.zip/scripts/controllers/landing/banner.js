'use strict';

angular.module('xplorationApp')
        .controller('bannerCtrl', [
            '$scope',
            '$state',
            'bannerPostData',
            'URLS',
            function (
                    $scope,
                    $state,
                    bannerPostData,
                    URLS
                    ) {

                $scope.base_path = URLS.BASE_API;
                $scope.bannerData = bannerPostData;
                $scope.fullPostView = function (slug) {
                    $state.go('home.post', {slug: slug});
                }


            }
        ]);