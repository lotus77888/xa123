'use strict';

app.controller('changePwdCtrl', [
    '$scope',
    '$rootScope',
    '$timeout',
    'AuthenticationService',
    '$localStorage',
    function (
            $scope,
            $rootScope,
            $timeout,
            AuthenticationService,
            $localStorage
            ) {

        $scope.cpwd = {};
        $scope.cpwd.id = $localStorage.session.id; // login users id 

        /* to change password for login profile */
        $scope.changePassword = function (chk_validations, oldPwdChck) {

            if (chk_validations === true || oldPwdChck !== '') {
                return false;
            }
            var data = $scope.cpwd;
            $rootScope.loading = true;
            AuthenticationService.toUpdatePassword(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authPwd = true;
                    $rootScope.pwdMessage = 'Password changes successfully!..';
                    $rootScope.alertType = 'alert-success';
                } else {
                    $rootScope.authPwd = true;
                    $rootScope.pwdMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authPwd = true;
                $rootScope.pwdMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.pwdMessage = '';
                $rootScope.authPwd = false;
            }, 7000);

        }
        /* end here */

        /* checking existing password correct or not */
        $scope.chkUserExistingPassword = function (oldpwd) {
            var credentials = {
                id: $localStorage.session.id,
                password: oldpwd
            };
            AuthenticationService.chkUserExistingPassword(credentials, function (response) {

            }, function (response) {

            });

        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authPwd = false;
        }
        /* end here */




    }
]);