'use strict';

app.controller('episodesCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'episodesService',
    'episodesdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            episodesService,
            episodesdata
            ) {

        $scope.episodes = episodesdata;
        $scope.dropdown_val = 10;
        $scope.toEditEpisode = function (id) {
            $location.path('/acp/editepisode').search({episodeId: id});
        }

        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };

        $scope.toDeleteEpisode = function (val, id) {
            $rootScope.loading = true;
            episodesService.toDeleteData(id, function (response) {
                $rootScope.authEpisode = true;
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.episodeMessage = 'Episode Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.episodeMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.episodeMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.episodeMessage = '';
                $rootScope.authEpisode = false;
            }, 7000);
        }
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authEpisode = false;
        }
        /* end here */




    }
]);