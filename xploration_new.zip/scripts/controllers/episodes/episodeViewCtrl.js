'use strict';

angular.module('xplorationApp')
        .controller('episodeViewCtrl', [
            '$scope',
            '$rootScope',
            'episodeData',
            '$sce',
            '$state',
            '$stateParams',
            '$timeout',
            'URLS',
            'categoriesdata',
            'headerpagesdata',
            'trendingEpisodeData',
            'settingsData',
            'sideBarsData',
            'episodesService',
            function (
                    $scope,
                    $rootScope,
                    episodeData,
                    $sce,
                    $state,
                    $stateParams,
                    $timeout,
                    URLS,
                    categoriesdata,
                    headerpagesdata,
                    trendingEpisodeData,
                    settingsData,
                    sideBarsData,
                    episodesService
                    ) {
                $scope.site_url = settingsData.site_url;
                $scope.trendingEpisodeInfo = trendingEpisodeData;
                $scope.relatedEpisodes = episodeData.relEpisodeData;
                $scope.nextEpisodeData = episodeData.nextEpisodeData;
                $scope.sideBarData = sideBarsData; // sideBars Data
                $scope.episodeData = episodeData.episodeData;
                $scope.episodeData.video_tag = $sce.trustAsHtml(episodeData.episodeData.episode_video_tag)
                $scope.posturl = URLS.BASE_API;
                $scope.categories = categoriesdata;
                $scope.headerpages = headerpagesdata;

                $scope.fullEpisodeView = function (slug) {
                    $state.go('home.episode', {slug: slug});
                }

                /* Episode View Count Adding */
                episodesService.updateEpisodeViewCount($stateParams.slug, function (response) {
                    if (response.data === 'success') {
                        console.log('success');
                    } else {
                        console.log('fail');
                    }
                }, function (response) {
                    console.log(response);
                });
                /* end here */




            }
        ]);