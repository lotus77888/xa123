'use strict';

app.controller('editepisodeCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    '$filter',
    'Upload',
    'URLS',
    'AllKeywords',
    'episodesService',
    'episodesdata',
    'AllShows',
    'SeasonsByShow',
    'mediaImages',
    'FORMATS',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            $filter,
            Upload,
            URLS,
            AllKeywords,
            episodesService,
            episodesdata,
            AllShows,
            SeasonsByShow,
            mediaImages,
            FORMATS
            ) {

        $scope.episode = {};
        $scope.episode = episodesdata;
        $scope.posturl = URLS.BASE_API;
        $scope.mediaImages = mediaImages;
        $scope.oldimg = $scope.posturl + '/uploads/mediauploads/images/thumbnails_300_250/' + episodesdata.feature_image;
        $rootScope.authEpisode = false;
        $scope.title = 'Edit Episode';
        $scope.allshows = AllShows;
        $scope.seasons = SeasonsByShow;
        if ($scope.episode.thumbnail_image != '') {
            $scope.episode.thumbnail_image = $scope.posturl + '/uploads/episodes/' + episodesdata.thumbnail_image;
        }
        if (episodesdata.publish_end_date !== '0000-00-00') {
            $scope.publish_end_date = episodesdata.publish_end_date;
        }
        
        var currentDate = moment().format(FORMATS.DATETIME.ISO_SHORT_DATE);
        var cYr = parseInt(moment().format('YYYY'));

        $scope.dateOptions = {
            changeYear: true,
            changeMonth: true,
            minDate: new Date(episodesdata.publish_start_date),
            yearRange: cYr + ':' + (cYr + 10),
        };
        $scope.episode.publish_start_date = episodesdata.publish_start_date;
        $scope.$watch('episode.publish_start_date', function (new_value, old_value) {
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.endDateOptions = {
                changeYear: true,
                changeMonth: true,
                minDate: new_value,
                yearRange: '2013:' + (cYr + 10),
            };
        });

        $scope.$watch('publish_end_date', function (new_value, old_value) {
            if (new_value === undefined) {
                $scope.episode.publish_end_date = '';
            }
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.episode.publish_end_date = moment(new_value).format(FORMATS.DATETIME.ISO_SHORT_DATE);
        });

        /* image Selection */
        $scope.imageSelection = function (imgLink, img) {
            if ($rootScope._this !== undefined) {
                $rootScope.textAngularTools.insertImage.imgAction(imgLink);
            } else {
                $('#myModal').modal('toggle');
                $scope.oldimg = imgLink;
                $scope.episode.feature_image = img;
            }

        }

        $scope.featureImage = function () {
            $rootScope._this = undefined;
        }
        /* end */


        /* Date Validations */
        var currentDate = moment().format(FORMATS.DATETIME.ISO_SHORT_DATE);
        var cYr = parseInt(moment().format('YYYY'));

         $scope.dateOptions = {
            changeYear: true,
            changeMonth: true,
            yearRange: cYr + ':' + (cYr + 10),
        };
        $scope.episode.publish_start_date = currentDate;
        $scope.$watch('episode.publish_start_date', function (new_value, old_value) {
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.endDateOptions = {
                changeYear: true,
                changeMonth: true,
                minDate: new_value,
                yearRange: '2013:' + (cYr + 10),
            };
        });

        $scope.$watch('publish_end_date', function (new_value, old_value) {
            if (new_value === undefined) {
                $scope.episode.publish_end_date = '';
            }
            if (new_value === old_value || new_value === undefined) {
                return;
            }
            $scope.episode.publish_end_date = moment(new_value).format(FORMATS.DATETIME.ISO_SHORT_DATE);
        });
        /* end here */
        
        $scope.addEpisodeData = function (chk_validations, imageValidation, errSlug, thumbImage) {
            if (chk_validations === true || (imageValidation === '' && imageValidation === undefined) || (errSlug !== '' && errSlug !== undefined)|| (thumbImage !== '' && thumbImage !== undefined)) {
                return false;
            }
            $scope.upload($scope.episode);
        }
        /* end here */
        $scope.upload = function (post) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/updateEpisodeData',
//                data: {file: post.file, data: post}
                data: {file: post.feature_image, thumbnail_image: post.thumbnail_image,data: post}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authEpisode = true;
                if (response.data === 'success') {
                    $rootScope.episodeMessage = 'Episode Update Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.episodes');
                } else {
                    $rootScope.episodeMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.episodeMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.episodeMessage = '';
                $rootScope.authEpisode = false;
            }, 7000);
        };
        $scope.loadTags = function () {

            return AllKeywords;
        }

        /* for image validation */
        $scope.chkValidations = function (media) {
            if (media === undefined || media === null) {
                return;
            }
            $scope.imgValidataion = '';
            if (media !== undefined && media.type.search("image") === -1) {
                $scope.imgValidataion = 'please select image only';
                return;
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.imgValidataion = 'file size must be lessthan 2 mb';
                return;
            }
        }
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authEpisode = false;
        }
        /* end here */

        /* to get seasons by Show */

        $scope.showBySeasons = function (show_id) {
            episodesService.toGetSeasonsByShow(show_id, function (response) {
                if (response.data !== 'fail') {
                    $scope.seasons = response.data;
                } else {
                    $scope.seasons = [];
                }
            }, function (response) {
                $scope.seasons = [];
            });
            episodesService.toGetWatchlinksByShow(show_id, function (response) {
                if (response.data !== 'fail') {
                    $scope.episode.watchlinks = response.data;
                } else {
                    $scope.episode.watchlinks = [];
                }
            }, function (response) {
                $scope.episode.watchlinks = [];
            });
        }

        /* end here */



        /* slug */

        $scope.errorEpisodeSluMsg = '';
        $scope.$watch('episode.episode_title', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            if (new_value === undefined) {
                $scope.episode.episode_slug = '';
                return;
            }
            $scope.episode.episode_slug = $filter('slugfilter')(new_value);
        });


        /* To Check Slug */
        $scope.$watch('episode.episode_slug', function (new_value, old_value) {
            if (new_value === old_value) {
                return;
            }
            var data = {
                episodeSlug: new_value,
                id: $scope.episode.episode_id
            }
            episodesService.toCheckSlug(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorEpisodeSluMsg = '';
                } else {
                    $scope.errorEpisodeSluMsg = 'Episode Slug already exist!.. please try with another';
                }
            }, function (response) {
                $scope.errorEpisodeSluMsg = 'Something Went Wrong!.. Please try again';
            });
        });
        /* end here */
        
        
        /* Thumbnail Image */
        $scope.thumbnaiImageValidation = '';
        $scope.chkThumbnailImageValidations = function (media) {
            $scope.thumbnaiImageValidation = '';
            if (media === undefined || media === null) {
                return;
            }
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width == 270 && this.height == 150) {
                            $scope.thumbnaiImageValidation = '';
                            $scope.$digest();
                        } else {
                            $scope.thumbnaiImageValidation = 'Image dimensions must be 270X150';
                            $scope.$digest();
                            return;
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.thumbnaiImageValidation = 'please select image only';
                return;
            }
        }
        /* end */


    }
]);