'use strict';

app.controller('newsletterCtrl', [
    '$scope',
    'newsletterService',
    'newsletterdata',
    '$timeout',
    '$state',
    '$rootScope',
    '$location',
    function (
            $scope,
            newsletterService,
            newsletterdata,
            $timeout,
            $state,
            $rootScope,
            $location
            ) {
        $scope.newslettersNew = newsletterdata;
        $scope.newsletters = newsletterdata; // newsletter data
        $scope.newslettersTodos = [];
        $scope.totalItems = $scope.newsletters.length;
        $scope.searchNL = function (val) {
            if (val == undefined && val == '') {
                $scope.totalItems = $scope.newsletters.length;
            } else {
                searchCount(val);
            }
        }

        /* for search count */
        function searchCount(val) {
//            $rootScope.loading = true;
            newsletterService.forsearchCount(val, function (response) {
//                $rootScope.loading = false;
                if (response.data !== 'fail') {
                    newsletterdata = response.data;
                    $scope.totalItems = response.data.length;
                    $scope.$watch('currentPage + itemsPerPage', function () {
                        var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                        var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                        $scope.newslettersTodos = newsletterdata.slice(begin, end);
                        $scope.isAll = false
                        angular.forEach(newsletterdata, function (row, index) {
                            $scope.tableSelection[row.id] = false;
                        });
                        $scope.array = [];
                    });
                } else {
                    var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                    var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                    $scope.totalItems = $scope.newsletters.length;
                    $scope.postsTodos = $scope.newslettersNew.slice(begin, end);
                    $scope.$watch('currentPage + itemsPerPage', function () {
                        var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
                        var end = parseInt(begin) + parseInt($scope.itemsPerPage);
                        $scope.newslettersTodos = $scope.newslettersNew.slice(begin, end);
                        $scope.isAll = false
                        angular.forEach($scope.newslettersNew, function (row, index) {
                            $scope.tableSelection[row.id] = false;
                        });
                        $scope.array = [];
                    });
                }
            }, function (response) {
                $rootScope.loading = false;
            });
        }
        /* end here */
        $scope.itemsPerPage = 10;
        $scope.currentPage = 1;
        $scope.maxSize = 5;
        $scope.$watch('currentPage + itemsPerPage', function () {
            var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
            var end = parseInt(begin) + parseInt($scope.itemsPerPage);
            $scope.newslettersTodos = $scope.newslettersNew.slice(begin, end);
            $scope.isAll = false
            angular.forEach($scope.newslettersTodos, function (row, index) {
                $scope.tableSelection[row.id] = false;
            });
            $scope.array = [];
        });

        $scope.$watch('itemsPerPage', function () {
            var begin = (($scope.currentPage - 1) * $scope.itemsPerPage);
            var end = parseInt(begin) + parseInt($scope.itemsPerPage);
            $scope.newslettersTodos = $scope.newslettersNew.slice(begin, end);
            $scope.isAll = false
            angular.forEach($scope.newslettersTodos, function (row, index) {
                $scope.tableSelection[row.id] = false;
            });
            $scope.array = [];
        });

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */

        /* export data to csv */
        $scope.exportData = function () {
            alasql('SELECT * INTO CSV("newslettersubscription.csv",{headers:true}) FROM ?', [$scope.newsletters]);
        };
        /* end here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authNewsletter = false;
        }
        /* end here */

        /* to show particular data of admin user */
        $scope.toEditNewsletter = function (id) {
            $location.path('/acp/editnewsletter').search({id: id});
        }
        /* end here */

        /* to delete admin users */
        $scope.toDeleteNewsletter = function (val, id) {
            $rootScope.loading = true;
            newsletterService.toDeleteNewsletter(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authNewsletter = true;
                    $rootScope.newsletterMessage = 'Newsletter Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authNewsletter = true;
                    $rootScope.newsletterMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authNewsletter = true;
                $rootScope.newsletterMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.newsletterMessage = '';
                $rootScope.authNewsletter = false;
            }, 7000);
        }

        /* end here */

        /* select all  delete */
        $scope.array = [];
        $scope.isAll = false;
        $scope.tableSelection = {};

        $scope.selectAllRows = function () {
            if ($scope.isAll === false) {
                //set all row unselected
                angular.forEach($scope.newslettersTodos, function (row, index) {
                    $scope.tableSelection[row.id] = false;
                    if (index !== -1) {
                        $scope.array.splice(index, 1);
                    }
                });
                $scope.array = [];
            } else {
                $scope.array = [];
                //set all row selected
                angular.forEach($scope.newslettersTodos, function (row, index) {

                    $scope.tableSelection[row.id] = true;
                    var index = $scope.array.indexOf(row.id);
                    if (index === -1) {
                        $scope.array.push(row.id);
                    }
                });
            }

        };

        $scope.checkOnclick = function (index, id) {
            $scope.isAll = false;
            $scope.array = [];
            angular.forEach($scope.newslettersTodos, function (row, index) {
                if ($scope.tableSelection[row.id] == true) {
                    $scope.array.push(row.id);
                }
            });
        }
        /* delete selected rows */

        $scope.removeSelectedRows = function () {
            $rootScope.loading = true;
            newsletterService.toDeleteMultipleData($scope.array, function (response) {
                $rootScope.loading = false;
                $rootScope.authPost = true;
                if (response.data === 'success') {
                    $rootScope.postMessage = 'Post Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.postMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.postMessage = '';
                $rootScope.authPost = false;
            }, 7000);
        }

    }
]);