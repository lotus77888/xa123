'use strict';

app.controller('addnewsletterCtrl', [
    '$scope',
    '$rootScope',
    '$timeout',
    '$state',
    'REGEX',
    'newsletterService',
    'LISTS',
    function (
            $scope,
            $rootScope,
            $timeout,
            $state,
            REGEX,
            newsletterService,
            LISTS) {
        $scope.title = 'Add Newsletter';
        $scope.submit = 'Add';
//        $scope.errorEmailMsg = '';


        /* to add data into database */
        $scope.toAddNewsletterData = function (chk_validations, errMsg) {
            if (chk_validations === true || (errMsg !== '' && errMsg !== undefined)) {
                return false;
            }
            $rootScope.loading = true;
            var data = $scope.newsletters;
            newsletterService.toAddNewsletterData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authNewsletter = true;
                    $rootScope.newsletterMessage = 'Newsletter Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.newsletter');
                } else {
                    $rootScope.authNewsletter = true;
                    $rootScope.newsletterMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authNewsletter = true;
                $rootScope.newsletterMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.newsletterMessage = '';
                $rootScope.authNewsletter = false;
            }, 7000);
        }
        /* end here */

        /* to check email already exist or not */
        $scope.toCheckEmail = function () {
            if ($scope.newsletters.user_email !== undefined) {
                var data = {
                    email: $scope.newsletters.user_email,
                    id : $scope.newsletters.id
                };
                newsletterService.toCheckEmail(data, function (response) {
                    if (response.data == 'success') {
                        $scope.errorEmailMsg = '';
                    } else {
                        $scope.errorEmailMsg = 'Email Already Exist';
                    }
                }, function (response) {
                    $scope.errorEmailMsg = 'Email Already Registered';
                });
            }
        }
        /* end here */

        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authNewsletter = false;
        }
        /* end here */




    }
]);