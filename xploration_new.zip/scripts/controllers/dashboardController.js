'use strict';

app.controller('dashboardCtrl', [
    '$scope',
    'countdata',
    function (
            $scope,
            countdata) {

        $scope.dash = {};
        $scope.dash = countdata; // dashboard data
        console.log($scope.dash);



    }
]);