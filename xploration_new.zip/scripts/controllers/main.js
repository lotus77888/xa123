'use strict';

angular.module('xplorationApp')
  .controller('AppCtrl', [
    '$scope',
    '$state',
    '$localStorage',
    '$window',
    'AuthenticationService',
    'UserInfo',
    'Session',
    function(
      $scope,
      $state,
      $localStorage,
      $window,
      AuthenticationService,
      UserInfo,
      Session
    ) {

      // settings
      $scope.app = {
        name: 'xplorationApp',
        version: '1.0.0',
      }

      $scope.$watch(
        function() {
          return UserInfo.getUserInfo();
        },
        function(newValue, oldValue) {
          if (!newValue) {
            return;
          }
          
          $scope.currentUser = newValue;
        });

      // scope functions
      $scope.logout = function() {
        AuthenticationService.logout(function() {
          Session.destroy();
          console.log($localStorage.session);
          $state.go("access.login");
          
        });
      }

      $scope.cancel = function() {
        
      }
    }
  ]);