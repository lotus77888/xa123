'use strict';

app.controller('sidebarsCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'sidebarsService',
    'sidebarsdata',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            sidebarsService,
            sidebarsdata
            ) {

        $scope.sbData = sidebarsdata;
        $scope.dropdown_val = 10;

        /* Edit Post */
        $scope.toEditSidebar = function (id) {
            $location.path('/acp/editsidebars').search({id: id});
        }

        /* End here */

        /* Sort the Table Headings */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* End here */


        /* Delete page Data*/
        $scope.toDeleteSidebar = function (val, id) {
            $rootScope.loading = true;
            sidebarsService.toDeleteData(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authSidebar = true;
                $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.sidebarMess = '';
                $rootScope.authSidebar = false;
            }, 7000);
        }
        /* End here */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authSidebar = false;
        }
        /* end here */
    }
]);