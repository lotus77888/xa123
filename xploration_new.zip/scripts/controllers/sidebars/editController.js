'use strict';

app.controller('editsidebarsCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$filter',
    '$timeout',
    '$stateParams',
    'sidebarsService',
    'mediaImages',
    'sidebarsdata',
    'URLS',
    function (
            $scope,
            $rootScope,
            $state,
            $filter,
            $timeout,
            $stateParams,
            sidebarsService,
            mediaImages,
            sidebarsdata,
            URLS
            ) {
        $scope.mediaImages = mediaImages;
        $scope.sidebar = sidebarsdata;
        $scope.posturl = URLS.BASE_API;
        $scope.title = 'Edit Sidebar';
        $scope.errorPageMsg = '';
        $scope.selectOptionMessage = '';
        $scope.errorSluMsg = '';
        var id = '';
        if ($stateParams.pageId !== 'undefined') {
            id = $stateParams.pageId;
        }


        /* Edit Sidebars Data*/
        $scope.addSidebarData = function (chk_validations, SidebarMsg) {
            if (chk_validations === true || (SidebarMsg !== '' && SidebarMsg !== undefined)) {
                return false;
            }
            $rootScope.loading = true;
            var data = $scope.sidebar;
            sidebarsService.toAddSidebarData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Sidebar Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.sidebars');
                } else {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authSidebar = true;
                $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.sidebarMess = '';
                $rootScope.authSidebar = false;
            }, 7000);
        }
        /* End here */

        /* Image Selection */
        $scope.imageSelection = function (img) {
            $rootScope.textAngularTools.insertImage.imgAction(img);
        }
        /* end */

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authSidebar = false;
        }
        /* end here */
        
        /* to Check Sidebar Title */
        $scope.errorSidebarMsg = '';
        $scope.toCheckSidebarTitle = function (sidebarTitle) {
            if (sidebarTitle === undefined) {
                return false;
            }
            var data = {
                id: $scope.sidebar.id,
                sidebarTitle: sidebarTitle
            }
            sidebarsService.toCheckSidebarTitle(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorSidebarMsg = 'Sidebar Title already exist!.. please try with another';
                } else {
                    $scope.errorSidebarMsg = '';
                }
            }, function (response) {
                $scope.errorSidebarMsg = 'Something Went Wrong!.. Please try again';
            });

        }
        /* end */

    }
]);