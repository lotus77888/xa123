'use strict';

app.controller('addsidebarsCtrl', [
    '$scope',
    '$rootScope',
    '$filter',
    '$state', 
    '$timeout',
    'sidebarsService',
    'Upload',
    'URLS',
    'mediaImages',
    function (
            $scope,
            $rootScope,
            $filter,
            $state,
            $timeout,
            sidebarsService,
            Upload,
            URLS,
            mediaImages
            ) {
        $scope.title = 'Add Sidebar';
        $scope.mediaImages = mediaImages;
        $scope.posturl = URLS.BASE_API;

        $scope.imageSelection = function (img) {
            $rootScope.textAngularTools.insertImage.imgAction(img);
        }
          
        /* Add Sidebars Data*/
        $scope.addSidebarData = function (chk_validations, SidebarMsg) {
            if (chk_validations === true || (SidebarMsg !== '' && SidebarMsg !== undefined)) {
                return false;
            }
            $rootScope.loading = true;
            var data = $scope.sidebar;
            sidebarsService.toAddSidebarData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Sidebar Added Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.sidebars');
                } else {
                    $rootScope.authSidebar = true;
                    $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authSidebar = true;
                $rootScope.sidebarMess = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.sidebarMess = '';
                $rootScope.authSidebar = false;
            }, 7000);
        }
        /* End here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authSidebar = false;
        }
        /* end here */
        
        /* to Check Sidebar Title */
        $scope.errorSidebarMsg = '';
        $scope.toCheckSidebarTitle = function (sidebarTitle) {
            if (sidebarTitle === undefined) {
                return false;
            }
            var data = {
                sidebarTitle: sidebarTitle
            }
            sidebarsService.toCheckSidebarTitle(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorSidebarMsg = 'Sidebar Title already exist!.. please try with another';
                } else {
                    $scope.errorSidebarMsg = '';
                }
            }, function (response) {
                $scope.errorSidebarMsg = 'Something Went Wrong!.. Please try again';
            });

        }
        /* end */
    }
]);