'use strict';

app.controller('custompagesCtrl', [
    '$scope',
    '$rootScope',
    '$sce',
    'custompagedata',
    'newsletterService',
    'settingsData',
    'sideBarsData',
    function (
            $scope,
            $rootScope,
            $sce,
            custompagedata,
            newsletterService,
            settingsData,
            sideBarsData
            ) {
        if (custompagedata !== '') {
            $scope.pageData = custompagedata;
            $scope.pageData.page_description = $sce.trustAsHtml(custompagedata.page_description);
        }

        $scope.sideBarData = sideBarsData;

//        angular.element('h5').click(function () {
//            alert("fasdfafs");
//        });

        /* contest form cantact Email */

        $scope.subsceibe_form = function (email) {
//            console.log(email);return;
            var emailId = email;
            if (emailId === undefined || emailId == '') {
                angular.element('#emailId').html('<span class="help-block text-danger">Please enter email</span>');
            } else {
//                console.log('ddd');return;
                var atpos = emailId.indexOf("@");
                var dotpos = emailId.lastIndexOf(".");
                if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailId.length) {
                    angular.element('#emailId').html('<span class="help-block text-danger">Please enter a valid email</span>');
                } else {
                    $rootScope.loading = true;
                    console.log(emailId);
                    newsletterService.contestContactInfo(emailId, function (res) {
                        $rootScope.loading = false;
                        if (res === "success") {
                            angular.element('#emailId').html('<span class="help-block text-success">You are subscribed Successfully</span>');
//                            angular.element('.contest_text').val(' ');
                            $scope.emailContest = "";
                        } else if (res === "exist") {
                            angular.element('#emailId').html('<span class="help-block text-danger">Email Already Subscribed</span>');
//                            angular.element('.contest_text').val(' ');
                            $scope.emailContest = "";
                        }
                    }, function (err) {
                        angular.element('#emailId').html('<span class="help-block text-danger">oops something went wrong please try again</span>');
                    });
                }
            }
        };

        $scope.subsceibe_form_response = function (email) {
            var emailId_res = email;
            if (emailId_res === undefined || emailId_res == '') {
                angular.element('#emailId_res').html('<span class="help-block text-danger">Please enter email</span>');
            } else {
                var atpos = emailId_res.indexOf("@");
                var dotpos = emailId_res.lastIndexOf(".");
                if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailId_res.length) {
                    angular.element('#emailId_res').html('<span class="help-block text-danger">Please enter a valid email</span>');
                } else {
                    $rootScope.loading = true;
                    newsletterService.contestContactInfo(emailId_res, function (res) {
                        $rootScope.loading = false;
                        if (res === "success") {
                            angular.element('#emailId_res').html('<span class="help-block text-success">You are subscribed Successfully</span>');
                            angular.element('.contest_text').val(' ');
                        } else if (res === "exist") {
                            angular.element('#emailId_res').html('<span class="help-block text-danger">Email Already Subscribed</span>');
                            angular.element('.contest_text').val(' ');
                        }
                    }, function (err) {
                        angular.element('#emailId_res').html('<span class="help-block text-danger">oops something went wrong please try again</span>');
                    });
                }
            }
        };
        /* end */

        /* Subscribe form Email */
//        $scope.newsletter = {};
//        $scope.subscribe_success = "";
//        $scope.subscribe_submit = function (valid) {
//            var email = $scope.newsletter.subscribe_email;
//            if (!valid) {
//                $rootScope.loading = true;
//                newsletterService.toInsert(email, function (res) {
//                    $rootScope.loading = false;
//                    if (res === "success") {
//                        //$window.alert("You are scubscribed to newsletter successfully!!!");
//                        $scope.newsletter.subscribe_email = "";
//                        $scope.newsletter.subscribe_form = false;
//                        $scope.subscribe_success = "You are scubscribed to newsletter";
//                    } else if (res === "exist") {
//                        $scope.newsletter.subscribe_email = "";
//                        $scope.newsletter.subscribe_form = false;
//                        $scope.subscribe_success = "Email Already Subscribed";
//                    }
//                }, function (err) {
//                    $scope.subscribe_success = "";
//                    $scope.subscribe_success = "oops something went wrong please try again";
//                });
//            }
//        }
        /* end */
    }
]);

app.directive('compileTemplate', function ($compile, $parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            var parsed = $parse(attr.ngBindHtml);

            //Recompile if the template changes
            scope.$watch(
                    function () {
                        return (parsed(scope) || '').toString();
                    },
                    function () {
                        $compile(element, null, -9999)(scope);  //The -9999 makes it skip directives so that we do not recompile ourselves
                    }
            );
        }
    };
});