'use strict';

app.controller('LoginCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    'AuthenticationService',
    'MESSAGES',
    'REGEX',
    function (
            $scope,
            $rootScope,
            $state,
            AuthenticationService,
            MESSAGES,
            REGEX) {

        $scope.login = {
            processing: false,
        };

        $scope.emailPattern = REGEX.EMAIL;
        // Scope functions
        $scope.doLogin = function (chk_validations) {
            console.log($scope.login.processing)
            if (chk_validations === true) {
                return false;
            }
            $scope.login.error = null;
//            $scope.login.processing = true;
            

            var credentials = {
                email: $scope.login.email,
                password: $scope.login.password
            };
            $rootScope.loading = true;
            AuthenticationService.login(credentials, function () {
                $rootScope.loading = false;
//                $scope.login.processing = false;
                $state.go('home.app.dashboard');
            }, function (errorResponse) {
                $rootScope.loading = false;
//                $scope.login.processing = false;
                var statusCode = errorResponse.status;
                var errorMessage;
                switch (statusCode) {
                    case 401:
                        errorMessage = MESSAGES.LOGIN.INVALID_CREDENTIALS;
                        break;
                    default:
                        errorMessage = 'Error occurred';
                        break;
                }

                $scope.login.error = errorMessage;
            });
        }


    }
]);