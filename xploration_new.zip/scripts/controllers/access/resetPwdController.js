'use strict';

app.controller('resetPwdCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    'AuthenticationService',
    'userdata',
    function (
            $scope,
            $rootScope,
            $state,
            AuthenticationService,
            userdata) {


        $scope.confirm = {};
        $scope.confirm.email = userdata.email;
        $scope.confirm.id = userdata.id;
        $scope.toUpdatePassword = function (chk_validations) {
            if (chk_validations === true) {
                return false;
            }
            var data = $scope.confirm;
            AuthenticationService.toUpdatePassword(data, function (response) {
                if (response.data == 'success') {
                    $rootScope.authSuccess = true;
                    $rootScope.successMessage = 'Success! Password Updated Successfully!..';
                    $state.go("access.login");
                } else {
                    $rootScope.authError = true;
                    $rootScope.errorMessage = 'Something Went Wrong!.. Please try again';
                }
            }, function (response) {
                    $rootScope.authError = true;
                    $rootScope.errorMessage = 'Something Went Wrong!.. Please try again';
            });
        }




    }
]);