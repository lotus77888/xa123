'use strict';

app.controller('forgetPwdCtrl', [
    '$scope',
    '$rootScope',
    'AuthenticationService',
    function (
            $scope,
            $rootScope,
            AuthenticationService
            ) {


        $scope.forgetPwd = function (email, emailValidation) {
            if (emailValidation !== '') {
                return;
            }
            $rootScope.loading = true;
            AuthenticationService.forgetPassword(email, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $scope.sucessMsg = 'Password reset link has been sent to your email';
                    $scope.alertType = 'alert-success';
                    $scope.authForgetPwd = true;
                } else {
                    $scope.sucessMsg = 'Something went wrong!.. please try again';
                    $scope.alertType = 'alert-danger';
                    $scope.authForgetPwd = true;
                }

            }, function (response) {
                $rootScope.loading = false;
                $scope.sucessMsg = 'Something went wrong!.. please try again';
                $scope.alertType = 'alert-danger';
                $scope.authForgetPwd = true;
            });


        }

        /* to check email already exist or not */

        $scope.chckUser = function (email) {
            AuthenticationService.checkingUser(email, function (response) {
                if (response.data === 'fail') {
                    $scope.errorEmailMsgforget = 'Email does not exist';
                } else {
                    $scope.errorEmailMsgforget = '';
                }

            }, function (response) {
                $scope.errorEmailMsgforget = 'Something went wrong!.. please try again';
            });
        }


        /* to close alert */
        $scope.closeAlert = function () {
            $scope.authForgetPwd = false;
        }
        /* end here */





    }
]);