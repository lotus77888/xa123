'use strict';

app.controller('editMediaCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$timeout',
    'mediaService',
    'mediaData',
    'URLS',
    'Upload',
    function (
            $scope,
            $rootScope,
            $state,
            $timeout,
            mediaService,
            mediaData,
            URLS,
            Upload
            ) {
        $scope.media = mediaData;
        $scope.posturl = URLS.BASE_API;
        $scope.media.media_url = $scope.posturl + '/uploads/mediauploads/images/thumbnails_300_250/' + mediaData.media_url;
        $scope.title = 'Edit Media'
        $scope.editMedia = false;
        $scope.documentUrl = URLS.BASE_API + '/uploads/document.jpg';
        $scope.otherUrl = URLS.BASE_API + '/uploads/other.jpg';

        $scope.toChangeMes = function(val){
            if(val ===undefined){
                $scope.sizeValiadtion = '';
            }
        }

        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authMedia = false;
        }
        /* end here */

//        /* Image Validation */
//        $scope.sizeValiadtion = '';
//        $scope.chkValidations = function (media) {
//            
//            $scope.sizeValiadtion = '';
//            if (media !== undefined && media.type.search("image") === 0) {
//                var _URL = window.URL || window.webkitURL;
//                var file, img;
//                if ((file = media)) {
//                    img = new Image();
//                    img.onload = function () {
//                        if (this.width < 300 && this.height < 250) {
//                            $scope.sizeValiadtion = 'Image dimensions must be greater than 300X250';
//                            $scope.$digest();
//                            return;
//                        } else {
//                            $scope.sizeValiadtion = '';
//                            $scope.$digest();
//                        }
//                    };
//                    img.src = _URL.createObjectURL(file);
//                }
//            }
//            if (media !== undefined && media.size > 2000000) {
//                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
//            }
//        }
//        /* end here */
        $scope.chkValidations = function (media, type) {
            if (media !== undefined && media !== '' && media !== null) {
                if (type === 'I') {
                    chkImageValidation(media);
                } else if (type === 'V') {
                    chkVideoValidation(media);
                } else if (type === 'A') {
                    chkAudioValidation(media);
                } else if (type === 'D') {
                    chkDocumentValidation(media);
                }
            }
        }

        /* to check image validations */
        function chkImageValidation(media) {
//                console.log(media);return;
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("image") === 0) {
                var _URL = window.URL || window.webkitURL;
                var file, img;
                if ((file = media)) {
                    img = new Image();
                    img.onload = function () {
                        if (this.width < 300 || this.height < 250) {
                            $scope.sizeValiadtion = 'Image dimensions must be greater than 300X250';
                            $scope.$digest();
                            return;
                        } else {
//                            $scope.sizeValiadtion = '';
                            $scope.$digest();
                        }
                    };
                    img.src = _URL.createObjectURL(file);
                }
            } else {
                $scope.sizeValiadtion = "Please Select Images Only";
            }
            if (media !== undefined && media.size > 2000000) {
                $scope.sizeValiadtion = 'file size must be lessthan 2 mb';
            }
        }
        /* end here */

        /* to check video Validations */
        function chkVideoValidation(media) {
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("video") === 0) {
                if (media !== undefined && media.size > 2000000) {
                    $scope.sizeValiadtion = 'Video size must be lessthan 2 mb';
                    return;
                }
            } else {
                $scope.sizeValiadtion = "Please Select Video Only";
            }
        }
        /* end */
        /* to check Audio Validations */
        function chkAudioValidation(media) {
            $scope.sizeValiadtion = '';
            if (media !== undefined && media.type.search("audio") === 0) {
                if (media !== undefined && media.size > 2000000) {
                    $scope.sizeValiadtion = 'Audio size must be lessthan 2 mb';
                    return;
                }
            } else {
                $scope.sizeValiadtion = "Please Select Audio Only";
            }
        }
        /* end */

        /* to check Document Validations */
        function chkDocumentValidation(media) {
            var ext = media.name.split('.');
            var doc = ['doc', 'docx', 'pdf', 'txt', 'rtf', 'DOC', 'DOCX', 'PDF', 'TXT', 'RTF'];
            var val = doc.indexOf(ext[1]);
            if (val !== -1) {
                $scope.sizeValiadtion = '';
                if (media !== undefined && ((media.type.search("application") === 0) || (media.type.search("text") === 0) || (media.type.search("") === 0))) {
                    if (media !== undefined && media.size > 2000000) {
                        $scope.sizeValiadtion = 'Document size must be lessthan 2 mb';
                    }
                } else {
                    $scope.sizeValiadtion = "Please Select  Documents Only";
                }
            } else {
                $scope.sizeValiadtion = "Please Select  doc,pdf,txt and rtf Only";
            }
        }
        /* end */
        
        /* update existing user to database */
        $scope.addMediaData = function (chk_validations, sizeValidation ) {
            if (chk_validations === true || (sizeValidation !== '' && sizeValidation !== undefined)) {
               return false;
            }
            $scope.upload($scope.media);
        }


        // upload on file select or drop
        $scope.upload = function (media) {
            $rootScope.loading = true;
            Upload.upload({
                url: URLS.BASE_API + '/addNewMedia',
                data: {file: media.media_url, 'status': media.status, 'id': media.id, 'media_title': media.media_title, 'media_type': media.media_type}
            }).then(function (response) {
                $rootScope.loading = false;
                $rootScope.authMedia = true;
                if (response.data === 'success') {
                    $rootScope.mediaMessage = 'Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.media');
                } else {
                    $rootScope.mediaMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
                //console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
            }, function (response) {
                $rootScope.loading = false;
                //console.log('Error status: ' + resp.status);
                $rootScope.mediaMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            }, function (evt) {
                //var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
            });
            $timeout(function () {
                $rootScope.mediaMessage = '';
                $rootScope.authMedia = false;
            }, 7000);
        };
        /* end here */



    }
]);