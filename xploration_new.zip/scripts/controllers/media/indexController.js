'use strict';

app.controller('mediaCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$location',
    '$timeout',
    'mediaService',
    'mediadata',
    'URLS',
    function (
            $scope,
            $rootScope,
            $state,
            $location,
            $timeout,
            mediaService,
            mediadata,
            URLS
            ) {

        $scope.medias = mediadata;
        $scope.posturl = URLS.BASE_API;
        $scope.dropdown_val = 10;
        $scope.documentUrl = URLS.BASE_API+'/uploads/document.jpg';
        $scope.otherUrl = URLS.BASE_API + '/uploads/other.jpg';
        $scope.toEditMedia = function (id) {
            $location.path('/acp/editmedia').search({mediaId: id});
        }

        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        
        /* to delete media files */
        $scope.toDeleteMedia = function (val, id) {
            $rootScope.loading = true;
            mediaService.toDeleteData(id, function (response) {
                $rootScope.loading = false;
                $rootScope.authMedia = true;
                if (response.data === 'success') {
                    $rootScope.mediaMessage = 'Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.mediaMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.mediaMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.mediaMessage = '';
                $rootScope.authMedia = false;
            }, 7000);
        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authMedia = false;
        }
        /* end here */




    }
]);