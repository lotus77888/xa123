'use strict';

app.controller('contactsCtrl', [
    '$scope',
    'contactsdata',
    function (
            $scope,
            contactsdata
            ) {
        $scope.contacts = contactsdata; // contacts data
        $scope.dropdown_val = 10; // default records to show in manage page

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };
        /* end here */

    }
]);