'use strict';

app.controller('editUserCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    '$stateParams',
    '$timeout',
    'UserService',
    'userdata',
    'REGEX',
    function (
            $scope,
            $rootScope,
            $state,
            $stateParams,
            $timeout,
            UserService,
            userdata,
            REGEX
            ) {

        $scope.user = userdata;
        $scope.user.password = '';
        $scope.mobilePattern = REGEX.PHONE; // pattern for phone
        $scope.emailPattern = REGEX.EMAIL; // pattern for email
        $scope.subTitle = 'Edit User'; // title
        var id = '';
        if ($stateParams.userId !== 'undefined') {
            id = $stateParams.userId;
        }
        $scope.showPassword = false; //password valdiation in addform
        $scope.errorEmailMsg = '';

        /* update existing user to database */
        $scope.toAddNewUser = function (chk_validations, email_validataion) {
            if (chk_validations === true || email_validataion !== '') {
                return false;
            }
            var data = $scope.user;
            $rootScope.loading = true;
            UserService.toUpdateUserData(data, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authUser = true;
                    $rootScope.userMessage = 'User Updated Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.go('home.app.users');
                } else {
                    $rootScope.authUser = true;
                    $rootScope.userMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authUser = true;
                $rootScope.userMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.userMessage = '';
                $rootScope.authUser = false;
            }, 7000);
        }
        /* end here */

        /* check useremail already exist or not */
        $scope.toCheckUserEmail = function (emailAddress) {
            if (emailAddress === undefined) {
                return false;
            }
            var data = {
                id: id,
                email: emailAddress
            }
            UserService.toCheckUserEmail(data, function (response) {
                if (response.data === 'fail') {
                    $scope.errorEmailMsg = '';
                } else {
                    $scope.errorEmailMsg = 'User already exist!.. please try with another email';
                }
            }, function (response) {
                $scope.errorMessage = 'Something Went Wrong!.. Please try again';
            });

        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authUser = false;
        }
        /* end here */




    }
]);