'use strict';

app.controller('usersCtrl', [
    '$scope',
    '$rootScope',
    '$location',
    '$state',
    '$timeout',
    'usersdata',
    'UserService',
    function (
            $scope,
            $rootScope,
            $location,
            $state,
            $timeout,
            usersdata,
            UserService) {

        $scope.users = usersdata; // users data
        $scope.dropdown_val = 10; //default records to show in manage page

        /* to view data of user by uisng Id */
        $scope.toEditUser = function (id) {
            $location.path('/acp/edituser').search({userId: id});
        }
        /* end here */

        /* sorting the data in datatable */
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        };

        /* end here */

        /* to delete user */
        $scope.toDeleteUser = function (val, id) {
            $rootScope.loading = true;
            UserService.toDeleteUser(id, function (response) {
                $rootScope.loading = false;
                if (response.data === 'success') {
                    $rootScope.authUser = true;
                    $rootScope.userMessage = 'User Deleted Successfully!..';
                    $rootScope.alertType = 'alert-success';
                    $state.reload();
                } else {
                    $rootScope.authUser = true;
                    $rootScope.userMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authUser = true;
                $rootScope.userMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.userMessage = '';
                $rootScope.authUser = false;
            }, 7000);
        }
        /* end here */
        
        /* to close alert */
        $scope.closeAlert = function () {
            $rootScope.authUser = false;
        }
        /* end here */

    }
]);
