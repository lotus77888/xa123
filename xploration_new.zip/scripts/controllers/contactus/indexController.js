'use strict';

app.controller('contactusCtrl', [
    '$scope',
    'REGEX',
    'contactsService',
    '$timeout',
    '$rootScope',
    function (
            $scope,
            REGEX,
            contactsService,
            $timeout,
            $rootScope
            ) {
        $scope.mobilePattern = REGEX.PHONE;
        
        $scope.toSendContactUsEmail = function (chk_validations, contactusForm) {
            if (chk_validations === true) {
                return false;
            }
            var data = $scope.contactus;
            contactsService.toSendEmailData(data, function (response) {
                if (response.data === 'success') {
                    $rootScope.authContact = true;
                    $rootScope.contactUsMessage = 'Your Mail was sent successfully. Thanks.';
                    $rootScope.alertType = 'alert-success';
                    $scope.contactus = {};
                    $scope.sendContactUs = false;
                    contactusForm.$setPristine();
                    contactusForm.$setUntouched();
                    contactusForm.$setDirty();
                } else {
                    $rootScope.authContact = true;
                    $rootScope.contactUsMessage = 'Something Went Wrong!.. Please try again';
                    $rootScope.alertType = 'alert-danger';
                }
            }, function (response) {
                $rootScope.loading = false;
                $rootScope.authContact = true;
                $rootScope.contactUsMessage = 'Something Went Wrong!.. Please try again';
                $rootScope.alertType = 'alert-danger';
            });
            $timeout(function () {
                $rootScope.contactUsMessage = '';
                $rootScope.authContact = false;
            }, 7000);
        }

        $scope.closeAlert = function () {
            $rootScope.authContact = false;
        }

    }
]);