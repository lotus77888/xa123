app.controller('FileUploadCtrl', ['$scope','notification', 'FileUploader', 'URLS', 'Restangular', 'Upload', '$rootScope', function($scope, notification, FileUploader, URLS, Restangular, Upload, $rootScope) {
    var uploader = $scope.uploader = new FileUploader({
        //url: 'js/controllers/upload.php'
        url: URLS.BASE_API+'/upload_orders',
        //autoUpload: true
    });
    console.log("uploader", uploader);
    // FILTERS

    uploader.filters.push({
        name: 'customFilter',
        fn: function(item /*{File|FileLikeObject}*/, options) {
            return this.queue.length < 10;
        }
    });

    // CALLBACKS

    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.info('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.info('onAfterAddingFile', fileItem._file);
        fileItem._file.upload = Upload.upload({
            url: URLS.BASE_API+'/upload_orders',
            method: 'POST',
            fields: {
                categorydata: 'asdasd'
            },
            file: fileItem._file
        });

        fileItem._file.upload.then(function (response) {
            $rootScope.showDipatchedOrders = false;
            var batchOrders = response.data.data;
            $rootScope.batchOrders = [];

            if(batchOrders[0] != undefined) {                      
              $rootScope.batchOrders = batchOrders[0].orders; 
              //$rootScope.$apply();
            }      
            if(batchOrders[0].records_not_found != undefined) {                 
                $rootScope.failedOrders = batchOrders[0].records_not_found;
            }
            if(batchOrders[0].file == 'invalid') {                 
                var errors = [];
                notification.notifyErrors('Invalid File !',errors);
            }                
        }, function (response) {
        if (response.status > 0)
            $scope.errorMsg = response.status + ': ' + response.data;
        });
         
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.info('onAfterAddingAll', addedFileItems);
    };
    uploader.onBeforeUploadItem = function(item) {
        console.info('onBeforeUploadItem', item);
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.info('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.info('onProgressAll', progress);
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.info('onSuccessItem', fileItem, response, status, headers);
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.info('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.info('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.info('onCompleteItem', fileItem, response, status, headers);
    };
    uploader.onCompleteAll = function() {
        console.info('onCompleteAll');
    };

    //console.info('uploader', uploader);
    console.info('uploader', URLS.BASE_API);
}]);