'use strict';
/**
 * Config for the router
 */
app.run([
    '$rootScope',
    '$state',
    '$stateParams',
    function ($rootScope, $state, $stateParams) {
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
//        console.log("run : router");
    }
])
        .config([
            '$stateProvider',
            '$urlRouterProvider',
            'MODULE_CONFIG',
            '$locationProvider',
            function (
                    $stateProvider,
                    $urlRouterProvider,
                    MODULE_CONFIG,
                    $locationProvider
                    ) {
//                $locationProvider.html5Mode({
//                    enabled: true,
//                    requireBase: false
//                });
                $locationProvider.html5Mode(true).hashPrefix('!'); // this is for to removing the hash symbol in url
                var layout = 'views/app.html';
                $urlRouterProvider.otherwise(function ($injector) {
                    var $state = $injector.get("$state");
                    $state.go('home.index');
                });
                $stateProvider

                        //home
                        .state('home', {
                            url: '',
                            abstract: true,
                            templateUrl: 'views/blocks/index.html'
                        })
                        .state('home.index', {
                            url: '/',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'banner': {
                                    templateUrl: 'views/landing/banner.html',
                                    controller: 'bannerCtrl',
                                    resolve: {
                                        bannerPostData: function (postService, $q) {
                                            var def = $q.defer();
                                            var lmt = 10;
                                            var ofSet = 0;
                                            postService.toGetPostPublishData(lmt, ofSet, 'Y', function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/landing/index.html',
                                    controller: 'LandingCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        postData: function (postService, $q) {
                                            var def = $q.defer();
                                            var lmt = 10;
                                            var ofSet = 0;
                                            postService.toGetPostPublishData(lmt, ofSet, 'N', function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        postCount: function (postService, $q) {
                                            var def = $q.defer();
                                            postService.toGetPostPublishCount(function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        trendingPostData: function (postService, $q) {
                                            var def = $q.defer();
                                            postService.getTrendingPostData(function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }

                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.post', {
                            url: '/stories/:slug',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/post_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }

                                },
                                'main': {
                                    templateUrl: 'views/posts/postFullView.html',
                                    controller: 'PostViewCtrl',
                                    resolve: {
                                        postData: function (postService, settingsService, $q, $stateParams, $rootScope) {
                                            var def = $q.defer();
                                            postService.getPostDetails($stateParams.slug, function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                    if (response.postsData !== undefined) {
                                                        $rootScope.site_tit_cont = response.postsData.seo_title;
                                                        $rootScope.site_tags = response.postsData.seo_tags;
                                                        $rootScope.site_desc_cont = response.postsData.seo_description;
                                                        settingsService.toGetData(function (data) {
                                                            if (data === 'fail') {
                                                                console.log(data);
                                                            } else {
                                                                if (response.postsData.seo_title === '') {
                                                                    $rootScope.site_tit_cont = data.site_title;
                                                                }
                                                                if (response.postsData.seo_tags === '') {
                                                                    $rootScope.site_tags = data.site_tags;
                                                                }
                                                                if (response.postsData.site_desc_cont === '') {
                                                                    $rootScope.site_desc_cont = data.site_description;
                                                                }

                                                            }
                                                        }, function (data) {
                                                            console.log(data);
                                                        });
                                                    }
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        sideBarsData: function (postService, $q, $stateParams) {
                                            var def = $q.defer();
                                            postService.getsideBarDetails($stateParams.slug, function (data) {
                                                if (data !== 'fail') {
                                                    def.resolve(data);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        trendingPostData: function (postService, $q) {
                                            var def = $q.defer();
                                            postService.getTrendingPostData(function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.preview', {
                            url: '/preview/:id',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/post_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }

                                },
                                'main': {
                                    templateUrl: 'views/posts/postFullView.html',
                                    controller: 'PostViewCtrl',
                                    resolve: {
                                        postData: function (postService, settingsService, $q, $stateParams, $rootScope) {
                                            var def = $q.defer();
                                            postService.getPreviewPostDetails($stateParams.id, function (response) {
                                                def.resolve(response);
                                                $rootScope.site_tit_cont = response.postsData.seo_title;
                                                $rootScope.site_tags = response.postsData.seo_tags;
                                                $rootScope.site_desc_cont = response.postsData.seo_description;
                                                settingsService.toGetData(function (data) {
                                                    if (data === 'fail') {
                                                        console.log(data);
                                                    } else {
                                                        if (response.postsData.seo_title === '') {
                                                            $rootScope.site_tit_cont = data.site_title;
                                                        }
                                                        if (response.postsData.seo_tags === '') {
                                                            $rootScope.site_tags = data.site_tags;
                                                        }
                                                        if (response.postsData.site_desc_cont === '') {
                                                            $rootScope.site_desc_cont = data.site_description;
                                                        }

                                                    }
                                                }, function (data) {
                                                    console.log(data);
                                                });
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        sideBarsData: function (postService, $q, $stateParams) {
                                            var def = $q.defer();
                                            postService.getsideBarDetails($stateParams.slug, function (data) {
                                                if (data !== 'fail') {
                                                    def.resolve(data);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        trendingPostData: function (postService, $q) {
                                            var def = $q.defer();
                                            postService.getTrendingPostData(function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        settingsData: function (settingsService, $q) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }

                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.shows', {
                            url: '/shows',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/shows/shows.html',
                                    controller: 'showCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        showData: function (showsService, $q) {
                                            var def = $q.defer();
                                            var lmt = 8;
                                            var ofSet = 0;
                                            showsService.toGetShowPublishData(lmt, ofSet, function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        showCount: function (showsService, $q) {
                                            var def = $q.defer();
                                            showsService.toGetShowPublishCount(function (response) {
                                                def.resolve(response);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.show', {
                            url: '/show/:slug',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }

                                },
                                'main': {
                                    templateUrl: 'views/shows/seasons.html',
                                    controller: 'showViewCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data === 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        xplorererdata: function (techexplorerService, $q, $stateParams) {
                                            var def = $q.defer();
                                            techexplorerService.toGetDataById($stateParams.slug, function (data) {
                                                if (data === 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        showdata: function (showsService, $q, $stateParams) {
                                            var def = $q.defer();
                                            showsService.toGetDataById($stateParams.slug, function (data) {
                                                if (data === 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        showLinksdata: function (showsService, $q, $stateParams) {
                                            var def = $q.defer();
                                            showsService.toGetShowWatchLinksDataByShowId($stateParams.slug, function (data) {
                                                if (data === 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        seasondata: function (showsService, techexplorerService, $q, $stateParams) {
                                            var def = $q.defer();
                                            var totaldata = {};
                                            showsService.toGetSeasonDataById($stateParams.slug, function (seasondata) {
                                                if (seasondata === 'fail') {
                                                    def.resolve('');
                                                    totaldata['seasondata'] = [];
                                                } else {
//                                                    console.log(data[0].id); // need to work on this
                                                    var lmt = 3;
                                                    var ofSet = 0;
                                                    totaldata['seasondata'] = seasondata;
                                                    var seasonId = seasondata[0].id;
                                                    /* episode data by seasonid start here*/
                                                    showsService.toGetEpisodeDataById(lmt, ofSet, seasonId, $stateParams.slug, function (episodedata) {
                                                        if (episodedata === 'fail') {
                                                            totaldata['episodedata'] = [];
                                                            //def.resolve('');
//                                                            def.resolve(totaldata);
                                                        } else {
                                                            totaldata['episodedata'] = episodedata;
                                                        }
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                    /* episode data by seasonid end here */

                                                    /* episode count by seasonId */
                                                    showsService.toGetEpisodeDataCount(seasonId, $stateParams.slug, function (episodecount) {
                                                        if (episodecount === 'fail') {
                                                            totaldata['episodeCount'] = 0;
                                                        } else {
                                                            totaldata['episodeCount'] = episodecount;
                                                        }
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                    /* end here */

                                                    /* xplorer data start here */
                                                    techexplorerService.toGetTexhxplorerDataBySeasonId(seasonId, function (techxplorerdata) {
                                                        if (techxplorerdata === 'fail') {
                                                            totaldata['techxplorerdata'] = [];
                                                        } else {
                                                            totaldata['techxplorerdata'] = techxplorerdata;
                                                        }
                                                        def.resolve(totaldata);
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                    /* end here */

                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.episode', {
                            url: '/episodes/:slug',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }

                                },
                                'main': {
                                    templateUrl: 'views/episodes/episodeFullView.html',
                                    controller: 'episodeViewCtrl',
                                    resolve: {
                                        episodeData: function (episodesService, settingsService, $q, $stateParams, $rootScope) {
                                            var def = $q.defer();
                                            episodesService.getEpisodeDetails($stateParams.slug, function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                    $rootScope.site_tit_cont = response.episodeData.seo_title;
                                                    $rootScope.site_tags = response.episodeData.seo_tags;
                                                    $rootScope.site_desc_cont = response.episodeData.seo_description;
                                                    settingsService.toGetData(function (data) {
                                                        if (data === 'fail') {
                                                            console.log(data);
                                                        } else {
                                                            if (response.episodeData.seo_title === '') {
                                                                $rootScope.site_tit_cont = data.site_title;
                                                            }
                                                            if (response.episodeData.seo_tags === '') {
                                                                $rootScope.site_tags = data.site_tags;
                                                            }
                                                            if (response.episodeData.site_desc_cont === '') {
                                                                $rootScope.site_desc_cont = data.site_description;
                                                            }

                                                        }
                                                    }, function (data) {
                                                        console.log(data);
                                                    });
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        sideBarsData: function (postService, $q, $stateParams) {
                                            var def = $q.defer();
                                            postService.getsideBarDetails($stateParams.slug, function (data) {
                                                if (data !== 'fail') {
                                                    def.resolve(data);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        trendingEpisodeData: function (episodesService, $q) {
                                            var def = $q.defer();
                                            episodesService.getTrendingEpisodeData(function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                ngclass: 'main'
                            }
                        })
                        .state('home.contactus', {
                            url: '/contactus',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/contactus/contactus.html',
                                    controller: 'contactusCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
//                                ngclass: 'main'
                            }
                        })
                        .state('home.pages', {
                            url: '/:customPage',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/custompages/custompage.html',
                                    controller: 'custompagesCtrl',
                                    resolve: {
                                        custompagedata: function (pagesService, settingsService, $q, $stateParams, $rootScope) {
                                            var def = $q.defer();
                                            pagesService.toGetCustomPageData($stateParams.customPage, function (data) {
                                                if (data === 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.seo_title;
                                                    $rootScope.site_tags = data.seo_tags;
                                                    $rootScope.site_desc_cont = data.seo_description;
                                                    settingsService.toGetData(function (settingsdata) {
                                                        if (settingsdata === 'fail') {
                                                            console.log(settingsdata);
                                                        } else {
                                                            if (data.seo_title === '') {
                                                                $rootScope.site_tit_cont = settingsdata.site_title;
                                                            }
                                                            if (data.seo_tags === '') {
                                                                $rootScope.site_tags = settingsdata.site_tags;
                                                            }
                                                            if (data.site_desc_cont === '') {
                                                                $rootScope.site_desc_cont = settingsdata.site_description;
                                                            }

                                                        }
                                                    }, function (settingsdata) {
                                                        console.log(settingsdata);
                                                    });
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        sideBarsData: function (pagesService, $q, $stateParams) {
                                            var def = $q.defer();
                                            pagesService.getsideBarDetails($stateParams.customPage, function (data) {
                                                if (data !== 'fail') {
                                                    def.resolve(data);
                                                } else {
                                                    def.resolve('');
                                                }

                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
//                                ngclass: 'main'
                            }
                        })
                        .state('home.customcategories', {
                            url: '/categories/:customCategory',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/categories/customcategories.html',
                                    controller: 'customCategoriesCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categotyDataBySlug: function (CategoryService, techexplorerService, postService, $q, $stateParams, $state) {
                                            var def = $q.defer();
                                            var result = {};
                                            CategoryService.toGetCategoryDataBySlug($stateParams.customCategory, function (categorydata) {
                                                if (categorydata === 'fail') {
                                                    def.resolve(0);
                                                } else {
                                                    if (categorydata.featured_post_id == 0) {
                                                        var lmt = 11;
                                                    } else {
                                                        var lmt = 10;
                                                    }

                                                    var ofSet = 0;
                                                    var tech_lmt = 3;
                                                    if (categorydata === 'fail') {
                                                        result['categorydata'] = [];
                                                        //def.resolve(result);
                                                    } else if (categorydata.form_subscription === 'Y') {
                                                        if (categorydata.featured_post_id == 0) {
                                                            var lmt = 12;
                                                        } else {
                                                            var lmt = 11;
                                                        }
                                                        tech_lmt = 1;
                                                    }
                                                    result['categorydata'] = categorydata;
                                                    techexplorerService.toGetAllDataByLimit(tech_lmt, $stateParams.customCategory, function (techx_data) {
                                                        if (techx_data === 'fail') {
                                                            result['techx_data'] = [];
                                                            //def.resolve(result);
                                                        } else {
                                                            result['techx_data'] = techx_data;
                                                        }
                                                        postService.toGetPostPublishDataByCategory(categorydata.slug, categorydata.featured_post_id, lmt, ofSet, function (post_data) {
                                                            if (post_data === 'fail') {
                                                                result['post_data'] = [];
                                                                def.resolve(result);
                                                            } else {
                                                                result['post_data'] = post_data;
                                                                def.resolve(result);
                                                            }

                                                        }, function (data) {
                                                            def.reject(data);
                                                        });
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        postsCount: function (postService, CategoryService, $stateParams, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetCategoryDataBySlug($stateParams.customCategory, function (categorydata) {
                                                if (categorydata === 'fail') {
                                                    def.resolve(0);
                                                } else {
                                                    postService.toGetPostPublishDataByCategoryCount($stateParams.customCategory, categorydata.featured_post_id, function (response) {
                                                        def.resolve(response);
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                }
                                            }, function (response) {
                                                def.reject(response);
                                            });
                                            return def.promise;
                                        },
                                        trendingPostDataByCategory: function (postService, $q, $stateParams) {
                                            var def = $q.defer();
                                            postService.getTrendingPostDataByCategory($stateParams.customCategory, function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                } else {
//                                                    console.log(response)
                                                    def.resolve(0);

                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }

                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
//                                ngclass: 'main'
                            }
                        })
                        .state('home.previewCustomcategories', {
                            url: '/previewCategory/:id',
                            views: {
                                'header': {
                                    templateUrl: 'views/blocks/landing_header.html',
                                    controller: 'headerCtrl',
                                    resolve: {
                                        categoriesdata: function (CategoryService, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetHomeCategoriesData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        headerpagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(0, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                                'main': {
                                    templateUrl: 'views/categories/customcategories.html',
                                    controller: 'customCategoriesCtrl',
                                    resolve: {
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        categotyDataBySlug: function (CategoryService, techexplorerService, postService, $q, $stateParams, $state) {
                                            var def = $q.defer();
                                            var result = {};
                                            CategoryService.toGetCategoryDataById($stateParams.id, function (categorydata) {
                                                if (categorydata === 'fail') {
                                                    def.resolve(0);
                                                } else {
                                                    if (categorydata.featured_post_id == 0) {
                                                        var lmt = 11;
                                                    } else {
                                                        var lmt = 10;
                                                    }

                                                    var ofSet = 0;
                                                    var tech_lmt = 3;
                                                    if (categorydata === 'fail') {
                                                        result['categorydata'] = [];
                                                        //def.resolve(result);
                                                    } else if (categorydata.form_subscription === 'Y') {
                                                        if (categorydata.featured_post_id == 0) {
                                                            var lmt = 12;
                                                        } else {
                                                            var lmt = 11;
                                                        }
                                                        tech_lmt = 1;
                                                    }
                                                    result['categorydata'] = categorydata;
                                                    techexplorerService.toGetAllXplorerDataByLimit(tech_lmt, $stateParams.id, function (techx_data) {
                                                        if (techx_data === 'fail') {
                                                            result['techx_data'] = [];
                                                            //def.resolve(result);
                                                        } else {
                                                            result['techx_data'] = techx_data;
                                                        }
                                                        postService.toGetPostPublishDataByCategory(categorydata.slug, categorydata.featured_post_id, lmt, ofSet, function (post_data) {
                                                            if (post_data === 'fail') {
                                                                result['post_data'] = [];
                                                                def.resolve(result);
                                                            } else {
                                                                result['post_data'] = post_data;
                                                                def.resolve(result);
                                                            }

                                                        }, function (data) {
                                                            def.reject(data);
                                                        });
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        postsCount: function (postService, CategoryService, $stateParams, $q) {
                                            var def = $q.defer();
                                            CategoryService.toGetCategoryDataById($stateParams.id, function (categorydata) {
                                                if (categorydata === 'fail') {
                                                    def.resolve(0);
                                                } else {
                                                    postService.toGetPostPublishDataByCategoryCountById($stateParams.id, categorydata.featured_post_id, function (response) {
                                                        def.resolve(response);
                                                    }, function (data) {
                                                        def.reject(data);
                                                    });
                                                }
                                            }, function (response) {
                                                def.reject(response);
                                            });
                                            return def.promise;
                                        },
                                        trendingPostDataByCategory: function (postService, $q, $stateParams) {
                                            var def = $q.defer();
                                            postService.getTrendingPostDataByCategoryById($stateParams.id, function (response) {
                                                if (response !== 'fail') {
                                                    def.resolve(response);
                                                } else {
//                                                    console.log(response)
                                                    def.resolve(0);

                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }

                                    }
                                },
                                'footer': {
                                    templateUrl: 'views/blocks/landing_footer.html',
                                    controller: 'footerCtrl',
                                    resolve: {
                                        pagesdata: function (pagesService, $q) {
                                            var def = $q.defer();
                                            pagesService.toGetHomePagesData(1, function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
//                                ngclass: 'main'
                            }
                        })
                        .state('access', {
                            url: '/access',
                            abstract: true,
                            templateUrl: 'views/blocks/index.html'
                        })
                        .state('access.login', {
                            url: '/login',
                            views: {
                                'main': {
                                    templateUrl: 'views/access/login.html',
                                    controller: 'LoginCtrl'
                                }
                            },
                            data: {
                                access: false,
                                ngclass: 'banner-img-admin'
                            }
                        })
                        .state('access.forgetpassword', {
                            url: '/forgetpassword',
                            views: {
                                'main': {
                                    templateUrl: 'views/access/page_forgotpwd.html',
                                    controller: 'forgetPwdCtrl'
                                }
                            },
                            data: {
                            }
                        })
                        .state('access.resetpassword', {
                            url: '/resetpassword?resetKey',
                            views: {
                                'main': {
                                    templateUrl: 'views/access/reset_forgotpwd.html',
                                    controller: 'resetPwdCtrl',
                                    resolve: {
                                        userdata: function (AuthenticationService, $q, $stateParams) {
                                            var def = $q.defer();
                                            AuthenticationService.resetPassword($stateParams.resetKey, function (response) {
                                                if (response.data !== 'fail') {
                                                    def.resolve(response.data);
                                                } else {
                                                    //$state.go('access.login');
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                },
                            },
                            data: {
                            }
                        })
                        .state('home.app', {
                            url: '/acp',
                            views: {
                                'header': {
                                    templateUrl: layout,
                                    controller: 'homeControl',
                                    resolve: {
                                        userdata: function (AuthenticationService, $q, $localStorage) {
                                            var def = $q.defer();
                                            AuthenticationService.toGetUserData($localStorage.session.id, function (data) {
                                                def.resolve(data);
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        },
                                        settingsData: function (settingsService, $q, $rootScope) {
                                            var def = $q.defer();
                                            settingsService.toGetData(function (data) {
                                                if (data == 'fail') {
                                                    def.resolve('');
                                                } else {
                                                    def.resolve(data);
                                                    $rootScope.site_tit_cont = data.site_title;
                                                    $rootScope.site_tags = data.site_tags;
                                                    $rootScope.site_desc_cont = data.site_description;
                                                }
                                            }, function (data) {
                                                def.reject(data);
                                            });
                                            return def.promise;
                                        }
                                    }
                                }
                            },
                            data: {
                                access: true
                            }
                        })
                        .state('home.app.dashboard', {
                            url: '/dashboard',
                            templateUrl: 'views/dashboard.html',
                            controller: 'dashboardCtrl',
                            resolve: {
                                countdata: function (AuthenticationService, $q) {
                                    var def = $q.defer();
                                    AuthenticationService.toGetAllAppData(function (response) {
                                        def.resolve(response);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
                            }
                        })
                        .state('home.app.editprofile', {
                            url: '/editprofile',
                            templateUrl: 'views/editprofile.html',
                            controller: 'editProfileCtrl',
                            resolve: {
                                userdata: function (AuthenticationService, $q, $localStorage) {
                                    var def = $q.defer();
                                    AuthenticationService.toGetUserData($localStorage.session.id, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
                            }
                        })
                        .state('home.app.changepassword', {
                            url: '/changepassword',
                            templateUrl: 'views/changepassword.html',
                            controller: 'changePwdCtrl',
                            data: {
                                access: true
                            }
                        })
                        .state('home.app.adminusers', {
                            url: '/adminusers',
                            templateUrl: 'views/admins/adminusers.html',
                            controller: 'adminusersCtrl',
                            resolve: {
                                adminsdata: function (SubAdminService, $q) {
                                    var def = $q.defer();
                                    SubAdminService.toGetAdminsData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'admins'
                            }
                        })
                        .state('home.app.addadmin', {
                            url: '/addadmin',
                            templateUrl: 'views/admins/addadmin.html',
                            controller: 'addAdminCtrl',
                            data: {
                                access: true

                            }
                        })
                        .state('home.app.editadmin', {
                            url: '/editadmin?admin_id',
                            templateUrl: 'views/admins/addadmin.html',
                            controller: 'editAdminCtrl',
                            resolve: {
                                adminuserdata: function (SubAdminService, $q, $stateParams) {
                                    var def = $q.defer();
                                    SubAdminService.toGetAdminData($stateParams.admin_id, function (response) {
                                        def.resolve(response.data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
                            }
                        })
                        .state('home.app.users', {
                            url: '/users',
                            templateUrl: 'views/users/users.html',
                            controller: 'usersCtrl',
                            resolve: {
                                usersdata: function (UserService, $q) {
                                    var def = $q.defer();
                                    UserService.toGetAllUsersData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }

                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'users'
                            }
                        })
                        .state('home.app.adduser', {
                            url: '/adduser',
                            templateUrl: 'views/users/adduser.html',
                            controller: 'addUserCtrl',
                            data: {
                                access: true,
                                adminPermission: 'users'
                            }
                        })
                        .state('home.app.edituser', {
                            url: '/edituser?userId',
                            templateUrl: 'views/users/adduser.html',
                            controller: 'editUserCtrl',
                            resolve: {
                                userdata: function (UserService, $q, $stateParams) {
                                    var def = $q.defer();
                                    UserService.toGetUserData($stateParams.userId, function (response) {
                                        def.resolve(response.data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'users'
                            }
                        })
                        .state('home.app.categories', {
                            url: '/categories',
                            templateUrl: 'views/categories/categories.html',
                            controller: 'categoriesCtrl',
                            resolve: {
                                categoriesdata: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetAllCategoriesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'categories'
                            }
                        })
                        .state('home.app.addcategory', {
                            url: '/addcategory',
                            templateUrl: 'views/categories/addcategory.html',
                            controller: 'addCategoriesCtrl',
                            resolve: {
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'categories'
                            }
                        })
                        .state('home.app.editcategory', {
                            url: '/editcategory?categoryId',
                            templateUrl: 'views/categories/addcategory.html',
                            controller: 'editCategoriesCtrl',
                            resolve: {
                                categoryData: function (CategoryService, $q, $stateParams) {
                                    var def = $q.defer();
                                    CategoryService.toGetCategoryData($stateParams.categoryId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                categoryPostsData: function (postService, $q, $stateParams) {
                                    var def = $q.defer();
                                    postService.toGetAllDataByCategoryId($stateParams.categoryId, function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'categories'

                            }
                        })
                        .state('home.app.keywords', {
                            url: '/keywords',
                            templateUrl: 'views/keywords/index.html',
                            controller: 'keywordsCtrl',
                            resolve: {
                                keywordsdata: function (keywordService, $q) {
                                    var def = $q.defer();
                                    keywordService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'keywords'
                            }
                        })
                        .state('home.app.addkeyword', {
                            url: '/addkeyword',
                            templateUrl: 'views/keywords/add.html',
                            controller: 'addKeywordCtrl',
                            data: {
                                access: true,
                                adminPermission: 'keywords'
                            }
                        })
                        .state('home.app.editkeyword', {
                            url: '/editkeyword?keywordId',
                            templateUrl: 'views/keywords/add.html',
                            controller: 'editKeywordCtrl',
                            resolve: {
                                keywordData: function (keywordService, $q, $stateParams) {
                                    var def = $q.defer();
                                    keywordService.toGetData($stateParams.keywordId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'keywords'
                            }
                        })
                        .state('home.app.media', {
                            url: '/media',
                            templateUrl: 'views/media/index.html',
                            controller: 'mediaCtrl',
                            resolve: {
                                mediadata: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'media'
                            }
                        })
                        .state('home.app.addmedia', {
                            url: '/addmedia',
                            templateUrl: 'views/media/add.html',
                            controller: 'addMediaCtrl',
                            data: {
                                access: true,
                                adminPermission: 'media'
                            }
                        })
                        .state('home.app.editmedia', {
                            url: '/editmedia?mediaId',
                            templateUrl: 'views/media/edit.html',
                            controller: 'editMediaCtrl',
                            resolve: {
                                mediaData: function (mediaService, $q, $stateParams) {
                                    var def = $q.defer();
                                    mediaService.toGetData($stateParams.mediaId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'media'
                            }
                        })
                        .state('home.app.techexplorers', {
                            url: '/techexplorer',
                            templateUrl: 'views/techexplorer/index.html',
                            controller: 'techexplorerCtrl',
                            resolve: {
                                techexplorerdata: function (techexplorerService, $q) {
                                    var def = $q.defer();
                                    techexplorerService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'xplorers'
                            }
                        })
                        .state('home.app.addtechexplorer', {
                            url: '/addtechexplorer',
                            templateUrl: 'views/techexplorer/addtechexplorers.html',
                            controller: 'addTechexplorerCtrl',
                            resolve: {
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }, },
                            data: {
                                access: true,
                                adminPermission: 'xplorers'
                            }
                        })
                        .state('home.app.edittechexplorer', {
                            url: '/edittechexplorer?techexplorerId',
                            templateUrl: 'views/techexplorer/addtechexplorers.html',
                            controller: 'editTechexplorerCtrl',
                            resolve: {
                                techexplorerdata: function (techexplorerService, $q, $stateParams) {
                                    var def = $q.defer();
                                    techexplorerService.toGetTechexplorerData($stateParams.techexplorerId, function (response) {
                                        def.resolve(response.data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'xplorers'
                            }
                        })
                        .state('home.app.posts', {
                            url: '/posts',
                            templateUrl: 'views/posts/index.html',
                            controller: 'postsCtrl',
                            resolve: {
                                postsdata: function (postService, $q) {
                                    var def = $q.defer();
                                    postService.toGetSelectedData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                postsearchdata: function (postService, $q) {
                                    var def = $q.defer();
                                    postService.toGetSelectedData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'posts'
                            }
                        })
                        .state('home.app.addpost', {
                            url: '/addpost',
                            templateUrl: 'views/posts/add.html',
                            controller: 'addPostCtrl',
                            resolve: {
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                sideBars: function (sidebarsService, $q) {
                                    var def = $q.defer();
                                    sidebarsService.toGetAllActiveSidebarsData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllKeywords: function (keywordService, $q) {
                                    var def = $q.defer();
                                    keywordService.toGetSelectedKeywordData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }

                            },
                            data: {
                                access: true,
                                adminPermission: 'posts'
                            }
                        })
                        .state('home.app.editpost', {
                            url: '/editpost?postId',
                            templateUrl: 'views/posts/add.html',
                            controller: 'editPostCtrl',
                            resolve: {
                                postData: function (postService, $q, $stateParams) {
                                    var def = $q.defer();
                                    postService.toGetData($stateParams.postId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllCategories: function (CategoryService, $q) {
                                    var def = $q.defer();
                                    CategoryService.toGetSelectCategoryData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllKeywords: function (keywordService, $q) {
                                    var def = $q.defer();
                                    keywordService.toGetSelectedKeywordData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                sideBars: function (sidebarsService, $q) {
                                    var def = $q.defer();
                                    sidebarsService.toGetAllActiveSidebarsData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'posts'
                            }
                        })
                        .state('home.app.contacts', {
                            url: '/contacts',
                            templateUrl: 'views/contacts/index.html',
                            controller: 'contactsCtrl',
                            resolve: {
                                contactsdata: function (contactsService, $q) {
                                    var def = $q.defer();
                                    contactsService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'contacts'
                            }
                        })
                        .state('home.app.newsletter', {
                            url: '/newsletter',
                            templateUrl: 'views/newsletter/index.html',
                            controller: 'newsletterCtrl',
                            resolve: {
                                newsletterdata: function (newsletterService, $q) {
                                    var def = $q.defer();
                                    newsletterService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'newsletters'
                            }
                        })
                        .state('home.app.addnewsletter', {
                            url: '/addnewsletter',
                            templateUrl: 'views/newsletter/add.html',
                            controller: 'addnewsletterCtrl',
                            data: {
                                access: true,
                                adminPermission: 'newsletters'

                            }
                        })
                        .state('home.app.editnewsletter', {
                            url: '/editnewsletter?id',
                            templateUrl: 'views/newsletter/add.html',
                            controller: 'editnewsletterCtrl',
                            resolve: {
                                editNewsletterdata: function (newsletterService, $q, $stateParams) {
                                    var def = $q.defer();
                                    newsletterService.toGetNewletterData($stateParams.id, function (response) {
                                        def.resolve(response.data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'newsletters'

                            }
                        })
                        .state('home.app.sidebars', {
                            url: '/sidebars',
                            templateUrl: 'views/sidebars/index.html',
                            controller: 'sidebarsCtrl',
                            resolve: {
                                sidebarsdata: function (sidebarsService, $q) {
                                    var def = $q.defer();
                                    sidebarsService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
//                                adminPermission: 'newsletters'
                            }
                        })
                        .state('home.app.addsidebars', {
                            url: '/addsidebars',
                            templateUrl: 'views/sidebars/add.html',
                            controller: 'addsidebarsCtrl',
                            resolve: {
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
//                                adminPermission: 'newsletters'
                            }
                        })
                        .state('home.app.editsidebars', {
                            url: '/editsidebars?id',
                            templateUrl: 'views/sidebars/add.html',
                            controller: 'editsidebarsCtrl',
                            resolve: {
                                sidebarsdata: function (sidebarsService, $q, $stateParams) {
                                    var def = $q.defer();
                                    sidebarsService.toGetSidebarData($stateParams.id, function (response) {
                                        if (response.data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(response.data);
                                        }
                                    }, function (response) {
                                        def.reject(response);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
//                                adminPermission: 'newsletters'
                            }
                        })
                        .state('home.app.shows', {
                            url: '/shows',
                            templateUrl: 'views/shows/index.html',
                            controller: 'showsCtrl',
                            resolve: {
                                showsdata: function (showsService, $q) {
                                    var def = $q.defer();
                                    showsService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'shows'
                            }
                        })
                        .state('home.app.addshow', {
                            url: '/addshow',
                            templateUrl: 'views/shows/add.html',
                            controller: 'addShowCtrl',
                            resolve: {
                                techexplorerdata: function (techexplorerService, $q) {
                                    var def = $q.defer();
                                    techexplorerService.toGetAllDataStatusByAsc(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'shows'
                            }
                        })
                        .state('home.app.editshow', {
                            url: '/editshow?showId',
                            templateUrl: 'views/shows/edit.html',
                            controller: 'editShowCtrl',
                            resolve: {
                                showData: function (showsService, $q, $stateParams) {
                                    var def = $q.defer();
                                    showsService.toGetData($stateParams.showId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                techexplorerdata: function (techexplorerService, $q) {
                                    var def = $q.defer();
                                    techexplorerService.toGetAllDataStatus(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'shows'
                            }
                        })
                        .state('home.app.episodes', {
                            url: '/episodes',
                            templateUrl: 'views/episodes/index.html',
                            controller: 'episodesCtrl',
                            resolve: {
                                episodesdata: function (episodesService, $q) {
                                    var def = $q.defer();
                                    episodesService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'episodes'
                            }
                        })
                        .state('home.app.addepisode', {
                            url: '/addepisode',
                            templateUrl: 'views/episodes/addepisodes.html',
                            controller: 'addepisodeCtrl',
                            resolve: {
                                AllKeywords: function (keywordService, $q) {
                                    var def = $q.defer();
                                    keywordService.toGetSelectedKeywordData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllShows: function (showsService, $q) {
                                    var def = $q.defer();
                                    showsService.toGetSelectedShowData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'episodes'
                            }
                        })
                        .state('home.app.editepisode', {
                            url: '/editepisode?episodeId',
                            templateUrl: 'views/episodes/addepisodes.html',
                            controller: 'editepisodeCtrl',
                            resolve: {
                                episodesdata: function (episodesService, $q, $stateParams) {
                                    var def = $q.defer();
                                    episodesService.toGetData($stateParams.episodeId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllKeywords: function (keywordService, $q) {
                                    var def = $q.defer();
                                    keywordService.toGetSelectedKeywordData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllShows: function (showsService, $q) {
                                    var def = $q.defer();
                                    showsService.toGetSelectedShowData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                SeasonsByShow: function (showsService, $q, $stateParams) {
                                    var def = $q.defer();
                                    showsService.toGetSeasonsByShowId($stateParams.episodeId, function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'episodes'
                            }
                        })
                        .state('home.app.pages', {
                            url: '/pages',
                            templateUrl: 'views/pages/index.html',
                            controller: 'pagesCtrl',
                            resolve: {
                                pagesdata: function (pagesService, $q) {
                                    var def = $q.defer();
                                    pagesService.toGetAllData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'pages'
                            }
                        })
                        .state('home.app.addpage', {
                            url: '/addpage',
                            templateUrl: 'views/pages/add.html',
                            controller: 'addPageCtrl',
                            resolve: {
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllSidebars: function (sidebarsService, $q) {
                                    var def = $q.defer();
                                    sidebarsService.toGetAllActiveSidebarsData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'pages'
                            }
                        })
                        .state('home.app.editpage', {
                            url: '/editpage?pageId',
                            templateUrl: 'views/pages/add.html',
                            controller: 'editpageCtrl',
                            resolve: {
                                pagesData: function (pagesService, $q, $stateParams) {
                                    var def = $q.defer();
                                    pagesService.toGetData($stateParams.pageId, function (data) {
                                        def.resolve(data);
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                mediaImages: function (mediaService, $q) {
                                    var def = $q.defer();
                                    mediaService.toGetImagesData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                },
                                AllSidebars: function (sidebarsService, $q) {
                                    var def = $q.defer();
                                    sidebarsService.toGetAllActiveSidebarsData(function (data) {
                                        if (data === 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true,
                                adminPermission: 'pages'
                            }
                        })
                        .state('home.app.settings', {
                            url: '/settings',
                            templateUrl: 'views/settings/add.html',
                            controller: 'editSettingsCtrl',
                            resolve: {
                                settingsdata: function (settingsService, $q) {
                                    var def = $q.defer();
                                    settingsService.toGetData(function (data) {
                                        if (data == 'fail') {
                                            def.resolve('');
                                        } else {
                                            def.resolve(data);
                                        }
                                    }, function (data) {
                                        def.reject(data);
                                    });
                                    return def.promise;
                                }
                            },
                            data: {
                                access: true
                            }
                        });
                function load(srcs, callback) {
                    return {
                        deps: ['$ocLazyLoad', '$q',
                            function ($ocLazyLoad, $q) {

                                var deferred = $q.defer();
                                var promise = false;
                                srcs = angular.isArray(srcs) ? srcs : srcs.split(/\s+/);
                                if (!promise) {
                                    promise = deferred.promise;
                                }

                                angular.forEach(srcs, function (src) {
                                    promise = promise.then(function () {
                                        angular.forEach(MODULE_CONFIG, function (module) {
                                            if (module.name === src) {
                                                name = module.name;
                                            } else {
                                                name = src;
                                            }
                                        });
                                        return $ocLazyLoad.load(name);
                                    });
                                });
                                deferred.resolve();
                                return callback ? promise.then(function () {
                                    return callback();
                                }) : promise;
                            }
                        ]
                    };
                }


            }
        ]);
